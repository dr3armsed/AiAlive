class OracleAI:
    pass