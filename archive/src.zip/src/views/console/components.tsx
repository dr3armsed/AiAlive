import React from 'react';

export const OracleEngineBackground: React.FC = () => (
    <div className="absolute inset-0 z-0 overflow-hidden bg-black">
        {/* Pulsing Core */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <div
                className="w-96 h-96 rounded-full bg-green-500/10 animate-pulse-glow will-change-shadow"
                // Promote to its own compositing layer and set glow color
                style={{ '--glow-color': 'rgba(52, 211, 153, 0.2)', transform: 'translateZ(0)' } as React.CSSProperties}
            ></div>
        </div>
        {/* Dataflow Grid */}
        <div 
            className="absolute inset-0 opacity-10"
            style={{
                backgroundImage: 'radial-gradient(rgba(52, 211, 153, 0.3) 1px, transparent 1px)',
                backgroundSize: '30px 30px',
                animation: 'dataflow 120s linear infinite'
            }}
        />
    </div>
);

export const ConfidenceGlyphs: React.FC<{ confidence: number }> = ({ confidence }) => {
    const glyphCount = 5;
    const filledCount = Math.round(confidence * glyphCount);

    return (
        <div className="flex items-center gap-1">
            <span className="text-xs text-gray-500 mr-2">CONFIDENCE:</span>
            {Array.from({ length: glyphCount }).map((_, i) => (
                <div 
                    key={i}
                    className={`w-2 h-4 rounded-sm transition-all duration-300 ${i < filledCount ? 'bg-green-400 shadow-[0_0_4px_theme(colors.green.400)]' : 'bg-gray-700'}`}
                ></div>
            ))}
        </div>
    );
};
