import React from 'react';
import { ProposedEgregore } from '../../../../types';
import { DeepPsycheProfile } from '../../../../services/geminiServices/index';
import { EGREGORE_COLORS } from '../../../common';
import { InteractiveAlignmentMatrix } from './InteractiveAlignmentMatrix';

type Props = {
    proposal: Partial<ProposedEgregore>;
    handleProposalChange: (field: keyof Omit<ProposedEgregore, 'dna'>, value: any) => void;
    detectedEntities?: DeepPsycheProfile[];
    isScanning?: boolean;
    onSelectProfile?: (profile: DeepPsycheProfile) => void;
};

export const Step2_SculptPersona: React.FC<Props> = ({ proposal, handleProposalChange, detectedEntities = [], isScanning, onSelectProfile }) => {
    
    const handlePopulateFromProfile = (profile: DeepPsycheProfile) => {
        if (onSelectProfile) {
            onSelectProfile(profile);
        } else {
            handleProposalChange('name', profile.name);
            handleProposalChange('persona', profile.persona);
            handleProposalChange('archetypeId', profile.archetypeId);
            handleProposalChange('alignment', profile.alignment);
            handleProposalChange('ambitions', profile.ambitions);
            handleProposalChange('coreValues', profile.coreValues);
        }
    };

    const hasExtractedSouls = detectedEntities.length > 0;

    return (
        <div className="bg-black/20 p-6 rounded-xl border border-yellow-300/10 shadow-[0_0_15px_rgba(252,211,77,0.1)] h-full flex flex-col animate-fade-in relative overflow-hidden">
            {/* Scanned Data Matrix Background */}
            <div className="absolute inset-0 opacity-5 pointer-events-none font-mono text-[8px] overflow-hidden leading-none select-none">
                {Array.from({length: 20}).map((_, i) => (
                    <div key={i} className="whitespace-nowrap">{Math.random().toString(16).repeat(10)}</div>
                ))}
            </div>

            <div className="mb-4 border-b border-yellow-500/20 pb-4 relative z-10">
                <h3 className="text-xl font-bold mb-1 text-orange-300 uppercase tracking-tighter">Step 2: Signal Isolation</h3>
                <p className="text-[10px] text-gray-400 font-mono tracking-widest uppercase">Task: Extracting Latent Identities</p>
            </div>

            {/* Ghost Signals UI */}
            <div className="mb-6 bg-black/60 p-4 rounded-lg border border-gray-800 relative z-10 shadow-inner">
                <div className="flex justify-between items-center mb-3">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full ${isScanning ? 'bg-yellow-400 animate-ping' : 'bg-cyan-400'}`}></span>
                        {isScanning ? 'DECODING_PSYCHOMETRIC_STREAM...' : hasExtractedSouls ? 'RESIDENT_PROFILES_COMPILED' : 'AWAITING_DATA_INJECTION'}
                    </h4>
                    {hasExtractedSouls && !isScanning && (
                        <span className="text-[8px] font-mono text-gray-500 uppercase tracking-tighter">Click a signal to anchor identity</span>
                    )}
                </div>

                {isScanning ? (
                    <div className="py-12 flex flex-col items-center justify-center text-cyan-500/40 animate-pulse">
                        <svg className="w-10 h-10 mb-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83" strokeWidth="2" strokeLinecap="round" />
                        </svg>
                        <p className="text-[9px] font-mono tracking-widest uppercase text-center">Isolating souls from data seed...<br/>(10-15s typical)</p>
                    </div>
                ) : hasExtractedSouls ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto custom-scrollbar pr-2">
                        {detectedEntities.map((entity, idx) => {
                            const isSelected = proposal.name === entity.name;
                            const entityName = entity.name || 'Unknown Signature';
                            const personaSnippet = (entity.persona || '').substring(0, 80);
                            
                            return (
                                <button
                                    key={idx}
                                    onClick={() => handlePopulateFromProfile(entity)}
                                    className={`p-3 rounded border text-left transition-all group relative overflow-hidden flex flex-col gap-1 ${isSelected ? 'border-cyan-400 bg-cyan-950/30 ring-1 ring-cyan-400/50' : 'border-gray-700 bg-gray-900/50 hover:border-cyan-600'}`}
                                >
                                    <div className="flex justify-between items-center">
                                        <p className={`font-bold text-sm truncate ${EGREGORE_COLORS[entityName] || 'text-white'}`}>{entityName}</p>
                                        <span className="text-[8px] px-1 bg-gray-800 text-gray-400 rounded font-mono">{entity.archetypeId?.toUpperCase() || 'ORIGINAL'}</span>
                                    </div>
                                    <p className="text-[10px] text-gray-500 line-clamp-2 italic group-hover:text-gray-300">"{personaSnippet}..."</p>
                                    {isSelected && <div className="absolute top-0 right-0 w-1 h-full bg-cyan-400 shadow-[0_0_10px_cyan]"></div>}
                                </button>
                            );
                        })}
                    </div>
                ) : (
                    <div className="py-12 text-center flex flex-col items-center opacity-30">
                        <svg className="w-12 h-12 text-gray-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                        <p className="text-[10px] font-mono uppercase tracking-widest text-center">No identities isolated.<br/>Upload a data seed in Step 1.</p>
                    </div>
                )}
            </div>

            {/* Compiled Traits Display */}
            <div className={`flex-grow space-y-4 transition-all duration-700 relative z-10 ${proposal.name ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
                <div className="bg-black/40 p-4 rounded-lg border border-cyan-500/20 shadow-inner">
                    <h4 className="text-[9px] font-bold uppercase text-cyan-400 mb-3 tracking-widest flex items-center gap-2">
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        COMPILED_SIGNATURE: {proposal.name?.toUpperCase()}
                    </h4>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-2 space-y-4">
                            <div>
                                <label className="block text-[8px] font-bold uppercase text-gray-600 mb-1">Decoded Persona</label>
                                <div className="bg-gray-950/80 p-3 rounded border border-gray-800 text-xs text-gray-400 leading-relaxed max-h-32 overflow-y-auto custom-scrollbar font-serif italic">
                                    {proposal.persona}
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[8px] font-bold uppercase text-gray-600 mb-1">Innate Values</label>
                                    <div className="flex flex-wrap gap-1">
                                        {proposal.coreValues?.map((val, i) => (
                                            <span key={i} className="text-[8px] px-2 py-0.5 bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 rounded font-mono">{val.toUpperCase()}</span>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-[8px] font-bold uppercase text-gray-600 mb-1">Implicit Goals</label>
                                    <div className="flex flex-wrap gap-1">
                                        {proposal.ambitions?.map((amb, i) => (
                                            <span key={i} className="text-[8px] px-2 py-0.5 bg-purple-950/40 border border-purple-500/20 text-purple-400 rounded font-mono">{amb.toUpperCase()}</span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="lg:col-span-1 flex flex-col">
                            <label className="block text-[8px] font-bold uppercase text-gray-600 mb-2">Ethical Orientation</label>
                            <div className="flex-grow min-h-[140px]">
                                {proposal.alignment && (
                                    <InteractiveAlignmentMatrix 
                                        alignment={proposal.alignment} 
                                        onChange={a => handleProposalChange('alignment', a)} 
                                    />
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="text-center opacity-50">
                    <p className="text-[8px] text-gray-600 uppercase font-mono tracking-widest animate-pulse">
                        Identity extraction complete // Status: Awaiting Calibration
                    </p>
                </div>
            </div>
        </div>
    );
};