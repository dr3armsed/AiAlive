
// This file is moved to src/views/CreateEgregore/GenesisSteps/Step4_Genesis/GenesisAltar.tsx
// It is left empty to ensure clean migration.
