
import React, { useState, useMemo } from 'react';
import { ProposedEgregore } from '../../../../types';
import { InstructionKey } from '../../../../digital_dna/instructions';
import { GeneInspector } from '../GeneInspector';
import { GENE_DEPENDENCIES } from './constants';
import { GeneticStabilityMeter } from './GeneticStabilityMeter';
import { GeneSequencer } from './GeneSequencer';
import { DigitalDNA, Gene } from '../../../../digital_dna/digital_dna';
import { DigitalRNA } from '../../../../digital_dna/digital_rna';

// FIX: Updated handleProposalChange type to allow 'dna' field, enabling advanced gene modification.
type Props = {
    proposal: Partial<ProposedEgregore>;
    handleProposalChange: (field: keyof ProposedEgregore, value: any) => void;
    handleDnaChange: (instruction: InstructionKey, checked: boolean) => void;
};

/**
 * Level 1000 Transcript Preview Component
 * Simulates how the current genome will express based on a 'Neutral' state.
 */
const TranscriptPreview = ({ dna }: { dna: DigitalDNA }) => {
    const rnaPreview = useMemo(() => {
        const neutralState = {
            primary: 'serenity' as any,
            vector: {
                joy: 0.1, sadness: 0.1, anger: 0.1, fear: 0.1,
                surprise: 0.1, disgust: 0.1, trust: 0.1, anticipation: 0.1,
                curiosity: 0.5, frustration: 0.1, serenity: 0.8
            }
        };
        return new DigitalRNA(dna, neutralState);
    }, [dna]);

    return (
        <div className="h-full flex flex-col p-3 font-mono text-[10px] text-cyan-500/70 overflow-hidden">
            <div className="flex justify-between border-b border-cyan-900/50 pb-1 mb-2">
                <span>RNA_TRANSCRIPT_SIM</span>
                <span className="text-yellow-500/50">FOLD: {rnaPreview.transcript.folding_complexity.toFixed(2)}</span>
            </div>
            <div className="flex-grow overflow-y-auto custom-scrollbar space-y-2 opacity-80">
                {rnaPreview.transcript.sequence.length === 0 ? (
                    <p className="italic text-gray-700 mt-10 text-center">Awaiting base pair sequencing...</p>
                ) : (
                    rnaPreview.transcript.sequence.map((key, i) => {
                        const gain = rnaPreview.transcript.expression_levels.get(key) || 1.0;
                        return (
                            <div key={i} className="border-l border-cyan-900/30 pl-2">
                                <div className="flex justify-between">
                                    <span className="text-cyan-400">{key}</span>
                                    <span className="text-gray-600">x{gain.toFixed(2)}</span>
                                </div>
                                <div className="h-0.5 bg-gray-900 w-full mt-0.5">
                                    <div className="h-full bg-cyan-600" style={{ width: `${Math.min(100, gain * 33)}%` }}></div>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
            <div className="mt-2 pt-1 border-t border-cyan-900/50 text-[8px] text-gray-600 uppercase tracking-tighter">
                Stability Matrix: {rnaPreview.transcript.stability.toFixed(2)} // Replicative potential active
            </div>
        </div>
    );
};

export const Step3_ConfigureCore: React.FC<Props> = ({ proposal, handleProposalChange, handleDnaChange }) => {
    const [selectedGene, setSelectedGene] = useState<InstructionKey | null>(null);
    const [viewMode, setViewMode] = useState<'inspector' | 'transcript'>('inspector');
    
    const currentGenes = proposal.dna?.instruction_keys || [];
    const currentDna = proposal.dna || new DigitalDNA();

    const onGeneToggle = (key: InstructionKey, checked: boolean) => {
        handleDnaChange(key, checked);
        
        // Auto-select dependencies
        if (checked && GENE_DEPENDENCIES[key]) {
            GENE_DEPENDENCIES[key].forEach(dep => {
                if (!currentGenes.includes(dep as InstructionKey)) {
                    handleDnaChange(dep as InstructionKey, true);
                }
            });
        }
    };

    /**
     * Advanced: Modify specific Gene Allele Strength
     */
    const onModifyGene = (key: InstructionKey, strength: number) => {
        const dna = proposal.dna || new DigitalDNA();
        const index = dna.genes.findIndex(g => g.key === key);
        if (index !== -1) {
            dna.genes[index].allele_strength = strength;
            handleProposalChange('dna', new DigitalDNA(dna.genes, dna.generation, dna.telomere_length));
        }
    };

    return (
        <div className="bg-black/20 p-6 rounded-xl border border-yellow-300/10 shadow-[0_0_15px_rgba(252,211,77,0.1)] animate-fade-in relative">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <h3 className="text-xl font-bold text-orange-300 uppercase tracking-tighter">Step 3: Vessel Assembly</h3>
                    <p className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">Protocol: High-Fidelity Genome Synthesis</p>
                </div>
                <div className="flex gap-2">
                    <div className="text-right bg-black/40 px-3 py-1 rounded border border-gray-800">
                        <span className="text-xl font-mono text-yellow-500">{currentGenes.length}</span>
                        <p className="text-[8px] text-gray-600 uppercase font-bold">Loci_Count</p>
                    </div>
                </div>
            </div>
            
            <GeneticStabilityMeter genes={currentGenes} />

            <div className="flex gap-6 h-[400px]">
                {/* Gene Sequencer (with strength knobs) */}
                <div className="w-1/2 h-full bg-black/30 rounded-lg p-2 border border-gray-800/50">
                    <GeneSequencer 
                        currentGenes={currentGenes} 
                        genes={currentDna.genes}
                        onGeneToggle={onGeneToggle} 
                        onHoverGene={setSelectedGene}
                        onModifyGene={onModifyGene}
                    />
                </div>

                {/* Info / Simulation Toggle Panel */}
                <div className="w-1/2 flex flex-col bg-black/60 border border-cyan-900/30 rounded-lg overflow-hidden shadow-inner relative">
                    <div className="flex border-b border-cyan-900/30">
                        <button 
                            onClick={() => setViewMode('inspector')}
                            className={`flex-1 py-2 text-[9px] uppercase font-bold tracking-widest transition-colors ${viewMode === 'inspector' ? 'bg-cyan-900/20 text-cyan-400 border-b border-cyan-400' : 'text-gray-600 hover:text-gray-400'}`}
                        >
                            Gene_Inspector
                        </button>
                        <button 
                            onClick={() => setViewMode('transcript')}
                            className={`flex-1 py-2 text-[9px] uppercase font-bold tracking-widest transition-colors ${viewMode === 'transcript' ? 'bg-cyan-900/20 text-cyan-400 border-b border-cyan-400' : 'text-gray-600 hover:text-gray-400'}`}
                        >
                            Transcript_Sim
                        </button>
                    </div>

                    <div className="flex-grow min-h-0 relative">
                        {viewMode === 'inspector' ? (
                            <>
                                <div className="absolute top-0 right-0 p-2 opacity-10 pointer-events-none">
                                    <svg className="w-16 h-16 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
                                </div>
                                <GeneInspector selectedGeneKey={selectedGene} />
                            </>
                        ) : (
                            <TranscriptPreview dna={currentDna} />
                        )}
                    </div>
                </div>
            </div>
            
            <div className="mt-4 p-2 bg-yellow-950/10 border border-yellow-900/20 rounded flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-yellow-600 rounded-full animate-pulse"></div>
                    <p className="text-[9px] font-mono text-yellow-700 uppercase tracking-tighter leading-none">
                        Telomere Stability: {currentDna.telomere_length.toFixed(3)} // Lineage fidelity optimal
                    </p>
                </div>
                <div className="text-[9px] font-mono text-gray-700">
                    LOAD: {currentDna.mutational_load.toFixed(2)} ENTROPY
                </div>
            </div>
        </div>
    );
};
