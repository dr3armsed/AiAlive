
// This file is replaced by src/views/CreateEgregore/GenesisSteps/Step4_Genesis/index.tsx
// It is left empty to ensure clean migration.
