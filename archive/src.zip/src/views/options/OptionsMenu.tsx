// This file is obsolete. The canonical OptionsMenu component is now located in src/views/options/OptionsMenu/OptionsMenu.tsx.
// This re-export is for backward compatibility during the transition and to prevent import errors.
export { OptionsMenu } from './OptionsMenu/OptionsMenu';