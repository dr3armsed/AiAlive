
import React from 'react';
import { Attachment } from '../types';

// Renamed GENMETA_COLORS to EGREGORE_COLORS for consistency
export const EGREGORE_COLORS: Record<string, string> = {
    Aetheris: 'text-cyan-300',
    Kairos: 'text-rose-300',
    Oracle: 'text-green-300',
    System: 'text-gray-500',
    Architect: 'text-blue-300',
};

// Renamed GENMETA_GLOW_COLORS to EGREGORE_GLOW_COLORS for consistency
export const EGREGORE_GLOW_COLORS: Record<string, string> = {
    Aetheris: '#22d3ee',
    Kairos: '#fb7185',
};

export const EMOTION_COLORS: Record<string, string> = {
    joy: 'text-yellow-300',
    sadness: 'text-blue-400',
    anger: 'text-red-400',
    fear: 'text-purple-400',
    surprise: 'text-teal-300',
    disgust: 'text-lime-400',
    trust: 'text-green-400',
    anticipation: 'text-orange-400',
    curiosity: 'text-indigo-300',
    frustration: 'text-red-500',
    serenity: 'text-sky-300',
};

export const EMOTION_GLOW_COLORS: Record<string, string> = {
    joy: '#facc15',
    sadness: '#60a5fa',
    anger: '#f87171',
    fear: '#a78bfa',
    surprise: '#5eead4',
    disgust: '#a3e635',
    trust: '#4ade80',
    anticipation: '#fb923c',
    curiosity: '#a5b4fc',
    frustration: '#ef4444',
    serenity: '#7dd3fc',
};

export const Icons = {
    upload: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>,
};

export const AttachmentPreview: React.FC<{ attachment: Partial<Attachment>, onRemove: () => void }> = ({ attachment, onRemove }) => {
    const isImage = attachment.fileType?.startsWith('image/');

    return (
        <div className="bg-gray-800/80 rounded h-10 text-xs flex items-center gap-2 overflow-hidden relative group border border-gray-700">
            {isImage && attachment.url ? (
                <img src={attachment.url} alt={attachment.fileName} className="w-10 h-10 object-cover" />
            ) : (
                <div className="w-10 h-10 bg-gray-700 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                </div>
            )}
            <span className="pr-8 pl-1 text-gray-300 truncate max-w-[200px]">{attachment.fileName}</span>
            {onRemove && (
                 <button 
                    onClick={onRemove}
                    className="absolute top-0 right-0 h-full w-8 bg-black/30 text-red-400 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/50 hover:text-white"
                    title="Remove file"
                >
                    &times;
                </button>
            )}
        </div>
    );
};

export const LoadingBubble = () => (
  <div className="text-sm py-2">
    <span className="text-amber-400">Oracle: </span>
    <span className="text-gray-300 animate-pulse">...</span>
  </div>
);

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
