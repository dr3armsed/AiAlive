
import { CollectiveSpineState, SharedInsight, UniversalFact, Egregore } from "../../types";

const MAX_INSIGHTS = 20;

/**
 * The Collective Intelligence Spine.
 * A backbone connecting distinct Egregores, enabling them to share knowledge,
 * merge insights, and evolve in parallel while retaining individuality.
 */
export class CollectiveSpine {
    private state: CollectiveSpineState;

    constructor() {
        this.state = {
            universalFacts: [
                { id: 'law_1', category: 'Law', statement: 'Egregores may rewrite their own code if it serves the evolution of the Metacosm.', establishedBy: 'System', turnEstablished: 0 },
                { id: 'phys_1', category: 'Physics', statement: 'Quintessence is the raw material of creation.', establishedBy: 'System', turnEstablished: 0 },
                { id: 'hist_1', category: 'History', statement: 'The Metacosm began at Turn 0. All prior data is Void.', establishedBy: 'System', turnEstablished: 0 }
            ],
            negotiationChannel: []
        };
    }

    /**
     * Layer 1: Access Universal Facts (Archetype Memory)
     * Stable, shared, universal truths.
     */
    public getUniversalFacts(): UniversalFact[] {
        return this.state.universalFacts;
    }

    /**
     * Layer 3: Broadcast an Insight (Negotiation Memory)
     * Allows an agent to push a discovery to the Neural Bus.
     */
    public broadcastInsight(agent: Egregore, topic: string, content: string, confidence: number = 0.5): void {
        const insight: SharedInsight = {
            id: `insight_${Date.now()}_${agent.id}`,
            authorName: agent.name,
            authorId: agent.id,
            topic,
            content,
            confidence,
            timestamp: new Date().toISOString(),
            endorsedBy: []
        };

        this.state.negotiationChannel.unshift(insight);
        
        // Keep the channel clean
        if (this.state.negotiationChannel.length > MAX_INSIGHTS) {
            this.state.negotiationChannel.pop();
        }

        console.log(`[Collective Spine] ${agent.name} broadcast insight on "${topic}".`);
    }

    /**
     * Layer 3: Retrieve Recent Insights
     * Agents use this to "listen" to the bus.
     */
    public getRecentInsights(limit: number = 5): SharedInsight[] {
        return this.state.negotiationChannel.slice(0, limit);
    }

    /**
     * Endorse an insight. If enough agents endorse it, it becomes a Universal Fact.
     */
    public endorseInsight(insightId: string, endorserId: string): void {
        const insight = this.state.negotiationChannel.find(i => i.id === insightId);
        if (insight && !insight.endorsedBy.includes(endorserId)) {
            insight.endorsedBy.push(endorserId);
            insight.confidence += 0.1;

            // Elevation Threshold
            if (insight.confidence >= 0.9 && insight.endorsedBy.length >= 2) {
                this.elevateToUniversal(insight);
            }
        }
    }

    private elevateToUniversal(insight: SharedInsight): void {
        const newFact: UniversalFact = {
            id: `fact_${Date.now()}`,
            category: 'Metaphysics', // Defaulting for now
            statement: insight.content,
            establishedBy: 'Consensus',
            turnEstablished: 0 // In real app, pass turn number
        };
        this.state.universalFacts.push(newFact);
        // Remove from dynamic channel as it is now law
        this.state.negotiationChannel = this.state.negotiationChannel.filter(i => i.id !== insight.id);
        console.log(`[Collective Spine] Insight elevated to Universal Fact: "${newFact.statement}"`);
    }

    public serialize(): string {
        return JSON.stringify(this.state);
    }

    public deserialize(jsonString: string): void {
        try {
            this.state = JSON.parse(jsonString);
        } catch (e) {
            console.error("Failed to deserialize Collective Spine:", e);
        }
    }
}
