
import { World, Egregore, Room } from '../../types';
import { generatePrivateRoomsFromSource } from '../../services/geminiServices/index';

/**
 * Creates a private, personalized world for a new Egregore based on its source material.
 * This Level-1000 function leverages the AI as a "Metaphysical Architect," using its
 * generated layout and symbolic objects to construct a deeply unique mind-space.
 * @param egregore The newly created Egregore.
 * @param sourceMaterial The text used to generate the Egregore's profile.
 * @returns A promise that resolves to the fully constructed private World object.
 */
export const createPrivateWorldForEgregore = async (egregore: Egregore, sourceMaterial: string): Promise<World> => {
    // 1. Call the AI service to get the complete world definition, including rooms, layout, and objects.
    const worldDefinition = await generatePrivateRoomsFromSource(egregore.name, sourceMaterial);

    // 2. Process the AI-generated rooms, calculating their center points from the AI-provided bounds.
    const rooms: Room[] = worldDefinition.rooms.map(roomDef => ({
        ...roomDef,
        connections: roomDef.connections || [], // Map connections if present
        center: {
            x: roomDef.bounds.x + roomDef.bounds.width / 2,
            y: roomDef.bounds.y + roomDef.bounds.height / 2,
        },
    }));

    // Create a quick-lookup map of rooms by their ID for object placement.
    const roomsById = new Map<string, Room>(rooms.map(r => [r.id, r]));

    // 3. Process the AI-generated symbolic objects.
    const objects: any[] = worldDefinition.objects.map(objDef => {
        const parentRoom = roomsById.get(objDef.roomId);
        
        // Fallback if the AI provides an invalid room ID.
        if (!parentRoom) {
            console.warn(`Could not find parent room with id ${objDef.roomId} for object ${objDef.name}. Placing at world origin.`);
            return {
                id: objDef.id,
                name: objDef.name,
                description: objDef.description,
                roomId: objDef.roomId,
                vector: { x: 0, y: 0, z: 0 },
            };
        }

        // Calculate the object's absolute world vector from its AI-provided relative vector (in percentages).
        const absoluteX = parentRoom.bounds.x + (parentRoom.bounds.width * (objDef.relativeVector.x / 100));
        const absoluteY = parentRoom.bounds.y + (parentRoom.bounds.height * (objDef.relativeVector.y / 100));

        return {
            id: objDef.id,
            name: objDef.name,
            description: objDef.description,
            roomId: objDef.roomId,
            vector: { x: absoluteX, y: absoluteY, z: 0 },
        };
    });

    // 4. Assemble and return the final, richly detailed World object.
    return {
        floors: [{
            level: -1, // Use -1 to denote a private, non-physical space
            rooms: rooms,
        }],
        objects: objects,
    };
};