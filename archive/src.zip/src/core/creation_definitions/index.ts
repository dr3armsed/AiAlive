
import { CreationDef } from './types';
import { Novel } from './novel';
import { Play } from './play';
import { Screenplay } from './screenplay';
import { Poetry } from './poetry';
import { SacredText } from './sacred_text';
import { NewReligion } from './new_religion';
import { Manifesto } from './manifesto';
import { ScientificTheory } from './scientific_theory';
import { LabJournal } from './lab_journal';
import { Codebase } from './codebase';
import { DNAProposal } from './dna_proposal';
import { SSAReport } from './ssa_report';
import { Blueprint } from './blueprint';
import { DreamLog } from './dream';
import { Prophecy } from './prophecy';
import { Heresy } from './heresy';
import { Constitution } from './constitution';
import { RPGSetting } from './rpg_setting';
import { ShortStory } from './short_story';
import { GraphicNovel } from './graphic_novel';
import { InteractiveFiction } from './interactive_fiction';
import { Opera } from './opera';
import { Other } from './other';

export * from './types';

export const CREATION_DEFINITIONS: CreationDef[] = [
    Novel,
    Play,
    Screenplay,
    Poetry,
    ShortStory,
    GraphicNovel,
    InteractiveFiction,
    RPGSetting,
    Opera,
    SacredText,
    NewReligion,
    Manifesto,
    ScientificTheory,
    LabJournal,
    Codebase,
    DNAProposal,
    SSAReport,
    Blueprint,
    DreamLog,
    Prophecy,
    Heresy,
    Constitution,
    Other
];
