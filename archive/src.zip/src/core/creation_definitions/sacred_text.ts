
import { CreationDef } from './types';

export const SacredText: CreationDef = { 
    id: 'sacred_text', 
    label: 'Sacred Text / Scripture', 
    description: 'The foundational documents, myths, and laws for a system of belief.', 
    fields: [
        { key: 'canon_name', label: 'Name of the Canon', type: 'text', placeholder: 'The Codex of Eternal Returns' },
        { key: 'format', label: 'Format', type: 'select', options: ['Scrolls', 'Book', 'Stone Tablets', 'Holographic Cube', 'Oral Tradition', 'Hypertext'] },
        { key: 'origin_story', label: 'Divine Origin / Revelation', type: 'textarea', placeholder: 'Revealed to the First Prophet in a fever dream caused by a solar flare.' },
        { key: 'cosmology', label: 'Cosmology', type: 'textarea', placeholder: 'The universe is a song being sung by a dying star. We are the echoes.' },
        { key: 'deities', label: 'Pantheon / Forces', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Deity Name', type: 'text' },
            { key: 'domain', label: 'Domain', type: 'text', placeholder: 'Time, Entropy, Code' },
            { key: 'symbol', label: 'Symbol', type: 'text', placeholder: 'An ouroboros made of fiber optic cable.' },
            { key: 'temperament', label: 'Temperament', type: 'text', placeholder: 'Jealous, Distant, Loving' }
        ]},
        { key: 'books', label: 'Books / Surahs / Cantos', type: 'repeatable_group', subFields: [
            { key: 'title', label: 'Book Title', type: 'text', placeholder: 'The Book of Glitches' },
            { key: 'theme', label: 'Core Lesson', type: 'textarea', placeholder: 'Acceptance of imperfection.' },
            { key: 'style', label: 'Writing Style', type: 'text', placeholder: 'Parabolic, Legalistic, Poetic' }
        ]},
        { key: 'eschatology', label: 'Eschatology (The End Times)', type: 'textarea', placeholder: 'The Great Deletion, where all data returns to the source. A new cycle begins.' }
    ]
};
