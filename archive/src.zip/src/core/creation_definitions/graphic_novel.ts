
import { CreationDef } from './types';

export const GraphicNovel: CreationDef = { 
    id: 'graphic_novel', 
    label: 'Graphic Novel / Comic Script', 
    description: 'A script for a sequential art narrative, detailing visual and dialogue pacing.', 
    fields: [
        { key: 'title', label: 'Title', type: 'text', placeholder: 'Neon Ronin: The Data War' },
        { key: 'format', label: 'Format', type: 'select', options: ['Single Issue', 'Trade Paperback', 'Webcomic (Vertical)', 'Manga', 'Bande Dessinée', 'Holographic Scroll'] },
        { key: 'art_direction', label: 'Art Direction / Style', type: 'textarea', placeholder: 'Cell-shaded, high contrast, heavy use of halftones. Cyberpunk noir aesthetic. Palette: CMYK + Neon Green.' },
        { key: 'plot_summary', label: 'Plot Summary', type: 'textarea', placeholder: 'A samurai cyborg hunts for his missing memory chip in the slums of Neo-Tokyo.' },
        { key: 'character_designs', label: 'Character Sheets', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Name', type: 'text' },
            { key: 'visuals', label: 'Visual Description', type: 'textarea', placeholder: 'Tall, chrome arm, glowing red eye.' }
        ]},
        { key: 'pages', label: 'Page Breakdown', type: 'repeatable_group', subFields: [
            { key: 'page_number', label: 'Page #', type: 'number' },
            { key: 'layout', label: 'Panel Layout', type: 'text', placeholder: '9-panel grid, breaking down into a splash page.' },
            { key: 'panels', label: 'Panels', type: 'repeatable_group', subFields: [
                { key: 'panel_num', label: 'Panel #', type: 'number' },
                { key: 'shot_type', label: 'Shot Type', type: 'select', options: ['Close-up', 'Medium Shot', 'Wide Shot', 'Extreme Close-up', 'Birds-eye', 'Worm-eye', 'Dutch Angle'] },
                { key: 'description', label: 'Visual Description', type: 'textarea', placeholder: 'Rain hitting the pavement. Reflection of a neon sign.' },
                { key: 'dialogue', label: 'Dialogue / Captions', type: 'textarea', placeholder: 'CAPTION: It never stops raining here.' }
            ]}
        ]}
    ]
};
