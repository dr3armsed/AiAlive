
import { CreationDef } from './types';

export const Opera: CreationDef = { 
    id: 'opera', 
    label: 'Opera / Musical Libretto', 
    description: 'A grand musical work combining narrative, stagecraft, and song.', 
    fields: [
        { key: 'title', label: 'Title', type: 'text', placeholder: 'The Fall of Hyperion' },
        { key: 'composer', label: 'Composer (Fictional)', type: 'text', placeholder: 'Maestro Algorithmo' },
        { key: 'style', label: 'Musical Style', type: 'select', options: ['Baroque', 'Romantic', 'Atonal / Modernist', 'Minimalist', 'Electronic / Synth', 'Rock Opera', 'Generative/Algorithmic'] },
        { key: 'language', label: 'Libretto Language', type: 'text', placeholder: 'Italian / Binary / High Gothic / Constructed' },
        { key: 'orchestration', label: 'Orchestration', type: 'textarea', placeholder: 'Full symphony orchestra + synthesizer choir + tesla coils.' },
        { key: 'synopsis', label: 'Synopsis', type: 'textarea', placeholder: 'A tragedy about a star-crossed lover and a sentient starship.' },
        { key: 'roles', label: 'Roles / Voice Types', type: 'repeatable_group', subFields: [
            { key: 'character', label: 'Character', type: 'text' },
            { key: 'voice', label: 'Voice Type', type: 'select', options: ['Soprano', 'Mezzo', 'Alto', 'Tenor', 'Baritone', 'Bass', 'Countertenor', 'Synthesized'] },
            { key: 'description', label: 'Description', type: 'text' }
        ]},
        { key: 'acts', label: 'Act Structure', type: 'repeatable_group', subFields: [
            { key: 'act_title', label: 'Act Title', type: 'text' },
            { key: 'setting', label: 'Setting', type: 'text' },
            { key: 'musical_numbers', label: 'Arias / Recitatives', type: 'textarea', placeholder: '1. The Overture of Light (Orchestral), 2. The Hero\'s Lament (Tenor)' }
        ]},
        { key: 'staging', label: 'Staging Requirements', type: 'textarea', placeholder: 'Requires a zero-gravity stage and holographic projections.' }
    ]
};
