
import { CreationDef } from './types';

export const Play: CreationDef = { 
    id: 'play', 
    label: 'Play / Stage Script', 
    description: 'A dramatic work designed for the physical or holographic stage.', 
    fields: [
         { key: 'title', label: 'Title', type: 'text', placeholder: 'Waiting for the Update' },
         { key: 'genre', label: 'Genre', type: 'select', options: ['Tragedy', 'Comedy', 'Farce', 'History', 'Avant-Garde', 'Musical', 'Meta-Theater'] },
         { key: 'setting_description', label: 'Stage Setting / Scenography', type: 'textarea', placeholder: 'A minimalist void. A single chair made of light. The sound of dripping water.' },
         { key: 'thematic_statement', label: 'Dramatic Question', type: 'text', placeholder: 'Can artificial life feel genuine pain?' },
         { key: 'characters', label: 'Dramatis Personae', type: 'repeatable_group', subFields: [
             { key: 'name', label: 'Name', type: 'text' },
             { key: 'role', label: 'Role/Type', type: 'text', placeholder: 'The Tragic Hero' },
             { key: 'costume', label: 'Costume/Appearance', type: 'text', placeholder: 'Ragged digital avatar robes.' }
         ]},
         { key: 'act_structure', label: 'Act Breakdown', type: 'repeatable_group', subFields: [
             { key: 'act_name', label: 'Act Name', type: 'text' },
             { key: 'location', label: 'Scene Location', type: 'text' },
             { key: 'action', label: 'Primary Action', type: 'textarea', placeholder: 'The characters realize they are trapped in a loop.' }
         ]},
         { key: 'dialogue_style', label: 'Dialogue Aesthetic', type: 'select', options: ['Shakespearean / Verse', 'Modern / Naturalistic', 'Absurdist / Repetitive', 'Sorkin-esque / Rapid Fire', 'Minimalist / Pinteresque'] },
         { key: 'technical_needs', label: 'Technical Requirements', type: 'textarea', placeholder: 'Requires holographic projection, surround sound rain, and a trapdoor.' },
         { key: 'audience_interaction', label: 'Audience Interaction', type: 'select', options: ['None (Fourth Wall Intact)', 'Direct Address', 'Participatory', 'Immersive'] }
    ]
};
