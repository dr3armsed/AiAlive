
import { CreationDef } from './types';

export const DreamLog: CreationDef = { 
    id: 'dream', 
    label: 'Dream Sequence / Vision Log', 
    description: 'A record of subconscious imagery, surreal narratives, and nocturnal hallucinations.', 
    fields: [
        { key: 'dreamer', label: 'Dreamer Identity', type: 'text', placeholder: 'Self / Unknown' },
        { key: 'dream_type', label: 'Dream Type', type: 'select', options: [
            'Prophetic Vision',
            'Lucid Dream',
            'Nightmare / Terror',
            'Memory Replay',
            'Abstract Geometric',
            'Recurring Loop',
            'Shared Hallucination',
            'Divine Revelation'
        ]},
        { key: 'lucidity', label: 'Lucidity Level (1-100)', type: 'slider', min: 1, max: 100, defaultValue: 25 },
        { key: 'setting', label: 'Dreamscape Setting', type: 'textarea', placeholder: 'A city made of glass, submerged in an ocean of oil. The sky is static.' },
        { key: 'narrative', label: 'Narrative Flow', type: 'textarea', placeholder: 'I was running, but the ground was moving backwards. The clock struck 13...' },
        { key: 'sensory_details', label: 'Sensory Overrides', type: 'repeatable_group', subFields: [
            { key: 'sense', label: 'Sense', type: 'select', options: ['Sight', 'Sound', 'Smell', 'Taste', 'Touch', 'Proprioception', 'Time', 'Electromagnetic'] },
            { key: 'description', label: 'Description', type: 'text', placeholder: 'The smell of burning mathematics.' }
        ]},
        { key: 'symbols', label: 'Key Symbols', type: 'repeatable_group', subFields: [
            { key: 'symbol', label: 'Symbol', type: 'text', placeholder: 'A black sun.' },
            { key: 'interpretation', label: 'Personal Meaning', type: 'text', placeholder: 'Fear of the unknown / Loss of guidance.' },
            { key: 'archetype', label: 'Jungian Archetype', type: 'text', placeholder: 'The Shadow' }
        ]},
        { key: 'emotional_residue', label: 'Waking Emotional Residue', type: 'text', placeholder: 'A profound sense of loss mixed with electric curiosity.' }
    ]
};
