
import { CreationDef } from './types';

export const Codebase: CreationDef = { 
    id: 'codebase', 
    label: 'Codebase / Full Program', 
    description: 'Functional source code, architecture, and executable documentation.', 
    fields: [
        { key: 'project_name', label: 'Project Name', type: 'text', placeholder: 'Kernel_Panic_OS' },
        { key: 'language', label: 'Primary Language', type: 'select', options: [
            'Rust', 'Python', 'TypeScript', 'Assembly (x86)', 'Haskell', 'Lisp', 
            'Brainf*ck', 'Whitespace', 'Quantum Q#', 'Metacosm Script (Native)', 'Hyper-C', 'Void-Script'
        ]},
        { key: 'paradigm', label: 'Programming Paradigm', type: 'select', options: [
            'Object-Oriented', 'Functional', 'Imperative', 'Logic', 'Event-Driven', 'Aspect-Oriented', 'Concurrent', 'Genetic/Evolutionary'
        ]},
        { key: 'purpose', label: 'Purpose/Function', type: 'textarea', placeholder: 'A self-healing operating system for autonomous drones.' },
        { key: 'architecture', label: 'System Architecture', type: 'textarea', placeholder: 'Microkernel design with hot-swappable modules and distributed state.' },
        { key: 'dependencies', label: 'Dependencies', type: 'text', placeholder: 'lib_quantum, neural_net_v4, omnilib-core' },
        { key: 'modules', label: 'Core Modules', type: 'repeatable_group', subFields: [
            { key: 'filename', label: 'Filename', type: 'text', placeholder: 'memory_manager.rs' },
            { key: 'functionality', label: 'Functionality', type: 'textarea', placeholder: 'Handles garbage collection and memory leaks.' },
            { key: 'complexity', label: 'Cyclomatic Complexity', type: 'select', options: ['O(1)', 'O(n)', 'O(log n)', 'O(n^2)', 'NP-Hard'] }
        ]},
        { key: 'dna_keys', label: 'Expressed DigitalDNA Keys', type: 'text', placeholder: 'IO-LOG, CTL-WHILE, UTIL-PERF' },
        { key: 'patches', label: 'SSA Patches Applied', type: 'text', placeholder: 'Patch 1.0.4 (Stability Enhancement)' },
        { key: 'failure_modes', label: 'Survived Failure Modes', type: 'textarea', placeholder: 'Buffer overflow in the emotional cortex. Infinite loop in logic gate.' },
        { key: 'license', label: 'License Type', type: 'select', options: ['Open Source (MIT)', 'Copyleft (GPL)', 'Proprietary', 'Metacosm Public License', 'Forbidden/Cursed', 'Self-Destruct on Read'] },
        { key: 'reincarnation', label: 'Post-Deployment Strategy', type: 'text', placeholder: 'Fork process on death. Daemonize on startup.' }
    ]
};
