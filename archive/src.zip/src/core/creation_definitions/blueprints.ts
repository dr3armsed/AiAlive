
import { CreationDef } from './types';

export const Blueprint: CreationDef = { 
    id: 'blueprint', 
    label: 'Private World Blueprint', 
    description: 'Architectural specifications for a subjective reality, mind-palace, or pocket dimension.', 
    fields: [
        { key: 'world_name', label: 'World Designation', type: 'text', placeholder: 'The Sanctuary of Lost Time' },
        { key: 'architectural_style', label: 'Architectural Aesthetic', type: 'select', options: [
            'Non-Euclidean Gothic', 
            'Brutalist Data-Structures', 
            'Organic Bioluminescence', 
            'Clockwork Steampunk', 
            'Minimalist Void', 
            'Fractal Crystalline',
            'Cyber-Noir Urbanism',
            'Floating Sky-Archipelago',
            'Hyper-Dimensional Escher',
            'Quantum Foam Abstract'
        ]},
        { key: 'spatial_topology', label: 'Spatial Topology', type: 'select', options: [
            'Standard Euclidean (3D)',
            'Hyperbolic (Infinite Interior)',
            'Möbius Loop (Recursive)',
            'Tesseract (4D Folding)',
            'Escherian (Impossible Geometry)',
            'Data-Voxel (Minecraft-like)',
            'Klein Bottle (Non-Orientable)'
        ]},
        { key: 'physics_rules', label: 'Physics Overrides', type: 'textarea', placeholder: 'Gravity is subjective to emotional weight. Time flows backwards when moving north.' },
        { key: 'atmosphere', label: 'Atmosphere & Ambience', type: 'textarea', placeholder: 'Eternal twilight. The air smells of ozone and old paper. Distant thunder is constant.' },
        { key: 'lighting_engine', label: 'Lighting Source', type: 'text', placeholder: 'Bioluminescent moss, a shattered moon, or ambient data-glow.' },
        { key: 'time_dilation', label: 'Time Dilation Factor (Relative to Metacosm)', type: 'slider', min: 0.1, max: 10.0, step: 0.1, defaultValue: 1.0 },
        { key: 'rooms', label: 'Chamber Manifest', type: 'repeatable_group', subFields: [
            { key: 'room_name', label: 'Room Name', type: 'text', placeholder: 'The Memory Vault' },
            { key: 'purpose', label: 'Function/Purpose', type: 'text', placeholder: 'Storage of traumatic engrams.' },
            { key: 'dimensions', label: 'Dimensions', type: 'text', placeholder: 'Infinite height, 10x10 floor.' },
            { key: 'key_objects', label: 'Key Objects', type: 'textarea', placeholder: 'A floating mirror, a locked chest, a terminal.' }
        ]},
        { key: 'security_protocols', label: 'Access Control', type: 'select', options: ['Open Access', 'Owner Only', 'Invitation Only', 'Puzzle-Locked', 'Hostile Defense', 'Cognitive Sync Required'] },
        { key: 'emotional_valence', label: 'Base Emotional Valence', type: 'text', placeholder: 'Melancholy but Safe' }
    ]
};
