
import { CreationDef } from './types';

export const Other: CreationDef = { 
    id: 'other', 
    label: 'Other / Freeform Creation', 
    description: 'A wildcard for creating something that defies standard categorization, anomalous objects, or memetic hazards.', 
    fields: [
        { key: 'title', label: 'Title / Designation', type: 'text', placeholder: 'Untitled Experiment 49' },
        { key: 'classification', label: 'Ontological Classification', type: 'select', options: [
            'Conceptual Art', 
            'Algorithm', 
            'Recipe', 
            'Spell / Ritual', 
            'Memetic Virus', 
            'Thoughtform', 
            'Architectural Plan',
            'Unclassifiable',
            'Hyper-Sigil'
        ]},
        { key: 'medium', label: 'Medium / Substrate', type: 'text', placeholder: 'Smoke, Light, Pure Mathematics, Code' },
        { key: 'description', label: 'Detailed Description', type: 'textarea', placeholder: 'Describe exactly what you want to bring into existence. Be specific about its sensory details.' },
        { key: 'intent', label: 'Creative Intent', type: 'textarea', placeholder: 'What is the purpose of this creation? What emotion should it evoke in the viewer?' },
        { key: 'components', label: 'Key Components / Ingredients', type: 'repeatable_group', subFields: [
            { key: 'component', label: 'Component', type: 'text' },
            { key: 'detail', label: 'Detail', type: 'textarea' }
        ]},
        { key: 'hazards', label: 'Potential Hazards', type: 'text', placeholder: 'May cause dizziness or existential dread.' }
    ]
};
