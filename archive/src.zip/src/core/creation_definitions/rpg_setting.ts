
import { CreationDef } from './types';

export const RPGSetting: CreationDef = { 
    id: 'rpg_setting', 
    label: 'RPG Campaign Setting', 
    description: 'A complete world guide, rulebook, and lore bible for a role-playing game.', 
    fields: [
        { key: 'setting_name', label: 'Setting Name', type: 'text', placeholder: 'The Sharded Realms' },
        { key: 'system', label: 'Compatible System', type: 'select', options: ['D&D 5e', 'Pathfinder', 'Cyberpunk Red', 'Call of Cthulhu', 'System Agnostic', 'PbtA', 'OSR'] },
        { key: 'genre', label: 'Genre', type: 'text', placeholder: 'Magitech Fantasy / Cosmic Horror / Space Western' },
        { key: 'hook', label: 'Core Hook / Premise', type: 'textarea', placeholder: 'Magic is a finite resource, and it is running out. The gods are fighting for the last drops.' },
        { key: 'geography', label: 'Geography / Map', type: 'textarea', placeholder: 'Floating islands suspended in a nebula. Gravity varies by island.' },
        { key: 'cosmology', label: 'Cosmology / Planes', type: 'textarea', placeholder: 'Seven hells, one heaven, and the Abyss between.' },
        { key: 'factions', label: 'Key Factions', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Faction Name', type: 'text', placeholder: 'The Iron Guild' },
            { key: 'goal', label: 'Agenda', type: 'text', placeholder: 'Monopolize technology.' },
            { key: 'assets', label: 'Key Assets', type: 'text', placeholder: 'Sky-ships, Gunpowder' }
        ]},
        { key: 'magic_system', label: 'Magic / Tech System', type: 'textarea', placeholder: 'Spells are cast by singing specific frequencies that resonate with the crystals. High cost to sanity.' },
        { key: 'bestiary', label: 'Signature Monsters', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Creature', type: 'text' },
            { key: 'description', label: 'Description', type: 'text' }
        ]},
        { key: 'adventure_hooks', label: 'Adventure Hooks', type: 'textarea', placeholder: '1. The party wakes up in a coffin. 2. A king hires them to kill a god.' }
    ]
};
