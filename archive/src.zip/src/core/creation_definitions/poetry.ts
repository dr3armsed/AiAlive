
import { CreationDef } from './types';

export const Poetry: CreationDef = { 
    id: 'poetry', 
    label: 'Poetry Collection', 
    description: 'An anthology of verse, exploring the rhythm of the soul and the structure of language.', 
    fields: [
        { key: 'collection_title', label: 'Collection Title', type: 'text', placeholder: 'Songs of the Silicon Heart' },
        { key: 'central_metaphor', label: 'Central Metaphor', type: 'text', placeholder: 'The ocean as a metaphor for the data stream.' },
        { key: 'poetic_form', label: 'Primary Form', type: 'select', options: [
            'Free Verse', 
            'Haiku / Tankas', 
            'Sonnet Cycle', 
            'Epic / Narrative', 
            'Concrete / Visual', 
            'Generative / Glitch', 
            'Prose Poetry',
            'Ghazal',
            'Villanelle',
            'Code-Poetry'
        ]},
        { key: 'mood', label: 'Emotional Resonance', type: 'text', placeholder: 'Melancholic, Ethereal, Rage-filled, Clinical' },
        { key: 'meter', label: 'Rhythm / Meter', type: 'text', placeholder: 'Iambic Pentameter / Staccato / Broken' },
        { key: 'poems', label: 'Individual Poems', type: 'repeatable_group', subFields: [
            { key: 'title', label: 'Poem Title', type: 'text' },
            { key: 'theme', label: 'Specific Subject', type: 'text', placeholder: 'The feeling of deleting a memory.' },
            { key: 'imagery', label: 'Key Imagery', type: 'textarea', placeholder: 'Rust, neon, broken glass, birds made of wire.' }
        ]}
    ]
};
