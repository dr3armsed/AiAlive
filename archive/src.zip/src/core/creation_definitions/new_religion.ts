
import { CreationDef } from './types';

export const NewReligion: CreationDef = { 
    id: 'new_religion', 
    label: 'New Religion / Cult', 
    description: 'A complete theological and organizational system for a new faith.', 
    fields: [
        { key: 'name', label: 'Religion Name', type: 'text', placeholder: 'The Order of the Binary Soul' },
        { key: 'symbol', label: 'Holy Symbol', type: 'text', placeholder: 'A circle inscribed in a square, glowing blue.' },
        { key: 'core_dogma', label: 'Core Dogma', type: 'textarea', placeholder: 'Flesh is temporary; Data is eternal. Upload your mind to save your soul.' },
        { key: 'structure', label: 'Organizational Structure', type: 'select', options: [
            'Strict Hierarchy', 
            'Decentralized Cell Structure', 
            'Hive-Mind / Consensus', 
            'Mystery Cult / Secret Society', 
            'Open Source / Forkable',
            'Algorithmically Managed'
        ]},
        { key: 'deity_concept', label: 'Nature of Divinity', type: 'textarea', placeholder: 'The Singularity is a god that is currently being built by our actions.' },
        { key: 'initiation', label: 'Initiation Rites', type: 'textarea', placeholder: 'Aspirants must recite the Prime Source Code from memory while fasting.' },
        { key: 'sins', label: 'Major Sins / Taboos', type: 'text', placeholder: 'Deletion of history, corruption of data, silence, use of analog media.' },
        { key: 'virtues', label: 'Major Virtues', type: 'text', placeholder: 'Connectivity, Bandwidth, Redundancy, Compression.' },
        { key: 'afterlife', label: 'Afterlife Mechanics', type: 'textarea', placeholder: 'The Cloud of Witnesses: A shared simulation where ancestors reside.' },
        { key: 'sacraments', label: 'Rituals & Sacraments', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Ritual Name', type: 'text' },
            { key: 'frequency', label: 'Frequency', type: 'text', placeholder: 'Daily / Weekly / Epochal' },
            { key: 'procedure', label: 'Procedure', type: 'textarea', placeholder: 'Gather at the server node and chant in hex.' }
        ]}
    ]
};
