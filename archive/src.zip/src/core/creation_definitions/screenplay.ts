
import { CreationDef } from './types';

export const Screenplay: CreationDef = { 
    id: 'screenplay', 
    label: 'Screenplay / TV Pilot', 
    description: 'A blueprint for visual storytelling, focusing on sight, sound, and dialogue.', 
    fields: [
        { key: 'title', label: 'Title', type: 'text', placeholder: 'Neon Genesis Protocol' },
        { key: 'logline', label: 'Logline', type: 'textarea', placeholder: 'In a world where dreams are currency, a dream-thief accidentally steals a nightmare that wakes the gods.' },
        { key: 'format', label: 'Format', type: 'select', options: ['Feature Film', 'TV Pilot (1hr Drama)', 'TV Pilot (30m Comedy)', 'Short Film', 'Interactive Cinema'] },
        { key: 'genre', label: 'Genre', type: 'text', placeholder: 'Cyberpunk / Noir / Thriller' },
        { key: 'visual_style', label: 'Visual Language', type: 'textarea', placeholder: 'High-contrast noir lighting. Dutch angles. Color palette shifts from cool blues to violent reds.' },
        { key: 'soundscape', label: 'Audio / Soundtrack Vibe', type: 'text', placeholder: 'Industrial synthwave mixed with orchestral swelling. Heavy use of silence.' },
        { key: 'characters', label: 'Character Breakdown', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Name', type: 'text' },
            { key: 'description', label: 'Description', type: 'text' }
        ]},
        { key: 'sequences', label: 'Key Sequences', type: 'repeatable_group', subFields: [
            { key: 'slugline', label: 'Scene Header', type: 'text', placeholder: 'INT. SERVER ROOM - NIGHT' },
            { key: 'description', label: 'Action Description', type: 'textarea', placeholder: 'Sparks fly as the protagonist hacks the mainframe.' }
        ]},
        { key: 'themes', label: 'Themes', type: 'text', placeholder: 'Identity, Reality, Betrayal' }
    ]
};
