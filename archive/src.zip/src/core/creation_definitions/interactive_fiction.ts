
import { CreationDef } from './types';

export const InteractiveFiction: CreationDef = { 
    id: 'interactive_fiction', 
    label: 'Interactive Fiction / Game', 
    description: 'A branching narrative or text adventure where the reader controls the outcome.', 
    fields: [
        { key: 'title', label: 'Title', type: 'text', placeholder: 'The Labyrinth of Forking Paths' },
        { key: 'engine', label: 'Target Engine', type: 'select', options: ['Twine', 'Ink', 'Inform 7', 'Ren\'Py', 'Custom Parser', 'Metacosm Native'] },
        { key: 'genre', label: 'Genre', type: 'text', placeholder: 'Cosmic Horror / Puzzle' },
        { key: 'premise', label: 'Premise', type: 'textarea', placeholder: 'You wake up in a room with two doors. One leads to the past, one to the future. You remember nothing.' },
        { key: 'mechanics', label: 'Core Mechanics', type: 'text', placeholder: 'Inventory system, Sanity meter, Relationship tracking, Time loop' },
        { key: 'variables', label: 'Global Variables', type: 'text', placeholder: 'health = 100, knowledge = 0, has_key = false' },
        { key: 'nodes', label: 'Story Nodes', type: 'repeatable_group', subFields: [
            { key: 'node_name', label: 'Node ID', type: 'text', placeholder: 'Start_Room' },
            { key: 'content', label: 'Text Content', type: 'textarea', placeholder: 'You see a rusty key on the table. The air smells of ozone.' },
            { key: 'choices', label: 'Choices / Links', type: 'textarea', placeholder: '[[Take Key]] -> Inventory_Add\n[[Leave Room]] -> Hallway\n[[Inspect Mirror]] -> Mirror_Event' },
            { key: 'conditions', label: 'Logic Conditions', type: 'text', placeholder: 'if (has_key) show [[Unlock Door]]' }
        ]},
        { key: 'endings', label: 'Possible Endings', type: 'repeatable_group', subFields: [
            { key: 'ending_name', label: 'Ending Name', type: 'text', placeholder: 'The True Exit' },
            { key: 'condition', label: 'Condition', type: 'text', placeholder: 'knowledge > 90 AND has_key' }
        ]}
    ]
};
