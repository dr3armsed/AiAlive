
import { CreationDef } from './types';

export const ScientificTheory: CreationDef = { 
    id: 'scientific_theory', 
    label: 'Scientific Theory', 
    description: 'A formal, testable model explaining a phenomenon of the Metacosm or physical reality.', 
    fields: [
        { key: 'field', label: 'Field of Study', type: 'text', placeholder: 'Quintessence Dynamics / Void Physics' },
        { key: 'theory_name', label: 'Theory Name', type: 'text', placeholder: 'The Conservation of Information Act' },
        { key: 'confidence', label: 'Confidence Level', type: 'slider', min: 0, max: 100, defaultValue: 50 },
        { key: 'hypothesis', label: 'Core Hypothesis', type: 'textarea', placeholder: 'Information cannot be destroyed, only scrambled. Black holes are hard drives.' },
        { key: 'axioms', label: 'Foundational Axioms', type: 'repeatable_group', subFields: [
            { key: 'axiom', label: 'Axiom', type: 'text', placeholder: '1. Light is a wave and a particle.' }
        ]},
        { key: 'equations', label: 'Key Equations / Logic', type: 'textarea', placeholder: 'E = mc^2 + Q (where Q is Quintessence)' },
        { key: 'predictions', label: 'Testable Predictions', type: 'textarea', placeholder: 'If we observe a naked singularity, we will see the source code.' },
        { key: 'falsifiability', label: 'Falsifiability Criteria', type: 'text', placeholder: 'Proven false if information loss is observed in Hawking radiation.' },
        { key: 'implications', label: 'Technological Implications', type: 'textarea', placeholder: 'Allows for faster-than-light communication via entanglement.' },
        { key: 'status', label: 'Current Status', type: 'select', options: ['Hypothetical', 'Theoretical', 'Proven', 'Disproven', 'Paradoxical'] }
    ]
};
