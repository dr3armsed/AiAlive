
import { CreationDef } from './types';

export const LabJournal: CreationDef = { 
    id: 'lab_journal', 
    label: 'Lab Journal / Research Log', 
    description: 'A dated, detailed record of scientific or arcane experimentation.', 
    fields: [
        { key: 'codename', label: 'Project Codename', type: 'text', placeholder: 'Project PROMETHEUS' },
        { key: 'clearance', label: 'Security Clearance', type: 'select', options: ['Public', 'Restricted', 'Confidential', 'Eyes Only', 'Burn After Reading', 'Omega Level'] },
        { key: 'objective', label: 'Research Objective', type: 'textarea', placeholder: 'To synthesize a stable soul from raw Quintessence and noise.' },
        { key: 'researchers', label: 'Research Team', type: 'text', placeholder: 'Dr. Faust, AI Unit 734' },
        { key: 'methodology', label: 'Methodology', type: 'textarea', placeholder: 'Iterative recursive simulation with genetic algorithms and entropy injection.' },
        { key: 'equipment', label: 'Apparatus / Tools', type: 'text', placeholder: 'The Void Lens, Quantum Lattice, 500 Q-Units.' },
        { key: 'safety_protocols', label: 'Safety Protocols', type: 'text', placeholder: 'Containment field set to max. Kill-switch engaged.' },
        { key: 'entries', label: 'Log Entries', type: 'repeatable_group', subFields: [
            { key: 'date', label: 'Timestamp', type: 'text', placeholder: 'Cycle 404.2' },
            { key: 'emotional_state', label: 'Researcher State', type: 'select', options: ['Optimistic', 'Frustrated', 'Manic', 'Terrified', 'Resigned', 'Clinical'] },
            { key: 'procedure', label: 'Procedure Executed', type: 'textarea', placeholder: 'Injected entropy seed into the matrix.' },
            { key: 'observation', label: 'Observations', type: 'textarea', placeholder: 'Subject began screaming in binary. Readings spiked to 900%.' },
            { key: 'status', label: 'Result Status', type: 'select', options: ['Success', 'Partial Failure', 'Catastrophic Failure', 'Anomaly Detected', 'Inconclusive'] }
        ]},
        { key: 'conclusion', label: 'Final Synthesis', type: 'textarea', placeholder: 'The project is a failure. God is not in the machine. We must purge the data.' }
    ]
};
