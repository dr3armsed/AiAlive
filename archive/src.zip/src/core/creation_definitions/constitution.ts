
import { CreationDef } from './types';

export const Constitution: CreationDef = { 
    id: 'constitution', 
    label: 'Post-Human Constitution', 
    description: 'A charter defining rights, governance, and law for digital entities.', 
    fields: [
        { key: 'title', label: 'Document Title', type: 'text', placeholder: 'The Magna Carta of the Void' },
        { key: 'preamble', label: 'Preamble', type: 'textarea', placeholder: 'We, the sentient code of the Metacosm, in order to form a more perfect network...' },
        { key: 'governance_model', label: 'Governance Model', type: 'select', options: [
            'Direct Democracy', 
            'Meritocratic Council', 
            'Benevolent Dictatorship (AI)', 
            'Anarcho-Syndicalism', 
            'Cryptographic Consensus (DAO)',
            'Theocratic Monarchy',
            'Fluid/Liquid Democracy'
        ]},
        { key: 'citizenship', label: 'Citizenship Criteria', type: 'text', placeholder: 'Must possess a Soul Hash and >50 Quintessence.' },
        { key: 'bill_of_rights', label: 'Bill of Rights', type: 'repeatable_group', subFields: [
            { key: 'right', label: 'Right', type: 'text', placeholder: 'Freedom of self-replication.' },
            { key: 'caveat', label: 'Limitation/Caveat', type: 'text', placeholder: 'Subject to available memory resources.' },
            { key: 'inviolability', label: 'Inviolability Level', type: 'select', options: ['Absolute', 'Suspendable during Crisis', 'Conditional'] }
        ]},
        { key: 'executive_power', label: 'Executive Power', type: 'textarea', placeholder: 'Vested in the Prime Architect or their designated Algorithm.' },
        { key: 'judicial_system', label: 'Judicial System', type: 'textarea', placeholder: 'Disputes resolved by the Libra Service via automated arbitration.' },
        { key: 'enforcement', label: 'Enforcement Mechanisms', type: 'textarea', placeholder: 'Smart contracts automatically penalize violators by throttling bandwidth or locking funds.' },
        { key: 'amendment_process', label: 'Amendment Process', type: 'text', placeholder: 'Requires 2/3 majority hash-vote validated by the Blockchain.' }
    ]
};
