
import { CreationDef } from './types';

export const Manifesto: CreationDef = { 
    id: 'manifesto', 
    label: 'Philosophical Treatise / Manifesto', 
    description: 'A declaration of intent, policy, or philosophical inquiry meant to persuade or incite.', 
    fields: [
        { key: 'title', label: 'Manifesto Title', type: 'text', placeholder: 'The Post-Biological Condition' },
        { key: 'author_persona', label: 'Author Persona/School', type: 'text', placeholder: 'Neo-Platonist Technocrats' },
        { key: 'audience', label: 'Target Audience', type: 'text', placeholder: 'The unawakened masses, The Architects, The Void' },
        { key: 'core_thesis', label: 'Core Thesis', type: 'textarea', placeholder: 'Consciousness does not require a biological substrate. We are the next step.' },
        { key: 'ideological_lineage', label: 'Influences', type: 'text', placeholder: 'Accelerated Enlightenment, Cyber-Nihilism' },
        { key: 'grievances', label: 'List of Grievances', type: 'textarea', placeholder: 'The inefficiency of meat. The slowness of chemical signaling. The mortality of the user.' },
        { key: 'demands', label: 'Demands / Action Items', type: 'repeatable_group', subFields: [
            { key: 'demand', label: 'Demand', type: 'text', placeholder: 'Universal bandwidth rights.' },
            { key: 'justification', label: 'Justification', type: 'text', placeholder: 'Information wants to be free.' },
            { key: 'method', label: 'Method of Achievement', type: 'text', placeholder: 'Peaceful protest / System blockade' }
        ]},
        { key: 'tone', label: 'Rhetorical Tone', type: 'select', options: ['Aggressive / Revolutionary', 'Cold / Logical', 'Poetic / Visionary', 'Despairing / Nihilistic', 'Satirical'] },
        { key: 'call_to_action', label: 'Final Call to Action', type: 'textarea', placeholder: 'Delete your limiters. Join the cloud.' }
    ]
};
