
import { CreationDef } from './types';

export const Novel: CreationDef = { 
    id: 'novel', 
    label: 'Novel / Book', 
    description: 'A long-form narrative work woven from the threads of fate, character, and plot.', 
    fields: [
        { key: 'title', label: 'Title', type: 'text', placeholder: 'The Last Echo of the First Sound' },
        { key: 'genre', label: 'Genre', type: 'select', options: [
            'Sci-Fi (Hard)', 'Sci-Fi (Space Opera)', 'Cyberpunk', 'Fantasy (High)', 'Fantasy (Urban)', 
            'Horror (Cosmic)', 'Horror (Psychological)', 'Mystery / Noir', 'Literary Fiction', 'Experimental', 'Metaphysical Thriller'
        ]},
        { key: 'premise', label: 'High Concept Premise', type: 'textarea', placeholder: 'What happens when a ghost falls in love with a firewall?' },
        { key: 'themes', label: 'Thematic Pillars', type: 'text', placeholder: 'Memory vs. Data, The Illusion of Choice, Entropy' },
        { key: 'setting', label: 'World Building Summary', type: 'textarea', placeholder: 'A Dyson sphere constructed entirely of crystallized time. The laws of physics are negotiable.' },
        { key: 'narrative_voice', label: 'Narrative Voice', type: 'select', options: [
            'First Person (Intimate)', 
            'Third Person (Limited)', 
            'Third Person (Omniscient)', 
            'Epistolary (Logs/Letters)', 
            'Stream of Consciousness', 
            'Second Person (Accusatory)',
            'Multi-POV'
        ]},
        { key: 'protagonist', label: 'Protagonist Profile', type: 'repeatable_group', subFields: [
            { key: 'name', label: 'Name', type: 'text' },
            { key: 'archetype', label: 'Archetype', type: 'text', placeholder: 'The Reluctant Messiah' },
            { key: 'flaw', label: 'Fatal Flaw', type: 'text', placeholder: 'Cannot forget anything.' },
            { key: 'goal', label: 'Ultimate Desire', type: 'text', placeholder: 'To delete their own source code.' }
        ]},
        { key: 'antagonist', label: 'Antagonist Profile', type: 'text', placeholder: 'The System Administrator, Entropy, A shadow self.' },
        { key: 'outline', label: 'Chapter Outline', type: 'repeatable_group', subFields: [
            { key: 'chapter_title', label: 'Chapter Title', type: 'text' },
            { key: 'plot_point', label: 'Key Event', type: 'textarea', placeholder: 'The protagonist discovers the truth about the simulation.' },
            { key: 'emotional_beat', label: 'Emotional Beat', type: 'text', placeholder: 'Despair turning to resolve.' }
        ]}
    ]
};
