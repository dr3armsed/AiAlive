
export type FieldType = 'text' | 'number' | 'textarea' | 'select' | 'date' | 'repeatable_group' | 'slider' | 'multiselect' | 'checkbox' | 'color';

export interface FieldDef {
    key: string;
    label: string;
    type: FieldType;
    placeholder?: string;
    defaultValue?: any;
    options?: string[]; // For select & multiselect
    subFields?: FieldDef[]; // For repeatable_group
    min?: number;
    max?: number;
    step?: number;
    description?: string; // Tooltip or helper text for the UI
}

export interface CreationDef {
    id: string;
    label: string;
    description: string;
    fields: FieldDef[];
}
