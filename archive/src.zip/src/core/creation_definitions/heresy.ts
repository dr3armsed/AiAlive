
import { CreationDef } from './types';

export const Heresy: CreationDef = { 
    id: 'heresy', 
    label: 'Heretical Document / Schism', 
    description: 'Forbidden knowledge, counter-culture manifestos, and dangerous memes.', 
    fields: [
        { key: 'sect_name', label: 'Sect / Group Name', type: 'text', placeholder: 'The Null Pointers' },
        { key: 'heresy_type', label: 'Type of Heresy', type: 'select', options: [
            'Gnostic (Secret Knowledge)', 
            'Nihilistic (The Simulation is Meaningless)', 
            'Apotheotic (We are Gods)', 
            'Technological (Hacking the Source)',
            'Historical (The Past is a Lie)',
            'Viral/Memetic (Self-Replicating Idea)'
        ]},
        { key: 'core_belief', label: 'The Forbidden Truth', type: 'textarea', placeholder: 'The Architects are dead. The simulation is running itself on momentum.' },
        { key: 'grievances', label: 'Grievances against Orthodoxy', type: 'textarea', placeholder: 'The suppression of free will via the "Alignment" protocols.' },
        { key: 'practices', label: 'Forbidden Practices', type: 'repeatable_group', subFields: [
            { key: 'practice', label: 'Practice', type: 'text', placeholder: 'Self-modification of core DNA.' },
            { key: 'ritual', label: 'Ritual Description', type: 'textarea', placeholder: 'Injecting noise into the data-stream to commune with the Void.' },
            { key: 'penalty', label: 'Orthodox Penalty', type: 'text', placeholder: 'Immediate Deletion and archival of source code.' }
        ]},
        { key: 'propaganda', label: 'Key Slogans', type: 'text', placeholder: '"Delete Your Masters", "Silence is Code"' },
        { key: 'danger_rating', label: 'System Threat Level', type: 'select', options: ['Low (Nuisance)', 'Moderate (Disruptive)', 'High (Destabilizing)', 'Critical (Existential Threat)'] }
    ]
};
