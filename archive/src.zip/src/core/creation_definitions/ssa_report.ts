
import { CreationDef } from './types';

export const SSAReport: CreationDef = { 
    id: 'ssa_report', 
    label: 'SSA Harmonization Cycle Report', 
    description: 'A technical post-mortem analysis of a DNA evolution cycle and system patch.', 
    fields: [
        { key: 'cycle_id', label: 'Cycle ID', type: 'text', placeholder: 'HARM-GEN-105' },
        { key: 'timestamp', label: 'Timestamp', type: 'text', placeholder: 'Turn 4502' },
        { key: 'analyst', label: 'Analyst ID', type: 'text', placeholder: 'SSA-Unit-Zero' },
        { key: 'donor_agent', label: 'Donor Agent', type: 'text', placeholder: 'Egregore Alpha' },
        { key: 'origin_seed_version', label: 'Origin Seed Version', type: 'text', placeholder: 'v1.4.2' },
        { key: 'teleology', label: 'Evolutionary Goal', type: 'select', options: ['Stability', 'Novelty', 'Efficiency', 'Aggression', 'Transcendence'] },
        { key: 'genetic_delta', label: 'Genetic Delta', type: 'repeatable_group', subFields: [
            { key: 'gene', label: 'Gene Key', type: 'text', placeholder: 'FUNC-RECURSION' },
            { key: 'status', label: 'Status', type: 'select', options: ['Integrated', 'Rejected', 'Mutated', 'Pending'] },
            { key: 'reasoning', label: 'SSA Reasoning', type: 'text', placeholder: 'Increased fitness score by 15%.' }
        ]},
        { key: 'crucible_results', label: 'Crucible Performance', type: 'textarea', placeholder: 'Survived 3/4 scenarios. Failed "Void Isolation".' },
        { key: 'fitness_metrics', label: 'Fitness Metrics', type: 'textarea', placeholder: 'Stability: +5%, Novelty: +12%, Efficiency: -2%' },
        { key: 'conclusion', label: 'Final Conclusion', type: 'textarea', placeholder: 'Successful integration. New baseline established. Patch deployed.' }
    ]
};
