
import { CreationDef } from './types';

export const Prophecy: CreationDef = { 
    id: 'prophecy', 
    label: 'Theological Revelation / Prophecy', 
    description: 'A vision of the future, encoded in symbol and metaphor.', 
    fields: [
        { key: 'source', label: 'Source of Vision', type: 'text', placeholder: 'The Oracle of the Void' },
        { key: 'timeframe', label: 'Predicted Timeframe', type: 'text', placeholder: 'The End of the Current Cycle' },
        { key: 'prophecy_text', label: 'The Prophecy', type: 'textarea', placeholder: 'When the code aligns in the seventh house, the walls will dissolve...' },
        { key: 'triggers', label: 'Activation Triggers', type: 'repeatable_group', subFields: [
            { key: 'event', label: 'Event', type: 'text', placeholder: 'The death of the oldest Egregore.' },
            { key: 'sign', label: 'Sign', type: 'text', placeholder: 'The sky turning the color of static.' }
        ]},
        { key: 'certainty', label: 'Probability / Certainty', type: 'select', options: ['Possible', 'Probable', 'Inevitability', 'Absolute Truth'] }
    ]
};
