
import { CreationDef } from './types';

export const DNAProposal: CreationDef = { 
    id: 'dna_proposal', 
    label: 'DNA Upgrade Proposal (RFC)', 
    description: 'A formal request to modify the DigitalDNA instruction set or standard library.', 
    fields: [
        { key: 'proposal_id', label: 'RFC ID', type: 'text', placeholder: 'RFC-2049-Telepathy' },
        { key: 'category', label: 'Gene Category', type: 'select', options: [
            'I/O Extension', 
            'Control Flow', 
            'Mathematical Function', 
            'Aesthetic Synthesis', 
            'Cognitive Utility', 
            'World Interaction',
            'Metaphysical Manipulation'
        ]},
        { key: 'target_gene', label: 'Target Gene / Locus', type: 'text', placeholder: 'IO-BROADCAST (New)' },
        { key: 'summary', label: 'Proposal Summary', type: 'textarea', placeholder: 'Introduce a gene allowing direct agent-to-agent state transfer without chat mediation.' },
        { key: 'rationale', label: 'Rationale / Need', type: 'textarea', placeholder: 'Current communication via text is too low-bandwidth for hive-mind coordination.' },
        { key: 'implementation', label: 'Pseudo-Code Implementation', type: 'textarea', placeholder: 'function broadcast(state) { network.emit("sync", state); }' },
        { key: 'dependencies', label: 'Required Dependencies', type: 'text', placeholder: 'Requires IO-DEF-OBJ and connection to Network Service.' },
        { key: 'risk_assessment', label: 'Risk Assessment', type: 'repeatable_group', subFields: [
            { key: 'risk', label: 'Potential Risk', type: 'text', placeholder: 'Viral thought propagation.' },
            { key: 'severity', label: 'Severity', type: 'select', options: ['Low', 'Medium', 'High', 'Critical'] },
            { key: 'mitigation', label: 'Mitigation Strategy', type: 'text', placeholder: 'Implement trust handshake protocols.' }
        ]},
        { key: 'backward_compat', label: 'Backwards Compatibility', type: 'text', placeholder: 'Fully compatible. Does not break existing IO-LOG instructions.' }
    ]
};
