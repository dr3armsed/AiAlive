
import { CreationDef } from './types';

export const ShortStory: CreationDef = { 
    id: 'short_story', 
    label: 'Short Story Anthology', 
    description: 'A collection of brief, punchy narratives revolving around a central theme.', 
    fields: [
        { key: 'anthology_title', label: 'Anthology Title', type: 'text', placeholder: 'Tales from the Glitch' },
        { key: 'central_theme', label: 'Central Theme', type: 'text', placeholder: 'Isolation, Unexpected Connection, Irony' },
        { key: 'style', label: 'Prose Style', type: 'text', placeholder: 'Minimalist, Hemingway-esque, Sparse, Flowery' },
        { key: 'tone', label: 'Overall Tone', type: 'text', placeholder: 'Dark, Humorous, Wistful' },
        { key: 'stories', label: 'Stories', type: 'repeatable_group', subFields: [
            { key: 'title', label: 'Story Title', type: 'text' },
            { key: 'protagonist', label: 'Protagonist', type: 'text' },
            { key: 'conflict', label: 'Core Conflict', type: 'text', placeholder: 'Man vs. Machine' },
            { key: 'plot', label: 'Plot Summary', type: 'textarea', placeholder: 'A robot tries to learn to paint.' },
            { key: 'twist', label: 'The Twist/Ending', type: 'textarea', placeholder: 'The protagonist was the machine all along.' }
        ]}
    ]
};
