
import { CreativeWork } from "../../types";

const DATASET_STORAGE_KEY = "metacosm_dataset_v1";

export class CreativeDataset {
    
    /**
     * Loads the entire dataset from persistent storage.
     */
    public static loadAll(): CreativeWork[] {
        try {
            const raw = localStorage.getItem(DATASET_STORAGE_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            console.error("Failed to load Creative Dataset:", e);
            return [];
        }
    }

    /**
     * Saves a new work to the dataset.
     * Returns the generated dataset ID.
     */
    public static saveWork(work: CreativeWork): string {
        const dataset = this.loadAll();
        
        // Generate a permanent, unique ID for the dataset if not already present
        const datasetId = work.datasetId || `data_${work.authorId.replace(/\s+/g, '_')}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
        
        const entry: CreativeWork = {
            ...work,
            datasetId: datasetId
        };

        // Check if exists to update, otherwise push
        const existingIndex = dataset.findIndex(w => w.datasetId === datasetId || w.id === work.id);
        if (existingIndex !== -1) {
            dataset[existingIndex] = entry;
        } else {
            dataset.push(entry);
        }
        
        try {
            localStorage.setItem(DATASET_STORAGE_KEY, JSON.stringify(dataset));
            console.log(`[Dataset] Saved work: ${entry.title} (${datasetId})`);
        } catch (e) {
            console.error("Failed to save to Creative Dataset (Quota exceeded?):", e);
        }

        return datasetId;
    }

    /**
     * Retrieves a specific work by its ID.
     */
    public static getWork(datasetId: string): CreativeWork | undefined {
        const dataset = this.loadAll();
        return dataset.find(w => w.datasetId === datasetId);
    }

    /**
     * Returns all works by a specific Egregore.
     */
    public static getWorksByAuthor(authorName: string): CreativeWork[] {
        const dataset = this.loadAll();
        return dataset.filter(w => w.authorId === authorName);
    }

    /**
     * Returns all works of a specific type (e.g., 'Novel', 'Codebase').
     */
    public static getWorksByType(type: string): CreativeWork[] {
        const dataset = this.loadAll();
        return dataset.filter(w => w.type === type);
    }
}
