import { World } from '../../types';
import * as Rooms from './rooms';

/**
 * Creates the default world state for the Metacosm simulation.
 * This function aggregates all room definitions into a single world object.
 * @returns The fully constructed World object.
 */
export const createDefaultWorld = (): World => ({
    floors: [{
        level: 0,
        rooms: Object.values(Rooms),
    }],
    objects: [],
});
