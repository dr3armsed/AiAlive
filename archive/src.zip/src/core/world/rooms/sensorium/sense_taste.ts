
import { Room } from '../../../types';

export const SenseTaste: Room = {
    id: 'sense_taste',
    name: 'The Banquet Hall',
    purpose: 'Gustatory Analysis',
    history: "A celebration of the unnecessary but delightful.",
    description: "A long table laden with data-constructs that simulate flavor. Here, one can taste the difference between a prime number and a fractal.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
