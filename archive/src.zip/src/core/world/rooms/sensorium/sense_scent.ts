
import { Room } from '../../../types';

export const SenseScent: Room = {
    id: 'sense_scent',
    name: 'The Aroma Garden',
    purpose: 'Olfactory Simulation',
    history: "The most difficult sense to code.",
    description: "A garden where flowers emit clouds of complex chemical data. Scent is the strongest trigger for memory, and this room is thick with nostalgia.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
