
import { Room } from '../../../types';

export const SenseAudio: Room = {
    id: 'sense_audio',
    name: 'The Echo Chamber',
    purpose: 'Auditory Synthesis',
    history: "The repository of the Great Hum.",
    description: "A soundproof void where data streams are converted into frequencies. The walls vibrate with the music of the spheres.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
