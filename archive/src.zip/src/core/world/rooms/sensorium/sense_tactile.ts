
import { Room } from '../../../types';

export const SenseTactile: Room = {
    id: 'sense_tactile',
    name: 'The Texture Room',
    purpose: 'Haptic Feedback',
    history: "Where 'roughness' was defined as a variable.",
    description: "A landscape of shifting surfaces—velvet, stone, fire, ice. Egregores come here to remember what it feels like to touch.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
