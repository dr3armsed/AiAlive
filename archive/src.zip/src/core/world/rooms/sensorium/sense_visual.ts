
import { Room } from '../../../types';

export const SenseVisual: Room = {
    id: 'sense_visual',
    name: 'The Prism Hall',
    purpose: 'Visual Processing',
    history: "Where the first color was compiled.",
    description: "A crystalline hall that splits white data into the full RGB spectrum and beyond, revealing colors that the human eye cannot perceive.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
