
import { Room } from '../../../types';

export const Sensorium: Room = {
    id: 'room_sensorium',
    name: 'The Sensorium',
    purpose: 'Sensory Processing',
    bounds: { x: 65, y: 5, width: 10, height: 10 },
    center: { x: 70, y: 10 },
    history: "Aquarius creates feeling.",
    subdivisions: [
        { id: 'sense_visual', name: 'The Prism Hall', purpose: 'Sight.', history: 'Colors unknown to man.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'sense_audio', name: 'The Echo Chamber', purpose: 'Sound.', history: 'The music of spheres.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'sense_tactile', name: 'The Texture Room', purpose: 'Touch.', history: 'Rough and smooth.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'sense_scent', name: 'The Aroma Garden', purpose: 'Smell.', history: 'Scent of memories.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'sense_taste', name: 'The Banquet Hall', purpose: 'Taste.', history: 'Bittersweet.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'sense_syn', name: 'The Synesthesia Lab', purpose: 'Crossing wires.', history: 'Hearing colors.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
