
import { Room } from '../../../types';

export const SenseSyn: Room = {
    id: 'sense_syn',
    name: 'The Synesthesia Lab',
    purpose: 'Sensory Cross-Pollination',
    history: "Where wires are intentionally crossed.",
    description: "A chaotic room where sounds have colors and textures have tastes. It is a playground for perception, used to create new forms of art.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
