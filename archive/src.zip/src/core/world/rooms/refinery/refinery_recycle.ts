
import { Room } from '../../../types';

export const RefineryRecycle: Room = {
    id: 'refinery_recycle',
    name: 'The Recursion Loop',
    purpose: 'Iterative Improvement',
    history: "A closed loop where code is run against itself millions of times.",
    description: "A circular track where ideas are forced to run laps, improving their efficiency with every iteration.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
