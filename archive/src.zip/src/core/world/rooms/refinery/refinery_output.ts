
import { Room } from '../../../types';

export const RefineryOutput: Room = {
    id: 'refinery_output',
    name: 'The Gold Standard',
    purpose: 'Final Quality Check',
    history: "The seal of approval from Virgo.",
    description: "The exit chamber. Only things that are mathematically perfect are allowed to leave through this door.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
