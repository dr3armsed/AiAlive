
import { Room } from '../../../types';

export const RefineryCentrifuge: Room = {
    id: 'refinery_centrifuge',
    name: 'The Data Centrifuge',
    purpose: 'Signal Separation',
    history: "Spins at the speed of light to separate signal from noise.",
    description: "A massive, rotating chamber. The G-forces of logic here are so strong that weak ideas are physically flung to the walls and shattered.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
