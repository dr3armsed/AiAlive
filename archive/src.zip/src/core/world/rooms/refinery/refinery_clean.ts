
import { Room } from '../../../types';

export const RefineryClean: Room = {
    id: 'refinery_clean',
    name: 'The Clean Room',
    purpose: 'Sterile Environment',
    history: "A zone of absolute zero entropy.",
    description: "A blindingly white, sterile laboratory. Not a single speck of dust or error exists here. It is used for the assembly of critical system kernels.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
