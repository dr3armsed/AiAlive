
import { Room } from '../../../types';

export const RefineryFilter: Room = {
    id: 'refinery_filter',
    name: 'The Logic Filter',
    purpose: 'Removing Fallacies',
    history: "A mesh of boolean gates that dissolves irrational arguments on contact.",
    description: "A corridor filled with laser-like grids of logic. Passing through it strips away cognitive biases and emotional clouding.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'efficiency_boost', magnitude: 0.2, description: "Reduces Quintessence cost of actions by 20%." }
    ]
} as Room;
