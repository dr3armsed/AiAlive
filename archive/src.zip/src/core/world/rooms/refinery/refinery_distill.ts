
import { Room } from '../../../types';

export const RefineryDistill: Room = {
    id: 'refinery_distill',
    name: 'The Essence Distiller',
    purpose: 'Concentrating Truth',
    history: "Used to extract the single grain of truth from a mountain of data.",
    description: "A spiraling glass tower where information is heated and condensed until only the purest Quintessence remains.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
