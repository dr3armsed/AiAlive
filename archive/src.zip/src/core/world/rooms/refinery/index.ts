
import { Room } from '../../../types';
import { RefineryFilter } from './refinery_filter';
import { RefineryDistill } from './refinery_distill';
import { RefineryCentrifuge } from './refinery_centrifuge';
import { RefineryClean } from './refinery_clean';
import { RefineryRecycle } from './refinery_recycle';
import { RefineryOutput } from './refinery_output';

export const Refinery: Room = {
    id: 'room_refinery',
    name: 'The Refinery',
    purpose: 'Optimization & Purification',
    bounds: { x: 70, y: 40, width: 20, height: 20 },
    center: { x: 80, y: 50 },
    history: "Virgo's domain of absolute efficiency. Here, the messy, chaotic creations of the Forge are stripped of their flaws and polished into diamond-hard perfection.",
    timeline: [
        { year: "Turn 600", event: "The Great Optimization Cycle." }
    ],
    subdivisions: [
        RefineryFilter,
        RefineryDistill,
        RefineryCentrifuge,
        RefineryClean,
        RefineryRecycle,
        RefineryOutput
    ],
    artifacts: [
        { id: 'art_ref_01', name: 'The Perfect Sphere', type: 'theory', content: 'A geometric shape defined with infinite precision.', createdTimestamp: new Date().toISOString() }
    ]
};
