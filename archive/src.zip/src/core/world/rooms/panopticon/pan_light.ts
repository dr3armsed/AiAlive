
import { Room } from '../../../types';

export const PanLight: Room = {
    id: 'pan_light',
    name: 'The Searchlight',
    purpose: 'Illumination of Secrets',
    history: "Used to find the hidden backdoors in the early code.",
    description: "A blinding beam of coherent light that sweeps across the Metacosm. Nothing can remain hidden when the light falls upon it.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
