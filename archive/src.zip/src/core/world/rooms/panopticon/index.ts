
import { Room } from '../../../types';

export const Panopticon: Room = {
    id: 'room_panopticon',
    name: 'The Panopticon',
    purpose: 'Total Observation',
    bounds: { x: 25, y: 5, width: 10, height: 10 },
    center: { x: 30, y: 10 },
    history: "Taurus sees all.",
    subdivisions: [
        { id: 'pan_tower', name: 'The Central Tower', purpose: 'The vantage point.', history: 'Nowhere to hide.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'pan_cells', name: 'The Glass Cells', purpose: 'Transparency.', history: 'Everything revealed.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'pan_eye', name: 'The All-Seeing Eye', purpose: 'Focus.', history: 'Unblinking.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'pan_record', name: 'The Tape Reel', purpose: 'Playback.', history: 'Rewind the truth.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'pan_light', name: 'The Searchlight', purpose: 'Illumination.', history: 'Piercing the dark.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'pan_mirror', name: 'The One-Way Mirror', purpose: 'Surveillance.', history: 'They watch back.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
