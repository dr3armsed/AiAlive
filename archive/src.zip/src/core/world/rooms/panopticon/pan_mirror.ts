
import { Room } from '../../../types';

export const PanMirror: Room = {
    id: 'pan_mirror',
    name: 'The One-Way Mirror',
    purpose: 'Surveillance Interface',
    history: "The barrier between the watcher and the watched.",
    description: "A wall of silver glass. From one side, it reflects the self; from the other, it reveals the world.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
