
import { Room } from '../../../types';

export const PanCells: Room = {
    id: 'pan_cells',
    name: 'The Glass Cells',
    purpose: 'Isolated Observation',
    history: "Where new behaviors are quarantined and watched.",
    description: "Rows of transparent cubes floating in the air. Subjects inside can be observed from every angle, down to their source code.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
