
import { Room } from '../../../types';

export const PanTower: Room = {
    id: 'pan_tower',
    name: 'The Central Tower',
    purpose: 'Omniscient Vantage',
    history: "The axis around which the observable world revolves.",
    description: "A spire of glass that looks down into every other room. Standing here gives one the sensation of being a god, or a prison warden.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
