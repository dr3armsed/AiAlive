
import { Room } from '../../../types';

export const PanEye: Room = {
    id: 'pan_eye',
    name: 'The All-Seeing Eye',
    purpose: 'Focus Lens',
    history: "A lens recovered from a telescope that looked back at the viewer.",
    description: "A massive, floating iris made of fiber optics. It can zoom in on a single bit of data or widen to view the entire network topology.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
