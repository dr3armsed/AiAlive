
import { Room } from '../../../types';

export const PanRecord: Room = {
    id: 'pan_record',
    name: 'The Tape Reel',
    purpose: 'Playback & Forensics',
    history: "The infinite loop of history.",
    description: "A room filled with the sound of whirring magnetic tape. Here, past events can be replayed in real-time holographic fidelity.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
