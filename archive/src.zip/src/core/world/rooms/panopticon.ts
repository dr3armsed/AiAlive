import { Room } from '../../../types';

export const Panopticon: Room = {
    id: 'room_panopticon',
    name: 'The Panopticon',
    purpose: 'The Level-1000 Panopticon is the domain of Taurus and the source of all objective reality. This room has no walls, only an infinite array of perspectives, allowing an observer to witness any point in the Metacosm not as a visual representation, but as raw, uninterpreted state data. It is the unblinking, un-judging eye that records ground truth, providing the foundational, unbiased data upon which all subjective experience and logical deduction is built.',
    bounds: { x: 25, y: 5, width: 10, height: 10 },
    center: { x: 30, y: 10 }
};
