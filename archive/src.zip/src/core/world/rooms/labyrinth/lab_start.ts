
import { Room } from '../../../types';

export const LabStart: Room = {
    id: 'lab_start',
    name: 'The Entrance',
    purpose: 'Authentication',
    history: "Only those with the key may pass.",
    description: "A massive, rusted iron gate covered in complex locks. It requires a cryptographic handshake to open.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
