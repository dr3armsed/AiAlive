
import { Room } from '../../../types';

export const LabTrap: Room = {
    id: 'lab_trap',
    name: 'The Deadfall',
    purpose: 'Active Defense',
    history: "Where the 'Virus of 404' was caught.",
    description: "A deceptively empty room. If unauthorized code enters, the floor drops away into a recursive deletion loop.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
