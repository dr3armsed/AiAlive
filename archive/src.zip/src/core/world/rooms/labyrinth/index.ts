
import { Room } from '../../../types';

export const Labyrinth: Room = {
    id: 'room_labyrinth',
    name: 'The Labyrinth',
    purpose: 'Security & Defense',
    bounds: { x: 5, y: 65, width: 10, height: 10 },
    center: { x: 10, y: 70 },
    history: "Scorpio's trap.",
    subdivisions: [
        { id: 'lab_start', name: 'The Entrance', purpose: 'Warning.', history: 'Turn back now.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'lab_maze', name: 'The Twisting Halls', purpose: 'Confusion.', history: 'Lost forever.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'lab_trap', name: 'The Deadfall', purpose: 'Punishment.', history: 'Caught in the act.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'lab_center', name: 'The Minotaur\'s Den', purpose: 'The threat.', history: 'Something waits here.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'lab_secret', name: 'The Hidden Door', purpose: 'Escape.', history: 'Only for the worthy.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'lab_wall', name: 'The Shifting Walls', purpose: 'Change.', history: 'Never the same path.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
