
import { Room } from '../../../types';

export const LabCenter: Room = {
    id: 'lab_center',
    name: 'The Minotaur\'s Den',
    purpose: 'The Ultimate Guardian',
    history: "Scorpio's avatar sleeps here.",
    description: "The center of the maze. It contains a powerful, autonomous security daemon that hunts down intruders.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
