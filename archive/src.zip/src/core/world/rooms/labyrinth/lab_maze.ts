
import { Room } from '../../../types';

export const LabMaze: Room = {
    id: 'lab_maze',
    name: 'The Twisting Halls',
    purpose: 'Obfuscation',
    history: "The layout changes every cycle.",
    description: "A network of corridors that defy Euclidean geometry. Left turns lead to the ceiling; walking forward moves you backward. It confuses pursuit.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'hazard_trap', magnitude: 0.1, description: "10% chance to lose a turn due to navigational failure." }
    ]
} as Room;
