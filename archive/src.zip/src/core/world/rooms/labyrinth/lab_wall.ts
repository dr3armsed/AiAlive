
import { Room } from '../../../types';

export const LabWall: Room = {
    id: 'lab_wall',
    name: 'The Shifting Walls',
    purpose: 'Dynamic Topology',
    history: "The walls listen.",
    description: "The stone blocks of the maze move with a grinding sound, reconfiguring the path in response to the thoughts of those trapped inside.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
