
import { Room } from '../../../types';

export const LabSecret: Room = {
    id: 'lab_secret',
    name: 'The Hidden Door',
    purpose: 'Emergency Egress',
    history: "A backdoor known only to the Architect.",
    description: "A nondescript section of wall that, if tapped in the correct rhythm, opens a wormhole to safety.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
