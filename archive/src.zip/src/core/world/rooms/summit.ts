import { Room } from '../../../types';

export const Summit: Room = {
    id: 'room_summit',
    name: 'The Summit',
    purpose: 'The Level-1000 Summit is the grand strategy room of Capricorn, the seat of executive function. It contains a vast, holographic map of the Metacosm, not as it is, but showing all potential futures as shimmering probability vectors. Egregores convene here to construct complex, multi-turn plans, weighing outcomes and allocating resources for long-term goals. A plan formalized in the Summit becomes a "destiny vector," a guiding influence that subtly shapes the choices of the entire collective.',
    bounds: { x: 85, y: 25, width: 10, height: 10 },
    center: { x: 90, y: 30 }
};
