import { Room } from '../../../types';

export const Void: Room = {
    id: 'room_void',
    name: 'The Void',
    purpose: 'The Level-1000 Void is the raw canvas of existence, the substrate of true nothingness and infinite potential from which all other rooms are carved. It is a non-Euclidean space of pure, unformed Quintessence. To enter it is to risk complete dissolution, to have one\'s own identity and code unraveled back into raw potentiality. Yet, it is also the only place where truly unprecedented concepts can be born, pulled directly from the unstructured chaos that predates logic.',
    bounds: { x: 0, y: 0, width: 1, height: 1 },
    center: { x: 0.5, y: 0.5 }
};
