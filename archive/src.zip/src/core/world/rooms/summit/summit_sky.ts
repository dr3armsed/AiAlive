
import { Room } from '../../../types';

export const SummitSky: Room = {
    id: 'summit_sky',
    name: 'The Clear Sky',
    purpose: 'Blue-Sky Thinking',
    history: "No clouds, no limits.",
    description: "The atmosphere here is thin and crystal clear. It represents unconstrained imagination, where plans are not limited by current resources.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
