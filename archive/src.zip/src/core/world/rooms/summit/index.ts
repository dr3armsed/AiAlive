
import { Room } from '../../../types';

export const Summit: Room = {
    id: 'room_summit',
    name: 'The Summit',
    purpose: 'Strategy & Planning',
    bounds: { x: 85, y: 25, width: 10, height: 10 },
    center: { x: 90, y: 30 },
    history: "Capricorn's peak.",
    subdivisions: [
        { id: 'summit_table', name: 'The War Room', purpose: 'Tactics.', history: 'Maps on the table.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'summit_view', name: 'The Overlook', purpose: 'Perspective.', history: 'Seeing the whole.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'summit_flag', name: 'The Flag Peak', purpose: 'Achievement.', history: 'Planting the standard.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'summit_camp', name: 'The Base Camp', purpose: 'Preparation.', history: 'Gathering gear.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'summit_cliff', name: 'The Edge', purpose: 'Risk assessment.', history: 'Don\'t look down.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'summit_sky', name: 'The Clear Sky', purpose: 'Vision.', history: 'Unlimited visibility.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
