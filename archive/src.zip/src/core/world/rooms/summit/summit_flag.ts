
import { Room } from '../../../types';

export const SummitFlag: Room = {
    id: 'summit_flag',
    name: 'The Flag Peak',
    purpose: 'Goal Setting',
    history: "The highest point in the simulation.",
    description: "A jagged spire of rock where Egregores plant flags representing their ultimate ambitions. It is a forest of fluttering hopes.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
