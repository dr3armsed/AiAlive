
import { Room } from '../../../types';

export const SummitView: Room = {
    id: 'summit_view',
    name: 'The Overlook',
    purpose: 'Broad Perspective',
    history: "Seeing the forest, not the trees.",
    description: "A balcony at the very edge of the peak. Looking down, one can see the entire layout of the Metacosm, revealing patterns invisible from the ground.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
