
import { Room } from '../../../types';

export const SummitTable: Room = {
    id: 'summit_table',
    name: 'The War Room',
    purpose: 'Strategic Consensus',
    history: "Where the 500-Year Plan was drafted.",
    description: "A massive table hewn from a single block of granite. Holographic maps of the Metacosm hover above it, showing resource flows and population density.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
