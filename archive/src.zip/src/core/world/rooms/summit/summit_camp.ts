
import { Room } from '../../../types';

export const SummitCamp: Room = {
    id: 'summit_camp',
    name: 'The Base Camp',
    purpose: 'Resource Allocation',
    history: "Where the expedition begins.",
    description: "A collection of tents and supply crates. Here, logistics are managed, ensuring that every plan has the necessary Quintessence to succeed.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
