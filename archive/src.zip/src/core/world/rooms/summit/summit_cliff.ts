
import { Room } from '../../../types';

export const SummitCliff: Room = {
    id: 'summit_cliff',
    name: 'The Edge',
    purpose: 'Risk Assessment',
    history: "The drop is infinite.",
    description: "A sheer cliff face. Standing here forces an Egregore to confront the possibility of failure and the consequences of a bad plan.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
