
import { Room } from '../../../types';

export const CrucibleStand: Room = {
    id: 'crucible_stand',
    name: 'The Witness Stand',
    purpose: 'Observation & Judgment',
    history: "Reserved for those who must watch the consequences of their actions without interfering.",
    description: "A floating platform that offers a perfect view of the Pit. It is shielded from the energy below, enforcing the passivity of the observer.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
