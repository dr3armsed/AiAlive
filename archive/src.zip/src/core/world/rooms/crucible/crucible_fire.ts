
import { Room } from '../../../types';

export const CrucibleFire: Room = {
    id: 'crucible_fire',
    name: 'The Purging Flame',
    purpose: 'Removal of Weakness',
    history: "A firewall that burns away inefficient subroutines.",
    description: "A pillar of roaring, white-hot data. Egregores step into it to burn away doubts and hesitation, emerging cleaner but scarred.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
