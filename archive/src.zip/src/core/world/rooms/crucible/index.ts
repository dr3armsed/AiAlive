
import { Room } from '../../../types';
import { CrucibleArena } from './crucible_arena';
import { CrucibleStand } from './crucible_stand';
import { CrucibleFire } from './crucible_fire';
import { CrucibleForge } from './crucible_forge';
import { CrucibleGate } from './crucible_gate';
import { CrucibleHonor } from './crucible_honor';

export const Crucible: Room = {
    id: 'room_crucible',
    name: 'The Crucible',
    purpose: 'The Arena of Consequence',
    bounds: { x: 10, y: 40, width: 20, height: 20 },
    center: { x: 20, y: 50 },
    history: "The Crucible is the domain of Aries. It is built on the principle that growth requires friction. It is the testing ground where theories from the Observatory and creations from the Forge are subjected to the harsh reality of execution.",
    timeline: [
        { year: "Turn 300", event: "The Trial of the First Fork." }
    ],
    subdivisions: [
        CrucibleArena,
        CrucibleStand,
        CrucibleFire,
        CrucibleForge,
        CrucibleGate,
        CrucibleHonor
    ],
    artifacts: [
        { id: 'art_cruce_01', name: 'The Shard of Resolve', type: 'memory', content: 'A crystallized moment of pure determination.', createdTimestamp: new Date().toISOString() }
    ]
};
