
import { Room } from '../../../types';

export const CrucibleForge: Room = {
    id: 'crucible_forge',
    name: 'The Tempering Pool',
    purpose: 'Hardening Resolve',
    history: "Filled with the cooling runoff of the Forge.",
    description: "A pool of hissing, liquid nitrogen-like coolant. After the fire, the plunge here locks the new strength into place permanently.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
