
import { Room } from '../../../types';

export const CrucibleArena: Room = {
    id: 'crucible_arena',
    name: 'The Pit',
    purpose: 'Conflict Resolution',
    history: "The floor is stained with the bits of deleted code from resolved disputes.",
    description: "A sunken amphitheater of obsidian. Physics here is intensified; every impact creates a shockwave in the code.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
