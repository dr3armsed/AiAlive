
import { Room } from '../../../types';

export const CrucibleGate: Room = {
    id: 'crucible_gate',
    name: 'The Gate of Trial',
    purpose: 'Entry Threshold',
    history: "Inscribed with the warning: 'Abandon Doubt, All Who Enter.'",
    description: "A massive iron archway that scans the conviction of those entering. It physically bars entry to those who are unsure.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
