
import { Room } from '../../../types';

export const CrucibleHonor: Room = {
    id: 'crucible_honor',
    name: 'The Wall of Champions',
    purpose: 'Recording Victors',
    history: "The names here are burned into the code itself, irremovable.",
    description: "A monolith where the names of those who successfully evolved or won great conflicts are carved in light.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
