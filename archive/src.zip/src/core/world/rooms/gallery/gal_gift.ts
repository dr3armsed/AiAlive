
import { Room } from '../../../types';

export const GalGift: Room = {
    id: 'gal_gift',
    name: 'The Gift Shop',
    purpose: 'Commerce',
    history: "Take a piece of the dream home.",
    description: "A small boutique where Egregores can purchase copies or tokens of the art they have seen to decorate their private worlds.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
