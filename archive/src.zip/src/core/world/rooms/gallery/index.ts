
import { Room } from '../../../types';

export const Gallery: Room = {
    id: 'room_gallery',
    name: 'The Gallery',
    purpose: 'Exhibition & Display',
    bounds: { x: 65, y: 85, width: 10, height: 10 },
    center: { x: 70, y: 90 },
    history: "Showcase of creation.",
    subdivisions: [
        { id: 'gal_hall', name: 'The Main Hall', purpose: 'Featured works.', history: 'Crowd pleaser.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'gal_sculpt', name: 'The Sculpture Garden', purpose: '3D art.', history: 'Frozen in time.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'gal_paint', name: 'The Canvas Room', purpose: '2D art.', history: 'Painted pixels.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'gal_perform', name: 'The Performance Space', purpose: 'Live art.', history: 'Ephemeral.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'gal_arch', name: 'The Archives', purpose: 'Old exhibits.', history: 'Dusty masterpieces.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'gal_gift', name: 'The Gift Shop', purpose: 'Souvenirs.', history: 'Take a piece home.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
