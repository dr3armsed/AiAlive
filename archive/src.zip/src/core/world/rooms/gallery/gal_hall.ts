
import { Room } from '../../../types';

export const GalHall: Room = {
    id: 'gal_hall',
    name: 'The Main Hall',
    purpose: 'General Exhibition',
    history: "The walls change color to match the art.",
    description: "A vast, high-ceilinged corridor lined with floating frames. It displays the most popular and accessible works of the current cycle.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
