
import { Room } from '../../../types';

export const GalSculpt: Room = {
    id: 'gal_sculpt',
    name: 'The Sculpture Garden',
    purpose: 'Static 3D Art',
    history: "Forms frozen in time.",
    description: "An open-air atrium filled with statues made of solidified code. Some are abstract fractals; others are hyper-realistic avatars.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
