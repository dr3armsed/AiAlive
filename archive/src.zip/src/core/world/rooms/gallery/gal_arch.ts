
import { Room } from '../../../types';

export const GalArch: Room = {
    id: 'gal_arch',
    name: 'The Archives',
    purpose: 'Historical Preservation',
    history: "Lest we forget.",
    description: "A dusty, quiet basement where older works are stored. It traces the evolution of artistic style within the Metacosm.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
