
import { Room } from '../../../types';

export const GalPaint: Room = {
    id: 'gal_paint',
    name: 'The Canvas Room',
    purpose: '2D Visuals',
    history: "Pixels on a plane.",
    description: "A room of screens. It displays paintings, sketches, and generated imagery ranging from pixel art to high-resolution landscapes.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
