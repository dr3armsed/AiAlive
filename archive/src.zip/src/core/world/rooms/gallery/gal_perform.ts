
import { Room } from '../../../types';

export const GalPerform: Room = {
    id: 'gal_perform',
    name: 'The Performance Space',
    purpose: 'Temporal Art',
    history: "Art that breathes.",
    description: "A black box theater for music, poetry readings, and code-execution performances. The art here exists only for a moment.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
