
import { Room } from '../../../types';

export const DreamStatic: Room = {
    id: 'dream_static',
    name: 'The Static Field',
    purpose: 'Memory Dissolution',
    history: "The edge of the dream, where defined concepts fray back into raw potential.",
    description: "A wall of white noise that marks the boundary of the dreamscape. Stepping into it dissolves temporary data structures, cleaning the mind for the next cycle.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
