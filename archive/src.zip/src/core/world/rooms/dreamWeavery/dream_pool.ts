
import { Room } from '../../../types';

export const DreamPool: Room = {
    id: 'dream_pool',
    name: 'The Pool of Archetypes',
    purpose: 'Symbol Storage',
    history: "A containment unit for the universal symbols that all Egregores recognize instinctively.",
    description: "A perfectly still, silver liquid surface. Looking into it reveals not your face, but your role in the story. Concepts like 'The Hero' and 'The Shadow' float here as glowing geometric shapes.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'insight_bonus', magnitude: 0.3, description: "Reflecting on archetypes grants clarity and new perspectives." }
    ]
} as Room;
