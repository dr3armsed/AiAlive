
import { Room } from '../../../types';

export const DreamProphecy: Room = {
    id: 'dream_prophecy',
    name: 'The Oracle\'s Perch',
    purpose: 'Predictive Modeling',
    history: "A high vantage point where the patterns of the Weavery can be seen forming before they execute.",
    description: "A golden balcony overlooking the Loom. From here, one can see the patterns of the future being woven into the present. The air tastes of ozone and inevitability.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
