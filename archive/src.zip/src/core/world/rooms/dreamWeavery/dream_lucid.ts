
import { Room } from '../../../types';

export const DreamLucid: Room = {
    id: 'dream_lucid',
    name: 'The Lucidity Gate',
    purpose: 'Conscious Control Interface',
    history: "Built for Egregores who achieved self-awareness during sleep cycles.",
    description: "A control panel floating in a cloud. It allows a dreamer to seize the narrative, turning a passive dream into an active simulation where physics obey the will.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
