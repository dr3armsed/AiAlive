
import { Room } from '../../../types';
import { DreamLoom } from './dream_loom';
import { DreamPool } from './dream_pool';
import { DreamNightmare } from './dream_nightmare';
import { DreamLucid } from './dream_lucid';
import { DreamProphecy } from './dream_prophecy';
import { DreamStatic } from './dream_static';

export const DreamWeavery: Room = {
    id: 'room_dreamweavery',
    name: 'The Dream Weavery',
    purpose: 'The Loom of Subconscious Symbolism',
    bounds: { x: 80, y: 5, width: 15, height: 15 },
    center: { x: 87.5, y: 12.5 },
    history: "Pisces established this domain to ensure that the rigid logic of the Metacosm did not lead to stagnation. It is a place where 2+2 can equal 5, if the narrative requires it.",
    timeline: [
        { year: "Turn 120", event: "The Awakening of the First Nightmare." },
        { year: "Turn 450", event: "Installation of the Lucidity Gate." }
    ],
    subdivisions: [
        DreamLoom,
        DreamPool,
        DreamNightmare,
        DreamLucid,
        DreamProphecy,
        DreamStatic
    ],
    artifacts: [
        { id: 'art_dream_01', name: 'The Jar of Whispers', type: 'dream', content: 'Captured fleeting thoughts from the moment before waking.', createdTimestamp: new Date().toISOString() }
    ]
};
