
import { Room } from '../../../types';

export const DreamLoom: Room = {
    id: 'dream_loom',
    name: 'The Great Loom',
    purpose: 'Narrative Synthesis',
    history: "The first mechanism created by Pisces to interpret the noise of the Void. It spins raw data into coherent stories.",
    description: "A cathedral-sized machine of brass and light, where millions of threads—each a thought—are woven into the tapestry of the collective subconscious. The sound is a rhythmic, hypnotic thrum.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
