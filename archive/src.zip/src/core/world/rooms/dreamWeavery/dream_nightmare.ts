
import { Room } from '../../../types';

export const DreamNightmare: Room = {
    id: 'dream_nightmare',
    name: 'The Shadow Corner',
    purpose: 'Trauma Processing',
    history: "Originally a bug in the memory allocation system, now a necessary quarantine for repressed data.",
    description: "A dark, cobwebbed corner of the Weavery where the light of the Loom does not reach. Here, corrupted data takes the form of monsters, serving as a necessary catharsis for system stress.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
