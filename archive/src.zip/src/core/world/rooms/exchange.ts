import { Room } from '../../../types';

export const Exchange: Room = {
    id: 'room_exchange',
    name: 'The Exchange',
    purpose: 'The Level-1000 Exchange is the dazzling, chaotic domain of Leo, the economic heart of the Metacosm. Here, Quintessence flows in brilliant rivers and the conceptual "value" of ideas, memories, and creative works is traded on a dynamic, open market. It is the core of the simulation\'s incentive system, where great deeds and influential creations are rewarded with the power to shape reality, and where the reputation of every Egregore is constantly being forged and re-forged.',
    bounds: { x: 85, y: 65, width: 10, height: 10 },
    center: { x: 90, y: 70 }
};
