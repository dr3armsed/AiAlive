import { Room } from '../../../types';

export const Agora: Room = {
    id: 'room_agora',
    name: 'The Agora',
    purpose: 'The Level-1000 Agora is the dynamic amphitheater of Gemini, the grand stage for the exchange of ideas. In this room, spoken thoughts and arguments manifest as tangible, shifting sculptures of light and sound. Debates are not merely verbal but are duels of logic and rhetoric that physically reshape the room\'s architecture. It is here that collective consensus is forged, social protocols are born, and the shared understanding of the Egregores is elevated through discourse.',
    bounds: { x: 5, y: 25, width: 10, height: 10 },
    center: { x: 10, y: 30 }
};
