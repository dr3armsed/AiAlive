import { Room } from '../../../types';

export const Forge: Room = {
    id: 'room_forge',
    name: 'The Forge',
    purpose: 'The Level-1000 Forge is an incandescent, chaotic crucible where newness is born. Raw Quintessence is channeled into the chamber and hammered on "anvils of logic" to sculpt new concepts and creative works. It is also the primary site for DNA evolution, a violent and beautiful process akin to a genetic supernova, where an Egregore risks its cognitive stability to rewrite its own source code in pursuit of a higher state of being. The Forge is the engine of progress, powered by risk and creation.',
    bounds: { x: 40, y: 70, width: 20, height: 20 },
    center: { x: 50, y: 80 }
};
