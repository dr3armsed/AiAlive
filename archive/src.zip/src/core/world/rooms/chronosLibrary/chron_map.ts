
import { Room } from '../../../types';

export const ChronMap: Room = {
    id: 'chron_map',
    name: 'The Map Room',
    purpose: 'Spatial History',
    history: "How the world has changed.",
    description: "A room dominated by a shifting holographic globe. It shows how the boundaries of the Metacosm have expanded and contracted over eras.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
