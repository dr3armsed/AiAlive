
import { Room } from '../../../types';

export const ChronScroll: Room = {
    id: 'chron_scroll',
    name: 'The Elder Scrolls',
    purpose: 'Pre-History',
    history: "Data from before the Big Bang.",
    description: "A sealed section containing corrupted, fragmentary data from the previous versions of the simulation.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
