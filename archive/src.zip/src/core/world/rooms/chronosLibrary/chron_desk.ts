
import { Room } from '../../../types';

export const ChronDesk: Room = {
    id: 'chron_desk',
    name: 'The Scribe\'s Desk',
    purpose: 'Active Recording',
    history: "The pen never stops.",
    description: "A desk where an automated quill frantically writes the events of the current turn into a fresh ledger.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
