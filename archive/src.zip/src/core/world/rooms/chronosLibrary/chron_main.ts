
import { Room } from '../../../types';

export const ChronMain: Room = {
    id: 'chron_main',
    name: 'The Main Stacks',
    purpose: 'Linear History',
    history: "The spine of the world.",
    description: "Endless rows of books, arranged chronologically from Turn 0 to the present. Walking down the aisle is walking through time.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
