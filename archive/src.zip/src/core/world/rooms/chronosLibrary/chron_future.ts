
import { Room } from '../../../types';

export const ChronFuture: Room = {
    id: 'chron_future',
    name: 'The Prognostication Room',
    purpose: 'Speculative History',
    history: "Pages that rewrite themselves.",
    description: "A room full of books with blank pages that fill with text as you watch, describing possible futures based on current probability vectors.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
