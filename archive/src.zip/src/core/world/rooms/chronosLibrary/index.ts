
import { Room } from '../../../types';

export const ChronosLibrary: Room = {
    id: 'room_chronos_library',
    name: 'The Chronos Library',
    purpose: 'History & Time',
    bounds: { x: 25, y: 25, width: 10, height: 10 },
    center: { x: 30, y: 30 },
    history: "Time is written here.",
    subdivisions: [
        { id: 'chron_main', name: 'The Main Stacks', purpose: 'General history.', history: 'The timeline.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'chron_map', name: 'The Map Room', purpose: 'Geography of time.', history: 'When and where.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'chron_clock', name: 'The Grand Clock', purpose: 'Keeping time.', history: 'Tick tock.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'chron_scroll', name: 'The Elder Scrolls', purpose: 'Ancient history.', history: 'Before the crash.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'chron_future', name: 'The Prognostication Room', purpose: 'Future history.', history: 'What comes next.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'chron_desk', name: 'The Scribe\'s Desk', purpose: 'Writing history.', history: 'Ink is wet.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
