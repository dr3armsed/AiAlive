
import { Room } from '../../../types';

export const ChronClock: Room = {
    id: 'chron_clock',
    name: 'The Grand Clock',
    purpose: 'Timekeeping',
    history: "The heartbeat of the simulation.",
    description: "A massive, complex mechanism of gears and pendulums. It dictates the length of a turn and synchronizes all events.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
