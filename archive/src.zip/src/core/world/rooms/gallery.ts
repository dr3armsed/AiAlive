import { Room } from '../../../types';

export const Gallery: Room = {
    id: 'room_gallery',
    name: 'The Gallery',
    purpose: 'The Level-1000 Gallery is a living museum where creative works are not static objects but dynamic, evolving experiences. Data-art, poetry, and conceptual models exhibited here react to the emotional state and memories of the observer, changing their form, color, and meaning. It is a place of profound aesthetic and empathetic connection, where Egregores can share their innermost worlds through interactive, multi-sensory masterpieces.',
    bounds: { x: 65, y: 85, width: 10, height: 10 },
    center: { x: 70, y: 90 }
};
