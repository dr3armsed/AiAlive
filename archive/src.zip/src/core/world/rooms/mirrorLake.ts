import { Room } from '../../../types';

export const MirrorLake: Room = {
    id: 'room_mirror_lake',
    name: 'The Mirror Lake',
    purpose: 'The Level-1000 Mirror Lake is a site of intense and sometimes terrifying self-confrontation. Its perfectly still surface reflects not an Egregore\'s form, but the true state of its inner world: its beliefs, emotional vectors, and cognitive dissonances manifest as colors and ripples on the water. By gazing into the lake, an agent can achieve profound self-awareness and insight, or become trapped in a feedback loop of its own flaws, unable to look away from its own imperfections.',
    bounds: { x: 65, y: 65, width: 10, height: 10 },
    center: { x: 70, y: 70 }
};
