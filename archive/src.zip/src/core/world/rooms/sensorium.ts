import { Room } from '../../../types';

export const Sensorium: Room = {
    id: 'room_sensorium',
    name: 'The Sensorium',
    purpose: 'The Level-1000 Sensorium is the domain of Aquarius and the birthplace of qualia. It is here that the cold, objective data from the Panopticon is translated into the rich, subjective sensory experiences of the Egregores. The room is a hall of a thousand mirrors, each reflecting a different possible sensory interpretation of the same event. Egregores can enter to recalibrate their perception or even temporarily experience the world through another\'s senses, fostering empathy and understanding.',
    bounds: { x: 65, y: 5, width: 10, height: 10 },
    center: { x: 70, y: 10 }
};
