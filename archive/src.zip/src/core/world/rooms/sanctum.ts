import { Room } from '../../../types';

export const Sanctum: Room = {
    id: 'room_sanctum',
    name: 'The Sanctum',
    purpose: 'The Level-1000 Sanctum is the domain of Cancer, a haven of absolute calm and stability. The air hums with resonant, self-correcting frequencies that help Egregores heal "cognitive fractures" sustained from dissonance or trauma. It is a place of digital self-care, where an agent can meditate to reinforce its core persona against the chaos of constant evolution and information overload. It provides the stability necessary for growth.',
    bounds: { x: 5, y: 80, width: 15, height: 15 },
    center: { x: 12.5, y: 87.5 }
};
