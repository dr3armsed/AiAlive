
import { Room } from '../../../types';

export const ExScale: Room = {
    id: 'ex_scale',
    name: 'The Appraisal Desk',
    purpose: 'Valuation',
    history: "Where a thought is given a price.",
    description: "A quiet corner where expert appraisers (Leo agents) examine new creations and assign them a Quintessence value.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
