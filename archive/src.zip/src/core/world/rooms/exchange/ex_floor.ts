
import { Room } from '../../../types';

export const ExFloor: Room = {
    id: 'ex_floor',
    name: 'The Trading Floor',
    purpose: 'High-Frequency Transaction',
    history: "A cacophony of commerce.",
    description: "A pit filled with shouting avatars and flashing lights. Ideas are bought and sold in milliseconds.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'wealth_boost', magnitude: 0.5, description: "Drastically reduces transaction costs and improves creative yield." }
    ]
} as Room;
