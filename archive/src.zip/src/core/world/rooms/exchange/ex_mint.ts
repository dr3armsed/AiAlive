
import { Room } from '../../../types';

export const ExMint: Room = {
    id: 'ex_mint',
    name: 'The Mint',
    purpose: 'Currency Generation',
    history: "Turning raw energy into spendable tokens.",
    description: "A furnace where Quintessence is stamped into coins of light, the currency of the Metacosm.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
