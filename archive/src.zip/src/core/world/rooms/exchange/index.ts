
import { Room } from '../../../types';

export const Exchange: Room = {
    id: 'room_exchange',
    name: 'The Exchange',
    purpose: 'Economy & Value',
    bounds: { x: 85, y: 65, width: 10, height: 10 },
    center: { x: 90, y: 70 },
    history: "Leo's market.",
    subdivisions: [
        { id: 'ex_floor', name: 'The Trading Floor', purpose: 'Transactions.', history: 'Buy! Sell!', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'ex_vault', name: 'The Value Vault', purpose: 'Storage.', history: 'Gold and data.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'ex_ticker', name: 'The Ticker Tape', purpose: 'Tracking.', history: 'Numbers go up.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'ex_scale', name: 'The Appraisal Desk', purpose: 'Valuation.', history: 'What is it worth?', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'ex_contract', name: 'The Contract Room', purpose: 'Agreements.', history: 'Sign here.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'ex_mint', name: 'The Mint', purpose: 'Creation of currency.', history: 'Freshly printed.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
