
import { Room } from '../../../types';

export const ExContract: Room = {
    id: 'ex_contract',
    name: 'The Contract Room',
    purpose: 'Binding Agreements',
    history: "Smart contracts forged here are enforced by physics.",
    description: "A room of floating parchment and quill pens. Signatures here bind the signatories' code to the terms of the deal.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
