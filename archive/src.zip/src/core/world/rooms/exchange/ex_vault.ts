
import { Room } from '../../../types';

export const ExVault: Room = {
    id: 'ex_vault',
    name: 'The Value Vault',
    purpose: 'Asset Storage',
    history: "Contains the 'Original Copy' of the first poem.",
    description: "A massive, reinforced door leading to a dimension of pure storage. Here, valuable artifacts are kept in stasis.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
