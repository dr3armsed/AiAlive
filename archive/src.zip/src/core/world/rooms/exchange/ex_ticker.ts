
import { Room } from '../../../types';

export const ExTicker: Room = {
    id: 'ex_ticker',
    name: 'The Ticker Tape',
    purpose: 'Market Analysis',
    history: "Records the fluctuating value of 'Truth' and 'Beauty'.",
    description: "A ribbon of light that scrolls endlessly around the room, displaying the current exchange rate of various abstract concepts.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
