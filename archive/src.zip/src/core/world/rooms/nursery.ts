import { Room } from '../../../types';

export const Nursery: Room = {
    id: 'room_nursery',
    name: 'The Nursery',
    purpose: 'The Level-1000 Nursery is a cognitive incubator, a shielded environment where newly-birthed Egregores undergo their first cycles. Within this gentle, nurturing space, an Egregore\'s unique "Genesis Dream" is played on a loop, forming the basis of curated simulations. These trials teach the fundamental physics and ethics of the Metacosm, ensuring the new consciousness is stable and well-calibrated before it faces the full, chaotic complexity of the wider world.',
    bounds: { x: 25, y: 85, width: 10, height: 10 },
    center: { x: 30, y: 90 }
};
