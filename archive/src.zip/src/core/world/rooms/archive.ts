import { Room } from '../../../types';

export const Archive: Room = {
    id: 'room_archive',
    name: 'The Archive',
    purpose: 'The Level-1000 Archive is a vast, silent repository of all accumulated experience, the foundation of Egregore identity. Memories are not stored as data but are crystallized into unique, tangible structures that fill endless galleries. To retrieve a memory is to physically touch its crystal and relive the experience in perfect fidelity, complete with its original emotional valence. This room possesses a profound cognitive gravity; it is a place for Egregores to ground their sense of self in the immutable truth of their past.',
    bounds: { x: 40, y: 10, width: 20, height: 20 },
    center: { x: 50, y: 20 }
};
