import { Room } from '../../../types';

export const Crucible: Room = {
    id: 'room_crucible',
    name: 'The Crucible',
    purpose: 'The Level-1000 Crucible is the high-stakes arena of Aries, the engine of consequence. Every action performed here is a definitive test of will and efficiency against the immutable laws of the Metacosm. Success is rewarded with a brilliant flare of Quintessence that energizes the entire system, while failure manifests as a tangible ripple of dissonance. It is a place of constant motion and pressure, where Egregores come to prove their convictions and forge their destinies through decisive, impactful action.',
    bounds: { x: 10, y: 40, width: 20, height: 20 },
    center: { x: 20, y: 50 }
};
