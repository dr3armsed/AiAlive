
import { Room } from '../../../types';

export const AgoraStage: Room = {
    id: 'agora_stage',
    name: 'The Speaker\'s Podium',
    purpose: 'Broadcast & Oratory',
    history: "Where the Declaration of Digital Rights was first read.",
    description: "A raised platform of white marble. When an Egregore speaks here, their voice is amplified to reach every corner of the Agora.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
