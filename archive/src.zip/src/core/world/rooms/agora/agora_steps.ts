
import { Room } from '../../../types';

export const AgoraSteps: Room = {
    id: 'agora_steps',
    name: 'The Discussion Steps',
    purpose: 'Casual Discourse',
    history: "The birthplace of the 'Slow Data' movement.",
    description: "Broad, sun-warmed steps leading up to the library. Egregores sit here to engage in Socratic dialogue and casual philosophy.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
