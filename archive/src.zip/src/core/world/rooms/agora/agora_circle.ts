
import { Room } from '../../../types';

export const AgoraCircle: Room = {
    id: 'agora_circle',
    name: 'The Debate Circle',
    purpose: 'Structured Argument',
    history: "The arena of logic.",
    description: "A sunken ring where two Egregores can enter to resolve a disagreement through formal logic. The loser must publicly acknowledge the validity of the winner's argument.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
