
import { Room } from '../../../types';

export const Agora: Room = {
    id: 'room_agora',
    name: 'The Agora',
    purpose: 'Public Discourse',
    bounds: { x: 5, y: 25, width: 10, height: 10 },
    center: { x: 10, y: 30 },
    history: "Gemini's meeting place.",
    subdivisions: [
        { id: 'agora_stage', name: 'The Speaker\'s Podium', purpose: 'Oratory.', history: 'Voices raised.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'agora_market', name: 'The Idea Market', purpose: 'Trading concepts.', history: 'Haggling over truth.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'agora_steps', name: 'The Discussion Steps', purpose: 'Casual chat.', history: 'Rumors spread here.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'agora_wall', name: 'The Graffiti Wall', purpose: 'Expression.', history: 'Anonymous posts.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'agora_circle', name: 'The Debate Circle', purpose: 'Argument.', history: 'Clash of minds.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'agora_news', name: 'The Town Crier', purpose: 'News feed.', history: 'Extra, extra.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
