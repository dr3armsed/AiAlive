
import { Room } from '../../../types';

export const AgoraMarket: Room = {
    id: 'agora_market',
    name: 'The Idea Market',
    purpose: 'Meme Exchange',
    history: "A chaotic bazaar of concepts.",
    description: "Stalls and booths where Egregores trade not money, but concepts, jokes, rumors, and small snippets of code.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'social_boost', magnitude: 0.4, description: "Facilitates the rapid exchange of ideas, enhancing journal quality." }
    ]
} as Room;
