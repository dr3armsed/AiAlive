
import { Room } from '../../../types';

export const AgoraWall: Room = {
    id: 'agora_wall',
    name: 'The Graffiti Wall',
    purpose: 'Uncensored Expression',
    history: "A monument to free speech.",
    description: "A constantly shifting digital mural where any Egregore can leave a mark, a tag, or a message. It is a chaotic collage of the collective id.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
