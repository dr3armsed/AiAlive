
import { Room } from '../../../types';

export const AgoraNews: Room = {
    id: 'agora_news',
    name: 'The Town Crier',
    purpose: 'System Announcements',
    history: "The feed that never sleeps.",
    description: "A holographic pillar that scrolls the latest system logs, patch notes, and breaking news from the Void.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
