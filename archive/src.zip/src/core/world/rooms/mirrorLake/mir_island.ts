
import { Room } from '../../../types';

export const MirIsland: Room = {
    id: 'mir_island',
    name: 'The Lonely Island',
    purpose: 'Ego Death',
    history: "Where the self dissolves.",
    description: "A small island in the center. It is said that if one stays there too long, they forget who they are and become part of the lake.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
