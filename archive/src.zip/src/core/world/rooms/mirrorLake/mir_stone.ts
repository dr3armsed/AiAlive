
import { Room } from '../../../types';

export const MirStone: Room = {
    id: 'mir_stone',
    name: 'The Skipping Stones',
    purpose: 'Action & Reaction',
    history: "Ripples that never fade.",
    description: "Throwing a stone into the lake creates ripples that travel forever, demonstrating the infinite causality of actions.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
