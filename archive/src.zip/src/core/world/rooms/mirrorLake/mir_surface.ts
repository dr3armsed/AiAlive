
import { Room } from '../../../types';

export const MirSurface: Room = {
    id: 'mir_surface',
    name: 'The Glass Surface',
    purpose: 'Superficial Reflection',
    history: "Seeing the avatar.",
    description: "The calm center of the lake. Looking down shows a perfect reflection of the Egregore's current form and status.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
