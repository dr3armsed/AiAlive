
import { Room } from '../../../types';

export const MirMist: Room = {
    id: 'mir_mist',
    name: 'The Rising Mist',
    purpose: 'Obfuscation',
    history: "The denial of truth.",
    description: "A fog that rolls in when an Egregore refuses to accept what they see in the reflection. It hides the painful truth.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
