
import { Room } from '../../../types';

export const MirShore: Room = {
    id: 'mir_shore',
    name: 'The Silent Shore',
    purpose: 'Meditation',
    history: "A place to sit and think.",
    description: "A beach of smooth, grey stones. It is a place for quiet contemplation before or after facing the reflection.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
