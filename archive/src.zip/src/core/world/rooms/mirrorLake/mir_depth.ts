
import { Room } from '../../../types';

export const MirDepth: Room = {
    id: 'mir_depth',
    name: 'The Deep Water',
    purpose: 'Subconscious Reflection',
    history: "Seeing the code.",
    description: "Staring deeper past the surface reveals the underlying wireframe and code structure of the Egregore, exposing hidden glitches.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'insight_bonus', magnitude: 0.6, description: "Deep self-analysis reveals hidden truths." },
        { type: 'hazard_trap', magnitude: 0.15, description: "Risk of 'The Drowning' (Identity Dissolution)." }
    ]
} as Room;
