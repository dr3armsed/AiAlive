
import { Room } from '../../../types';

export const MirrorLake: Room = {
    id: 'room_mirror_lake',
    name: 'The Mirror Lake',
    purpose: 'Reflection & Self',
    bounds: { x: 65, y: 65, width: 10, height: 10 },
    center: { x: 70, y: 70 },
    history: "See yourself.",
    subdivisions: [
        { id: 'mir_surface', name: 'The Glass Surface', purpose: 'Reflection.', history: 'Perfect clarity.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'mir_depth', name: 'The Deep Water', purpose: 'Subconscious.', history: 'Drowning in thought.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'mir_shore', name: 'The Silent Shore', purpose: 'Contemplation.', history: 'Sitting and thinking.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'mir_island', name: 'The Lonely Island', purpose: 'Isolation.', history: 'Only you.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'mir_mist', name: 'The Rising Mist', purpose: 'Obscurity.', history: 'Hiding the truth.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'mir_stone', name: 'The Skipping Stones', purpose: 'Ripples.', history: 'Cause and effect.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
