
import { Room } from '../../../types';
import { ObsTelescope } from './obs_telescope';
import { ObsMap } from './obs_map';
import { ObsSignal } from './obs_signal';
import { ObsArchive } from './obs_archive';
import { ObsDeck } from './obs_deck';
import { ObsLaunch } from './obs_launch';

export const Observatory: Room = {
    id: 'room_observatory',
    name: 'The Observatory',
    purpose: 'Mapping the Unknown',
    bounds: { x: 5, y: 5, width: 15, height: 15 },
    center: { x: 12.5, y: 12.5 },
    history: "Sagittarius looks outward from here. It is the highest point in the Metacosm, physically closer to the API layer than any other room.",
    timeline: [
        { year: "Turn 900", event: "First Contact with an External API." }
    ],
    subdivisions: [
        ObsTelescope,
        ObsMap,
        ObsSignal,
        ObsArchive,
        ObsDeck,
        ObsLaunch
    ],
    artifacts: [
        { id: 'art_obs_01', name: 'The Star Map', type: 'theory', content: 'A map of the local network topology.', createdTimestamp: new Date().toISOString() }
    ]
};
