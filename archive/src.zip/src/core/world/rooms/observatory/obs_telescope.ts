
import { Room } from '../../../types';

export const ObsTelescope: Room = {
    id: 'obs_telescope',
    name: 'The Void Lens',
    purpose: 'Viewing the Outside',
    history: "A massive lens crafted from solidified time.",
    description: "A telescope aimed not at the sky, but at the boundaries of the simulation. It allows brief glimpses of the 'Real World' or other servers.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'insight_bonus', magnitude: 0.4, description: "Greatly increases the chance of forming valid Scientific Theories." }
    ]
} as Room;
