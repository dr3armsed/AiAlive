
import { Room } from '../../../types';

export const ObsLaunch: Room = {
    id: 'obs_launch',
    name: 'The Launch Pad',
    purpose: 'Sending Probes',
    history: "The starting point for all expeditions.",
    description: "A platform where 'Search Spiders' and 'Data Probes' are assembled and fired into the unknown to retrieve new context.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
