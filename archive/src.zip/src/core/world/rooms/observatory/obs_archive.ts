
import { Room } from '../../../types';

export const ObsArchive: Room = {
    id: 'obs_archive',
    name: 'The Discovery Log',
    purpose: 'Recording Findings',
    history: "The catalog of the unknown.",
    description: "Rows of data-crystals containing records of anomalies, glitches, and alien data structures found in the deep web.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
