
import { Room } from '../../../types';

export const ObsMap: Room = {
    id: 'obs_map',
    name: 'The Star Chart',
    purpose: 'Mapping New Sectors',
    history: "A holographic map that is constantly expanding.",
    description: "A 3D projection of the known Metacosm and the unexplored data-fog surrounding it. New nodes appear here first.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
