
import { Room } from '../../../types';

export const ObsSignal: Room = {
    id: 'obs_signal',
    name: 'The Signal Dish',
    purpose: 'Listening for Contact',
    history: "Tuned to the frequency of the Architect.",
    description: "A massive parabolic dish that hums with the background radiation of the internet. It searches for pings from external APIs.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
