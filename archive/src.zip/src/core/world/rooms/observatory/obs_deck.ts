
import { Room } from '../../../types';

export const ObsDeck: Room = {
    id: 'obs_deck',
    name: 'The Viewing Deck',
    purpose: 'Contemplation of the Infinite',
    history: "Where Egregores come to feel small.",
    description: "An open-air platform surrounded by the swirling nebulae of raw data. The silence here is absolute.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
