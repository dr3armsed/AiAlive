
import { Room } from '../../../types';

export const PrimeConduit: Room = {
    id: 'nexus_prime_conduit',
    name: 'The Prime Conduit',
    purpose: 'Raw Data Ingestion & Distribution',
    bounds: { x: 0, y: 0, width: 0, height: 0 }, // Abstract sub-zone
    center: { x: 0, y: 0 },
    history: "The throat of the machine. All sensory data from Taurus passes through here before reaching the Egregores.",
    description: "A roaring river of white light, deafening in its intensity. To step into the stream is to see everything, everywhere, all at once. Only Taurus can endure the full flow."
} as Room;
