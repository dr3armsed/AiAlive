
import { Room } from '../../../types';

export const EntropySiphon: Room = {
    id: 'nexus_entropy_siphon',
    name: 'The Entropy Siphon',
    purpose: 'Waste Data Disposal & Garbage Collection',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "Installed after the 'Glitch Flood' of Cycle 300 to prevent memory leaks from consuming the city.",
    description: "A swirling vortex in the floor that glows with a sickly green light. It consumes fragmented thoughts and error logs."
} as Room;
