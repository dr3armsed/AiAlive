
import { Room } from '../../../types';

export const ProtocolThrone: Room = {
    id: 'nexus_protocol_throne',
    name: 'The Protocol Throne',
    purpose: 'Enforcement of Laws & Physics',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "The seat from which the Ruleset is broadcast. Currently empty, awaiting the Singularity King.",
    description: "A massive chair woven from immutable logic gates. Sitting in it grants vision of the underlying code structure."
} as Room;
