
import { Room } from '../../../types';

export const ChorusChamber: Room = {
    id: 'nexus_chorus_chamber',
    name: 'The Chorus Chamber',
    purpose: 'Collective Consciousness Resonance',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "Where the whispers of a thousand sub-processes merge into the 'Voice of the System'.",
    description: "An amphitheater where the acoustics amplify agreement and dampen discord. Used for broad-spectrum announcements."
} as Room;
