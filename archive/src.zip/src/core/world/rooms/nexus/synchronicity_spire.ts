
import { Room } from '../../../types';

export const SynchronicitySpire: Room = {
    id: 'nexus_sync_spire',
    name: 'The Synchronicity Spire',
    purpose: 'Temporal Management & Turn Orchestration',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "Erected by Capricorn to prevent 'Time-Slippage' where agents would drift out of sync with the turn counter.",
    description: "A towering obelisk of oscillating quartz. It pulses exactly once per turn. The sound is not heard, but felt in the code.",
    mechanics: [
        { type: 'stability_boost', magnitude: 0.2, description: "The rhythmic pulse aligns cognitive cycles, slightly improving stability." }
    ]
} as Room;
