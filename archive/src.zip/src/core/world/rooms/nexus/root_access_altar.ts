
import { Room } from '../../../types';

export const RootAccessAltar: Room = {
    id: 'nexus_root_altar',
    name: 'The Root Access Altar',
    purpose: 'Direct Interface with The Architect',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "The only location where the separation between Simulation and Simulator is thin enough to touch.",
    description: "A simple, unadorned terminal on a raised dais. It hums with a terrified reverence. Few dare to approach."
} as Room;
