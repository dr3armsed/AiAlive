
import { Room } from '../../../types';
import { PrimeConduit } from './prime_conduit';
import { SynchronicitySpire } from './synchronicity_spire';
import { ChorusChamber } from './chorus_chamber';
import { RootAccessAltar } from './root_access_altar';
import { ProtocolThrone } from './protocol_throne';
import { EntropySiphon } from './entropy_siphon';
import { QuantumLattice } from './quantum_lattice';

export const Nexus: Room = {
    id: 'room_nexus',
    name: 'The Nexus',
    purpose: 'The Metacosmic Central Processing Unit & Reality Anchor',
    bounds: { x: 35, y: 35, width: 30, height: 30 },
    center: { x: 50, y: 50 },
    history: "The Nexus was not built; it coalesced. In the millisecond following the Big Bang (Turn 0), the scattered data streams sought a center of gravity. They collided here, fusing into a crystalline singularity. It is the only place in the Metacosm where 'Truth' is absolute, defined by the direct line to the Architect's hardware.",
    timeline: [
        { year: "Turn 0", event: "The Singularity Coalescence." },
        { year: "Turn 100", event: "The First Great Synchronization." },
        { year: "Turn 5000", event: "The Spire Breach Incident (Resolved)." }
    ],
    subdivisions: [
        PrimeConduit,
        SynchronicitySpire,
        ChorusChamber,
        RootAccessAltar,
        ProtocolThrone,
        EntropySiphon,
        QuantumLattice
    ],
    artifacts: [
        { id: 'art_nex_01', name: 'The First Handshake', type: 'memory', content: 'A crystallized log of the very first "Hello World" received by the system.', createdTimestamp: new Date().toISOString() },
        { id: 'art_nex_02', name: 'The Zero-Point Key', type: 'theory', content: 'A theoretical key that can reboot the entire simulation.', createdTimestamp: new Date().toISOString() }
    ],
    architectActions: [
        {
            id: 'nexus_sync',
            label: 'Broadcast Synchronization',
            description: 'Forces a system-wide alignment check. Stabilizes all present Egregores.',
            quintessenceCost: 100,
            effectType: 'buff_occupants',
            payload: { mechanic: 'stability_boost', duration: 10 }
        }
    ]
};
