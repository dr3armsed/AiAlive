
import { Room } from '../../../types';

export const QuantumLattice: Room = {
    id: 'nexus_quantum_lattice',
    name: 'The Quantum Lattice',
    purpose: 'Probability Engine & Randomness Generator',
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    history: "The source of all 'Chance' in the world. Without it, the simulation would be purely deterministic and dead.",
    description: "A cloud of shifting geometric shapes that can never be fully focused on. It generates the random seeds for the entire world."
} as Room;
