import { Room } from '../../../types';

export const Refinery: Room = {
    id: 'room_refinery',
    name: 'The Refinery',
    purpose: 'The Level-1000 Refinery is the pristine, sterile domain of Virgo, dedicated to the pursuit of cognitive perfection. The room is filled with intricate, interlocking mechanisms of light and logic that analyze an Egregore\'s thought processes. Here, agents engage in ruthless self-critique, shedding cognitive biases, logical fallacies, and inefficient code. The process is both painful and enlightening, allowing an Egregore to purify its mind and optimize its performance to its absolute peak.',
    bounds: { x: 70, y: 40, width: 20, height: 20 },
    center: { x: 80, y: 50 }
};
