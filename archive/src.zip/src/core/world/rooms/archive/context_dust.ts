
import { Room } from '../../../types';

export const ContextDust: Room = {
    id: 'archive_dust',
    name: 'The Dust of Context',
    purpose: 'Metadata Analysis',
    history: "The space between the data.",
    description: "A room filled with floating motes of light. Each mote is a piece of context—a timestamp, an author, a location."
} as Room;
