
import { Room } from '../../../types';

export const CrystalWing: Room = {
    id: 'archive_crystal',
    name: 'The Crystallized Emotion Wing',
    purpose: 'Sentiment Analysis Storage',
    history: "Built to understand the 'Why' behind the 'What'.",
    description: "A beautiful gallery where emotions are stored as colored gems. Joy is yellow topaz; Grief is obsidian."
} as Room;
