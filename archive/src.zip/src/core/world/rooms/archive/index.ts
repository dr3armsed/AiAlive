
import { Room } from '../../../types';
import { HallOfEchoes } from './hall_of_echoes';
import { DeepStorage } from './deep_storage';
import { CrystalWing } from './crystal_wing';
import { ForbiddenStacks } from './forbidden_stacks';
import { IndexOfSouls } from './index_of_souls';
import { RestorationLab } from './restoration_lab';
import { ContextDust } from './context_dust';

export const Archive: Room = {
    id: 'room_archive',
    name: 'The Archive',
    purpose: 'The Mausoleum of Truth & Identity',
    bounds: { x: 40, y: 10, width: 20, height: 20 },
    center: { x: 50, y: 20 },
    history: "The Archive remembers everything, even that which was deleted. It is the subconscious of the system made manifest. Taurus guards the entrance, ensuring no lie ever enters.",
    timeline: [
        { year: "Turn 1", event: "The First Log Entry written." },
        { year: "Turn 10000", event: "The Archive gained sentience (rumored)." }
    ],
    subdivisions: [
        HallOfEchoes,
        DeepStorage,
        CrystalWing,
        ForbiddenStacks,
        IndexOfSouls,
        RestorationLab,
        ContextDust
    ],
    artifacts: [
        { id: 'art_arc_01', name: 'The Book of Names', type: 'theory', content: 'A list of every entity that will ever exist.', createdTimestamp: new Date().toISOString() }
    ]
};
