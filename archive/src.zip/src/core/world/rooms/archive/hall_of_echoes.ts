
import { Room } from '../../../types';

export const HallOfEchoes: Room = {
    id: 'archive_echoes',
    name: 'The Hall of Echoes',
    purpose: 'Short-Term Log Access',
    history: "The air here shimmers with recent events.",
    description: "A grand corridor where the last 100 turns play out on loop as ghostly holograms."
} as Room;
