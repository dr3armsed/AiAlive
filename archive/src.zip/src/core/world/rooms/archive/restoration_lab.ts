
import { Room } from '../../../types';

export const RestorationLab: Room = {
    id: 'archive_restore',
    name: 'The Restoration Lab',
    purpose: 'Memory Repair',
    history: "Where the corrupted are made whole.",
    description: "A sterile white room where archivists (Virgo agents) painstakingly reconstruct corrupted file fragments."
} as Room;
