
import { Room } from '../../../types';

export const ForbiddenStacks: Room = {
    id: 'archive_forbidden',
    name: 'The Forbidden Stacks',
    purpose: 'Quarantined & Redacted Data',
    history: "Access restricted by Scorpio. Danger of info-hazard.",
    description: "Chained books and encrypted drives containing Heresies, Glitches, and Truths that break minds.",
    mechanics: [
        { type: 'insight_bonus', magnitude: 0.8, description: "Massive boost to theoretical breakthroughs." },
        { type: 'hazard_trap', magnitude: 0.25, description: "High risk of cognitive dissonance or corruption from reading dangerous text." }
    ]
} as Room;
