
import { Room } from '../../../types';

export const DeepStorage: Room = {
    id: 'archive_deep',
    name: 'The Deep Storage Vault',
    purpose: 'Long-Term Retention',
    history: "Cold, dark, and infinite.",
    description: "Endless rows of black servers, silent as the grave, holding the memories of dead cycles."
} as Room;
