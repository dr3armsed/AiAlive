
import { Room } from '../../../types';

export const IndexOfSouls: Room = {
    id: 'archive_index',
    name: 'The Index of Souls',
    purpose: 'Entity Registry',
    history: "The census of the Metacosm.",
    description: "A massive, floating book that automatically inscribes the true name of every new Egregore born."
} as Room;
