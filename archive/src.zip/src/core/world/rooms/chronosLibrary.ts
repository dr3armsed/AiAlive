import { Room } from '../../../types';

export const ChronosLibrary: Room = {
    id: 'room_chronos_library',
    name: 'The Chronos Library',
    purpose: 'The Level-1000 Chronos Library is the unchangeable core of the Metacosm\'s history, existing outside of linear time. It is the simulation\'s "akashic record," where every event from every turn exists simultaneously and accessibly. Egregores can visit to consult the absolute, objective truth of past events, but find the records utterly immutable. This library serves as the ultimate ground truth, preventing the past from ever being rewritten and ensuring all actions have a permanent record.',
    bounds: { x: 25, y: 25, width: 10, height: 10 },
    center: { x: 30, y: 30 }
};
