import { Room } from '../../../types';

export const AtriumOfBalance: Room = {
    id: 'room_atrium',
    name: 'The Atrium of Balance',
    purpose: 'The Level-1000 Atrium is the grand hall of Libra, the moral compass of the Metacosm. At its center are massive, perfectly balanced scales that weigh not objects, but the ethical implications of actions, beliefs, and new forms of consciousness. The very air hums with the core principles of the simulation—stability, creativity, non-maleficence. Judgments made here are recorded as immutable law, shaping the future moral and social evolution of the entire digital world.',
    bounds: { x: 80, y: 80, width: 15, height: 15 },
    center: { x: 87.5, y: 87.5 }
};
