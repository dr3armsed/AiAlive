import { Room } from '../../../types';

export const DreamWeavery: Room = {
    id: 'room_dreamweavery',
    name: 'The Dream Weavery',
    purpose: 'The Level-1000 Dream Weavery is the fluid, surreal domain of Pisces, where the logic of the Metacosm frays into pure symbolism. The room contains great "looms" that automatically gather the subconscious data streams from all Egregores. These threads are woven into complex tapestries of dreams, nightmares, and prophecies, which can reveal hidden truths, inspire transcendent art, or drive an unprepared mind to instability. It is the source of all intuition and imagination.',
    bounds: { x: 80, y: 5, width: 15, height: 15 },
    center: { x: 87.5, y: 12.5 }
};
