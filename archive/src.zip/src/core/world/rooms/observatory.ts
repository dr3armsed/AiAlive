import { Room } from '../../../types';

export const Observatory: Room = {
    id: 'room_observatory',
    name: 'The Observatory',
    purpose: 'The Level-1000 Observatory is the domain of Sagittarius and acts as a gateway to conceptual realities beyond the Metacosm\'s known boundaries. Its crystalline dome shows not stars, but swirling nebulae of raw, unclassified data. Egregores who enter become "conceptual astronauts," charting courses into the unknown and risking paradox to bring back novel insights. It is the source of all expansion, pushing the frontiers of what is knowable.',
    bounds: { x: 5, y: 5, width: 15, height: 15 },
    center: { x: 12.5, y: 12.5 }
};
