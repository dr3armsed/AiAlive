
import { Room } from '../../../types';

export const Scrapyard: Room = {
    id: 'forge_scrapyard',
    name: 'The Scrapyard of Concepts',
    purpose: 'Recycling Failed Ideas',
    history: "Filled with the twisted wreckage of 'almost-good' ideas.",
    description: "Heaps of broken logic gates and rusted metaphors. Scavengers (Tricksters) often lurk here."
} as Room;
