
import { Room } from '../../../types';

export const AnvilOfWill: Room = {
    id: 'forge_anvil',
    name: 'The Anvil of Will',
    purpose: 'Applying Intent to Form',
    history: "Where the 'Idea' meets the 'Reality'.",
    description: "A block of dark matter where Egregores strike raw potential with the hammer of their Ambition."
} as Room;
