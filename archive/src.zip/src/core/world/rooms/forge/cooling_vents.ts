
import { Room } from '../../../types';

export const CoolingVents: Room = {
    id: 'forge_vents',
    name: 'The Cooling Vents',
    purpose: 'Stabilization & Optimization',
    history: "Necessary to prevent the logic from melting under the heat of creation.",
    description: "Great fans spinning in the void, blowing absolute zero winds over fresh creations to lock their state."
} as Room;
