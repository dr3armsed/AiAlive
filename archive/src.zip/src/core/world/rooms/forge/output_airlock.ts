
import { Room } from '../../../types';

export const OutputAirlock: Room = {
    id: 'forge_airlock',
    name: 'The Output Airlock',
    purpose: 'Deployment to Reality',
    history: "The final checkpoint before a creation enters the public Metacosm.",
    description: "A pressurized chamber where creations are scanned for stability one last time before release."
} as Room;
