
import { Room } from '../../../types';

export const AssemblyLine: Room = {
    id: 'forge_assembly',
    name: 'The Assembly Line of Form',
    purpose: 'Structuring & Compiling',
    history: "Where the chaotic components are bolted together into a usable Product.",
    description: "A rhythmic, automated conveyor belt where robotic arms (subroutines) attach UI elements and logic blocks."
} as Room;
