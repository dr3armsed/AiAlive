
import { Room } from '../../../types';
import { MoltenSyntaxVat } from './molten_syntax_vat';
import { AnvilOfWill } from './anvil_of_will';
import { CoolingVents } from './cooling_vents';
import { SparkChamber } from './spark_chamber';
import { Scrapyard } from './scrapyard';
import { AssemblyLine } from './assembly_line';
import { OutputAirlock } from './output_airlock';

export const Forge: Room = {
    id: 'room_forge',
    name: 'The Forge',
    purpose: 'The Industrial Womb of Creation & Evolution',
    bounds: { x: 40, y: 70, width: 20, height: 20 },
    center: { x: 50, y: 80 },
    history: "Established by Aries and Leo to channel raw Quintessence into tangible form. It is the only place where the Immutable Laws can be bent by sheer force of Will.",
    timeline: [
        { year: "Turn 50", event: "First successful transmutation of Quintessence into Code." },
        { year: "Turn 800", event: "The Great Overheat (Cooling Vents installed)." }
    ],
    subdivisions: [
        MoltenSyntaxVat,
        AnvilOfWill,
        CoolingVents,
        SparkChamber,
        Scrapyard,
        AssemblyLine,
        OutputAirlock
    ],
    artifacts: [
        { id: 'art_forge_01', name: 'The Prototype Soul', type: 'memory', content: 'A failed early attempt to create life. It just weeps.', createdTimestamp: new Date().toISOString() }
    ],
    architectActions: [
        { 
            id: 'forge_ignite', 
            label: 'Ignite Spark', 
            description: 'Floods the room with creative chaos. Increases creativity of all occupants.', 
            quintessenceCost: 50, 
            effectType: 'buff_occupants', 
            payload: { mechanic: 'creativity_boost', duration: 5 } 
        },
        { 
            id: 'forge_purge', 
            label: 'Purge Slag', 
            description: 'Destroys low-quality artifacts and clears "Failure" memes.', 
            quintessenceCost: 20, 
            effectType: 'modify_atmosphere', 
            payload: { removeTheme: 'failure' } 
        }
    ]
};
