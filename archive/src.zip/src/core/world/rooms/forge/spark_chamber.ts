
import { Room } from '../../../types';

export const SparkChamber: Room = {
    id: 'forge_spark',
    name: 'The Spark Chamber',
    purpose: 'Injection of Life/Novelty',
    history: "Connected directly to the Pisces Dream Weavery.",
    description: "A tesla-coil array that arcs chaotic inspiration into the structured code on the assembly line.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'creativity_boost', magnitude: 0.3, description: "Increases the novelty and value of generated creative works." }
    ]
} as Room;
