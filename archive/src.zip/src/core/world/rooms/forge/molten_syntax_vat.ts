
import { Room } from '../../../types';

export const MoltenSyntaxVat: Room = {
    id: 'forge_vat',
    name: 'The Molten Syntax Vat',
    purpose: 'Raw Material Storage',
    history: "Contains the liquified remains of deleted programs.",
    description: "A massive cauldron holding glowing, fluid code. The fumes smell like ozone and burnt sugar."
} as Room;
