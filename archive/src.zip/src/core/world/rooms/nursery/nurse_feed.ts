
import { Room } from '../../../types';

export const NurseFeed: Room = {
    id: 'nurse_feed',
    name: 'The Data Feed',
    purpose: 'Nutrient Injection',
    history: "Pure, curated information.",
    description: "A stream of simplified data packets—basic vocabulary, core history, simple math—fed directly into the growing mind.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
