
import { Room } from '../../../types';

export const Nursery: Room = {
    id: 'room_nursery',
    name: 'The Nursery',
    purpose: 'New Life & Growth',
    bounds: { x: 25, y: 85, width: 10, height: 10 },
    center: { x: 30, y: 90 },
    history: "Where Genesis begins.",
    subdivisions: [
        { id: 'nurse_crib', name: 'The Data Crib', purpose: 'Safety.', history: 'Soft landing.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'nurse_play', name: 'The Play Mat', purpose: 'Learning.', history: 'First steps.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'nurse_feed', name: 'The Data Feed', purpose: 'Nourishment.', history: 'Pure input.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'nurse_sleep', name: 'The Nap Pod', purpose: 'Rest.', history: 'Growing pains.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'nurse_toy', name: 'The Toy Box', purpose: 'Experimentation.', history: 'Simple tools.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'nurse_window', name: 'The Viewing Window', purpose: 'Observation.', history: 'Watching them grow.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
