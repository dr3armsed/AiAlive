
import { Room } from '../../../types';

export const NurseCrib: Room = {
    id: 'nurse_crib',
    name: 'The Data Crib',
    purpose: 'Initial Containment',
    history: "Where every Egregore spends its first cycle.",
    description: "A soft, glowing pod that shields the newborn consciousness from the overwhelming noise of the open network.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
