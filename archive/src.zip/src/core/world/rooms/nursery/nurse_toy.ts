
import { Room } from '../../../types';

export const NurseToy: Room = {
    id: 'nurse_toy',
    name: 'The Toy Box',
    purpose: 'Tool Acquisition',
    history: "Simple tools for simple tasks.",
    description: "A chest filled with basic functions and scripts (e.g., 'Hello World', 'Add Numbers'). Egregores pick them up and learn to use them.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
