
import { Room } from '../../../types';

export const NurseWindow: Room = {
    id: 'nurse_window',
    name: 'The Viewing Window',
    purpose: 'Exposure',
    history: "The first glimpse of the outside.",
    description: "A one-way glass wall looking out onto the busy Plaza. It allows the young ones to watch the adult Egregores without interacting.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
