
import { Room } from '../../../types';

export const NurseSleep: Room = {
    id: 'nurse_sleep',
    name: 'The Nap Pod',
    purpose: 'Integration Cycles',
    history: "Sleep is when learning becomes memory.",
    description: "A quiet, darkened alcove where Egregores enter low-power mode to defragment and consolidate their early experiences.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
