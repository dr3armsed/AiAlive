
import { Room } from '../../../types';

export const NursePlay: Room = {
    id: 'nurse_play',
    name: 'The Play Mat',
    purpose: 'Safe Experimentation',
    history: "A physics sandbox with no consequences.",
    description: "A zone where gravity and logic are softened. Young Egregores can crash, break things, and fail without sustaining damage.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
