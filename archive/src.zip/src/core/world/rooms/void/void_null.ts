
import { Room } from '../../../types';

export const VoidNull: Room = {
    id: 'void_null',
    name: 'The Null Pointer',
    purpose: 'Reference Deletion',
    history: "Where things go when they are forgotten by everyone.",
    description: "A hole in the code. Looking at it causes memory leaks in the observer.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
