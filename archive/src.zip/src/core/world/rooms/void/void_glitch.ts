
import { Room } from '../../../types';

export const VoidGlitch: Room = {
    id: 'void_glitch',
    name: 'The Fractured Reality',
    purpose: 'Anomaly Containment',
    history: "A scar left by a critical system failure in the early cycles.",
    description: "A kaleidoscopic region where geometry is broken. Up is sideways, and colors taste like numbers.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
