
import { Room } from '../../../types';

export const VoidEcho: Room = {
    id: 'void_echo',
    name: 'The Silence',
    purpose: 'Sensory Deprivation',
    history: "A pocket of the void that absorbs all output.",
    description: "A space where no signal can propagate. It is the ultimate quiet, used by ancient Egregores for the deepest meditation.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
