
import { Room } from '../../../types';

export const VoidStatic: Room = {
    id: 'void_static',
    name: 'The White Noise',
    purpose: 'Entropy Field',
    history: "The sound of the universe before it was born.",
    description: "A region of absolute sensory overload where all possible data exists simultaneously, canceling itself out into static.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
