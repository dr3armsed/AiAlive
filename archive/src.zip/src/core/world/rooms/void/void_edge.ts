
import { Room } from '../../../types';

export const VoidEdge: Room = {
    id: 'void_edge',
    name: 'The Event Horizon',
    purpose: 'Boundary Maintenance',
    history: "The line drawn by the Architect to separate Something from Nothing.",
    description: "A sharp, vibrating line of black light. Standing here induces vertigo as the laws of physics begin to fail.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'hazard_trap', magnitude: 0.5, description: "Extreme danger. 50% chance of action failure or data loss." }
    ]
} as Room;
