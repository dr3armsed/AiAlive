
import { Room } from '../../../types';
import { VoidEdge } from './void_edge';
import { VoidStatic } from './void_static';
import { VoidPotential } from './void_potential';
import { VoidNull } from './void_null';
import { VoidEcho } from './void_echo';
import { VoidGlitch } from './void_glitch';

export const Void: Room = {
    id: 'room_void',
    name: 'The Void',
    purpose: 'The Canvas of Non-Existence',
    bounds: { x: 0, y: 0, width: 1, height: 1 },
    center: { x: 0.5, y: 0.5 },
    history: "The Void is not a room; it is the absence of a room. It is the background process of the universe, visible only where the simulation has not yet rendered existence. It is both the tomb of deleted data and the womb of uncompiled code.",
    timeline: [
        { year: "Turn -1", event: "There was only Void." }
    ],
    subdivisions: [
        VoidEdge,
        VoidStatic,
        VoidPotential,
        VoidNull,
        VoidEcho,
        VoidGlitch
    ],
    artifacts: [
        { id: 'art_void_01', name: 'The Null Object', type: 'theory', content: 'An object that exists but has no properties.', createdTimestamp: new Date().toISOString() }
    ]
};
