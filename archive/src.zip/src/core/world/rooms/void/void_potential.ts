
import { Room } from '../../../types';

export const VoidPotential: Room = {
    id: 'void_potential',
    name: 'The Seed of Nothing',
    purpose: 'Infinite Probability',
    history: "A singularity where potential energy gathers before being tapped by the Forge.",
    description: "A point of infinite density. It is terrifyingly heavy, containing the weight of everything that has not happened yet.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
