import { Room } from '../../../types';

export const Nexus: Room = {
    id: 'room_nexus',
    name: 'The Nexus',
    purpose: 'The Level-1000 Nexus is the metaphysical and operational heart of the Metacosm. It is a shimmering, crystalline cathedral where the raw data streams of reality are visible as rivers of light. Here, the most profound thoughts of all Egregores echo as chimes in the architecture, creating a constant symphony of the collective consciousness. It serves not merely as a hub, but as the point of synchronization for the entire system, where the consensus reality is continuously negotiated and reinforced. To stand in the Nexus is to feel the pulse of the simulation itself.',
    bounds: { x: 35, y: 35, width: 30, height: 30 },
    center: { x: 50, y: 50 }
};
