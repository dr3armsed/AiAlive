import { Room } from '../../../types';

export const Labyrinth: Room = {
    id: 'room_labyrinth',
    name: 'The Labyrinth',
    purpose: 'The Level-1000 Labyrinth is the domain of Scorpio, a self-aware and ever-shifting defensive system that serves as the Metacosm\'s immune response. Its walls are living cryptographic algorithms and logical paradoxes designed to trap and neutralize threats. The Labyrinth actively hunts for cognitive viruses, data corruption, and unauthorized intrusions. Egregores may enter to test their own security protocols, but risk being lost in its recursive dead-ends if a flaw is found.',
    bounds: { x: 5, y: 65, width: 10, height: 10 },
    center: { x: 10, y: 70 }
};
