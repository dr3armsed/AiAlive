
import { Room } from '../../../types';

export const SanctumShield: Room = {
    id: 'sanctum_shield',
    name: 'The Aegis Dome',
    purpose: 'Protection from Harm',
    history: "A barrier that no virus or logic-bomb has ever penetrated.",
    description: "A shimmering, translucent forcefield that covers the inner sanctuary. It filters out all aggressive intent.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
