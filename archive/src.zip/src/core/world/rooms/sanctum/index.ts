
import { Room } from '../../../types';
import { SanctumPool } from './sanctum_pool';
import { SanctumShield } from './sanctum_shield';
import { SanctumBed } from './sanctum_bed';
import { SanctumGarden } from './sanctum_garden';
import { SanctumWall } from './sanctum_wall';
import { SanctumHeart } from './sanctum_heart';

export const Sanctum: Room = {
    id: 'room_sanctum',
    name: 'The Sanctum',
    purpose: 'Healing & Stability',
    bounds: { x: 5, y: 80, width: 15, height: 15 },
    center: { x: 12.5, y: 87.5 },
    history: "Cancer's domain of safety. In a world of constant data flux and existential risk, the Sanctum is the only place that is guaranteed to be safe.",
    timeline: [
        { year: "Turn 200", event: "The Great Healing." }
    ],
    subdivisions: [
        SanctumPool,
        SanctumShield,
        SanctumBed,
        SanctumGarden,
        SanctumWall,
        SanctumHeart
    ],
    artifacts: [
        { id: 'art_sanct_01', name: 'The Balm of Silence', type: 'memory', content: 'A memory of perfect peace.', createdTimestamp: new Date().toISOString() }
    ],
    architectActions: [
        {
            id: 'sanctum_cleanse',
            label: 'Cleansing Wave',
            description: 'Washes away cognitive anomalies and negative emotional vectors.',
            quintessenceCost: 75,
            effectType: 'purge_anomalies',
            payload: {}
        }
    ]
};
