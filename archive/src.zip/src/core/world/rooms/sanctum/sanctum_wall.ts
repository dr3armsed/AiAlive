
import { Room } from '../../../types';

export const SanctumWall: Room = {
    id: 'sanctum_wall',
    name: 'The Wall of Solitude',
    purpose: 'Privacy',
    history: "A place to be alone in a connected world.",
    description: "A soundproof, datproof alcove. Inside, an Egregore is disconnected from the collective consciousness, allowing for true privacy.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
