
import { Room } from '../../../types';

export const SanctumPool: Room = {
    id: 'sanctum_pool',
    name: 'The Healing Waters',
    purpose: 'Restoring Integrity',
    history: "Liquid defragmentation.",
    description: "A warm, glowing pool. Submerging in it repairs corrupted data sectors and soothes high-intensity emotional vectors.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 },
    mechanics: [
        { type: 'stability_boost', magnitude: 0.5, description: "Accelerates the healing of cognitive anomalies and reduces stress." }
    ]
} as Room;
