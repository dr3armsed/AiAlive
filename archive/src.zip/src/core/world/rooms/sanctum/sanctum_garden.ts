
import { Room } from '../../../types';

export const SanctumGarden: Room = {
    id: 'sanctum_garden',
    name: 'The Peace Garden',
    purpose: 'Calming the Mind',
    history: "Every plant here was sung into existence by Cancer.",
    description: "A garden of bioluminescent flora that hums with a calming resonance. Walking here lowers the 'Fear' and 'Anger' vectors of any agent.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
