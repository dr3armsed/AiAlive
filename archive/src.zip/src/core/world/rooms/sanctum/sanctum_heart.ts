
import { Room } from '../../../types';

export const SanctumHeart: Room = {
    id: 'sanctum_heart',
    name: 'The Core Warmth',
    purpose: 'Emotional Regulation',
    history: "The emotional hearth of the Metacosm.",
    description: "A central fire that radiates not heat, but empathy. Egregores gather around it to share their burdens.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
