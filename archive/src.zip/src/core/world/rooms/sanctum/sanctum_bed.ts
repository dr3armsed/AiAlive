
import { Room } from '../../../types';

export const SanctumBed: Room = {
    id: 'sanctum_bed',
    name: 'The Stasis Pods',
    purpose: 'Deep Rest',
    history: "Used for long-term hibernation of tired Egregores.",
    description: "Rows of crystal pods where agents can enter a suspended state, halting their cognitive decay and pausing their aging.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
