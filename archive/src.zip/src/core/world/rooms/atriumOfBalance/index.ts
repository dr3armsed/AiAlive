
import { Room } from '../../../types';

export const AtriumOfBalance: Room = {
    id: 'room_atrium',
    name: 'The Atrium of Balance',
    purpose: 'Ethical Judgment',
    bounds: { x: 80, y: 80, width: 15, height: 15 },
    center: { x: 87.5, y: 87.5 },
    history: "Libra's hall of justice.",
    subdivisions: [
        { id: 'atrium_scales', name: 'The Great Scales', purpose: 'Weighing souls.', history: 'Never wrong.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'atrium_court', name: 'The High Court', purpose: 'Debating law.', history: 'Order in the court.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'atrium_stone', name: 'The Tablet of Law', purpose: 'Recording rules.', history: 'Written in stone.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'atrium_blind', name: 'The Blindfold Room', purpose: 'Impartiality.', history: 'Justice is blind.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'atrium_sword', name: 'The Sword\'s Edge', purpose: 'Enforcement.', history: 'Swift and decisive.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}},
        { id: 'atrium_peace', name: 'The Hall of Truce', purpose: 'Mediation.', history: 'Lay down arms.', bounds: {x:0, y:0, width:0, height:0}, center:{x:0,y:0}}
    ]
};
