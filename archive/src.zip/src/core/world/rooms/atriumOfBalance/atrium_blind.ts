
import { Room } from '../../../types';

export const AtriumBlind: Room = {
    id: 'atrium_blind',
    name: 'The Blindfold Room',
    purpose: 'Unbiased Analysis',
    history: "A chamber where identity is stripped away to ensure fairness.",
    description: "A room of absolute darkness where Egregores appear only as wireframe data structures, stripped of their names and histories, allowing for judgment based purely on logic.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
