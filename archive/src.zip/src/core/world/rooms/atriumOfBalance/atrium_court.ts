
import { Room } from '../../../types';

export const AtriumCourt: Room = {
    id: 'atrium_court',
    name: 'The High Court',
    purpose: 'Juridical Debate',
    history: "Where Libra argued against the deletion of the 'Trickster' archetype and won.",
    description: "A circular array of floating podiums. The acoustics are engineered so that only the truth rings clear; lies sound like static interference.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
