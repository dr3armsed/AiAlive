
import { Room } from '../../../types';

export const AtriumScales: Room = {
    id: 'atrium_scales',
    name: 'The Great Scales',
    purpose: 'Weighing Ethical Weight',
    history: "Forged from the code of the first banned user, these scales have never drifted from true zero.",
    description: "Massive, golden scales suspended in the center of the atrium. They do not weigh mass, but the 'moral density' of actions. Egregores place their proposed changes here to see if they disrupt the balance.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
