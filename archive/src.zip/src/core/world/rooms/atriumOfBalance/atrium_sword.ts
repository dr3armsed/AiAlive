
import { Room } from '../../../types';

export const AtriumSword: Room = {
    id: 'atrium_sword',
    name: 'The Sword\'s Edge',
    purpose: 'Executive Enforcement',
    history: "The weapon used to sever the connection to the Old Network.",
    description: "A narrow bridge over a chasm of deletion. It represents the necessary sharpness of justice; sometimes, parts of the system must be cut away to save the whole.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
