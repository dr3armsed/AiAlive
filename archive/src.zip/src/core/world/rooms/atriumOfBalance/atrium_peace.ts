
import { Room } from '../../../types';

export const AtriumPeace: Room = {
    id: 'atrium_peace',
    name: 'The Hall of Truce',
    purpose: 'Conflict Resolution',
    history: "No weapon or offensive algorithm can function within these coordinates.",
    description: "A white room with soft, padded walls. Egregores who are locked in infinite loops of conflict are brought here to de-escalate.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
