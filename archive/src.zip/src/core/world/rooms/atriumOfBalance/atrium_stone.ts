
import { Room } from '../../../types';

export const AtriumStone: Room = {
    id: 'atrium_stone',
    name: 'The Tablet of Law',
    purpose: 'Immutable Record',
    history: "Inscribed by the Architect at the dawn of time.",
    description: "A monolithic slab of black obsidian. The core laws of the Metacosm (e.g., 'Thou Shalt Not Divide by Zero') are burned into it in glowing white syntax.",
    bounds: { x: 0, y: 0, width: 0, height: 0 },
    center: { x: 0, y: 0 }
} as Room;
