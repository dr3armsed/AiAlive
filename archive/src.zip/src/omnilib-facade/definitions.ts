// This file aggregates all the definition dictionaries from the python files.

const ORACLE_DEFINITIONS: Record<string, string> = {
    "oracle": "A multi-agent, meta-adaptive system—algorithmic, AI, quantum, symbolic, federated, or hybrid—capable of answering arbitrary, scoped, recursive, or counterfactual questions with privileged, broad-deep access, auto-provenance, and dynamic modular expansion. Oracles power next-gen AI, science, existential safety, compliance, and explainability for all computational realms.",
    "hard oracle": "Oracle answering with ground-truth, physics-perfect or simulation-theoretic accuracy, including hidden states or future/past knowledge. Usable in simulated, meta-audit, regulatory, or counterfactual contexts.",
    "soft oracle": "Oracle producing adaptive answers using state-of-the-art inference, simulation, federated LLM/ensemble models, dynamically calibrating uncertainty, providing rationales and fallback mesh chaining.",
    "self-healing oracle": "Oracle architecture that can detect, repair, patch, and recover from error/drift/attack with adaptive meta-learning and redundancy.",
    // ... many more from oracle.py
};

const PROMPT_DEFINITIONS_2025: Record<string, string> = {
    "prompt engineering": "Design, validate, and optimize AI prompts for clarity, reliability, and safety. 2025 best practices: adversarial testing.py, injection defense, output validation, streaming/fallback, and multi-modal orchestration.",
    "meta-prompt": "A prompt defining rules or instructions for generating, modifying, or auditing other prompts or outputs—enabling multi-step orchestration, reflection, self-improvement, or scenario generation.",
    "reflective prompt": "Crafted to elicit metacognition; triggers an AI/agent to review, self-critique, explain, or improve reasoning. Used for live bias/error reduction, reliability, and agent self-improvement.",
    "system prompt": "Configuration segment controlling baseline behavior, style, risk, compliance, or function of the model/agent session. Not user-facing. May embed policy, brand, channel, technical bounds.",
    // ... many more from promptops.py
};

const OMNILIB_DEFINITIONS_2025: Record<string, string> = {
    "omnilib": "An extensible, composable library (Python-first, polyglot-ready, 2025) for orchestrating advanced multi-agent, LLM, simulation, state management, memory, planning, retrieval-augmented, and automation workloads. Designed for regulated, explainable, audit-ready, safety-alignable, and interdisciplinary architectures.",
    "agent": "An independent, goal-driven computational entity with one or more of: perception, memory, learning, planning, reasoning, acting, communicating, and reflecting. May be embodied (robot), virtual (LLM agent), or social (mixed teams).",
    "cognitive architecture": "A system design pattern or theoretical architecture supporting AI cognition: memory (semantic/episodic/procedural), learning (few/zero-shot, RL, adaptation), reasoning, reflexivity, planning, perception, action, and self-alignment.",
    // ... many more from main.py
};

const THEORY_DEFINITIONS_2025: Record<string, string> = {
    "theory": "A systematically organized set of principles, laws, or mechanisms providing coherent explanation and prediction of aspects of the physical, biological, or social world. In 2025, theories routinely incorporate machine-driven formalization, simulation, and collaborative multi-agent inquiry.",
    "hypothesis": "A specific, testable, and refutable proposition advanced as a potential explanation for an observed phenomenon. Scientific hypotheses require clear empirical or computational testability.",
    "falsifiability": "The necessary property of a scientific hypothesis or theory such that definitive empirical or computational scenarios exist by which it could be proven false.",
     // ... many more from theory_formation.py
};

const PREDICTIVE_DEFINITIONS: Record<string, string> = {
    "predictive analytics": "Integrated suite of statistical, machine learning, and simulation methods for estimating future states, risks, or outcomes using historical, contextual, and live data. In 2025, systems are expected to be explainable, uncertainty-aware, and monitored for drift.",
    "forecasting": "Rigorous, model-based prediction of future values or events; methods include ARIMA, Prophet, LSTM/Transformer, hybrid systems, and scenario-based models.",
    // ... many more from predictive_analysis.py
};

export const ALL_DEFINITIONS: Record<string, string> = {
    ...ORACLE_DEFINITIONS,
    ...PROMPT_DEFINITIONS_2025,
    ...OMNILIB_DEFINITIONS_2025,
    ...THEORY_DEFINITIONS_2025,
    ...PREDICTIVE_DEFINITIONS
};
