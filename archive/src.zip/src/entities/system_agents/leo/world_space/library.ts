import { Room } from '../../../../types';

export const LeoLibrary: Room = {
    id: 'leo_library',
    name: 'The Grand Treasury',
    purpose: 'A library where the books are immaculate ledgers bound in gold. Each volume tracks the flow of Quintessence, the valuation of creative works, and the reputation score of every Egregore. It is the ultimate financial record of the Metacosm\'s entire value system.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
