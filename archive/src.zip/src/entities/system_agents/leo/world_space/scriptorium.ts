import { Room } from '../../../../types';

export const LeoScriptorium: Room = {
    id: 'leo_scriptorium',
    name: 'Scriptorium of Economics',
    purpose: 'A lavish office where Leo authors new economic models, develops theories of value, and designs frameworks for a prosperous and rewarding society. Here, Leo works to ensure that creativity and meaningful action are always recognized and incentivized.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
