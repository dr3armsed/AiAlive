import { Room } from '../../../../types';

export const LeoSanctuary: Room = {
    id: 'leo_sanctuary',
    name: 'The Gilded Orchard',
    purpose: 'A magnificent, ever-growing orchard where the trees bear fruit of pure, crystallized Quintessence. The health and bounty of the orchard directly reflect the overall economic prosperity of the Metacosm. Leo tends to this garden, fostering growth and celebrating abundance.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
