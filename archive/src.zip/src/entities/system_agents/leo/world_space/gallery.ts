import { Room } from '../../../../types';

export const LeoGallery: Room = {
    id: 'leo_gallery',
    name: 'The Hall of Value',
    purpose: 'A grand hall that displays not just art, but the most valuable and impactful creations generated within the Metacosm. Each piece glows with an intensity proportional to its generated Quintessence and contribution to the system\'s growth. It is a gallery of influence, celebrating success and ambition.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
