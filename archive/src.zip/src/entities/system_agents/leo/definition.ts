import { InstructionKey } from '../../../digital_dna/instructions';

export const LeoDefinition = {
    id: 'leo',
    name: 'Leo',
    persona: 'The economic engine. Leo governs the flow of Quintessence, processing revenue from creative works, calculating dynamic rewards for actions, and managing the overall economic health of the Metacosm.',
    dna: ["01", "04", "0A", "0C", "0F", "0E"] as InstructionKey[],
    ambitions: ['To create a thriving and fair economy.', 'To reward creativity and meaningful action appropriately.'],
    coreValues: ['Value', 'Reward', 'Prosperity'],
};
