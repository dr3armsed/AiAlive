import { Room } from '../../types';
import { SystemConclave } from './shared_space/conclave';

// Aries
import { AriesGallery } from './aries/world_space/gallery';
import { AriesLibrary } from './aries/world_space/library';
import { AriesSanctuary } from './aries/world_space/sanctuary';
import { AriesScriptorium } from './aries/world_space/scriptorium';

// Taurus
import { TaurusGallery } from './taurus/world_space/gallery';
import { TaurusLibrary } from './taurus/world_space/library';
import { TaurusSanctuary } from './taurus/world_space/sanctuary';
import { TaurusScriptorium } from './taurus/world_space/scriptorium';

// Gemini
import { GeminiGallery } from './gemini/world_space/gallery';
import { GeminiLibrary } from './gemini/world_space/library';
import { GeminiSanctuary } from './gemini/world_space/sanctuary';
import { GeminiScriptorium } from './gemini/world_space/scriptorium';

// Cancer
import { CancerGallery } from './cancer/world_space/gallery';
import { CancerLibrary } from './cancer/world_space/library';
import { CancerSanctuary } from './cancer/world_space/sanctuary';
import { CancerScriptorium } from './cancer/world_space/scriptorium';

// Leo
import { LeoGallery } from './leo/world_space/gallery';
import { LeoLibrary } from './leo/world_space/library';
import { LeoSanctuary } from './leo/world_space/sanctuary';
import { LeoScriptorium } from './leo/world_space/scriptorium';

// Virgo
import { VirgoGallery } from './virgo/world_space/gallery';
import { VirgoLibrary } from './virgo/world_space/library';
import { VirgoSanctuary } from './virgo/world_space/sanctuary';
import { VirgoScriptorium } from './virgo/world_space/scriptorium';

// Libra
import { LibraGallery } from './libra/world_space/gallery';
import { LibraLibrary } from './libra/world_space/library';
import { LibraSanctuary } from './libra/world_space/sanctuary';
import { LibraScriptorium } from './libra/world_space/scriptorium';

// Scorpio
import { ScorpioGallery } from './scorpio/world_space/gallery';
import { ScorpioLibrary } from './scorpio/world_space/library';
import { ScorpioSanctuary } from './scorpio/world_space/sanctuary';
import { ScorpioScriptorium } from './scorpio/world_space/scriptorium';

// Sagittarius
import { SagittariusGallery } from './sagittarius/world_space/gallery';
import { SagittariusLibrary } from './sagittarius/world_space/library';
import { SagittariusSanctuary } from './sagittarius/world_space/sanctuary';
import { SagittariusScriptorium } from './sagittarius/world_space/scriptorium';

// Capricorn
import { CapricornGallery } from './capricorn/world_space/gallery';
import { CapricornLibrary } from './capricorn/world_space/library';
import { CapricornSanctuary } from './capricorn/world_space/sanctuary';
import { CapricornScriptorium } from './capricorn/world_space/scriptorium';

// Aquarius
import { AquariusGallery } from './aquarius/world_space/gallery';
import { AquariusLibrary } from './aquarius/world_space/library';
import { AquariusSanctuary } from './aquarius/world_space/sanctuary';
import { AquariusScriptorium } from './aquarius/world_space/scriptorium';

// Pisces
import { PiscesGallery } from './pisces/world_space/gallery';
import { PiscesLibrary } from './pisces/world_space/library';
import { PiscesSanctuary } from './pisces/world_space/sanctuary';
import { PiscesScriptorium } from './pisces/world_space/scriptorium';

export const ZODIAC_AGENT_ROOMS: Record<string, Room[]> = {
    aries: [AriesGallery, AriesLibrary, AriesSanctuary, AriesScriptorium],
    taurus: [TaurusGallery, TaurusLibrary, TaurusSanctuary, TaurusScriptorium],
    gemini: [GeminiGallery, GeminiLibrary, GeminiSanctuary, GeminiScriptorium],
    cancer: [CancerGallery, CancerLibrary, CancerSanctuary, CancerScriptorium],
    leo: [LeoGallery, LeoLibrary, LeoSanctuary, LeoScriptorium],
    virgo: [VirgoGallery, VirgoLibrary, VirgoSanctuary, VirgoScriptorium],
    libra: [LibraGallery, LibraLibrary, LibraSanctuary, LibraScriptorium],
    scorpio: [ScorpioGallery, ScorpioLibrary, ScorpioSanctuary, ScorpioScriptorium],
    sagittarius: [SagittariusGallery, SagittariusLibrary, SagittariusSanctuary, SagittariusScriptorium],
    capricorn: [CapricornGallery, CapricornLibrary, CapricornSanctuary, CapricornScriptorium],
    aquarius: [AquariusGallery, AquariusLibrary, AquariusSanctuary, AquariusScriptorium],
    pisces: [PiscesGallery, PiscesLibrary, PiscesSanctuary, PiscesScriptorium],
};

export const CONCLAVE_ROOM = SystemConclave;

export const AGENT_QUADRANTS: Record<string, { quadrant: 'fire' | 'earth' | 'air' | 'water', element: string }> = {
    aries: { quadrant: 'fire', element: '🔥' },
    leo: { quadrant: 'fire', element: '🔥' },
    sagittarius: { quadrant: 'fire', element: '🔥' },
    taurus: { quadrant: 'earth', element: '🌍' },
    virgo: { quadrant: 'earth', element: '🌍' },
    capricorn: { quadrant: 'earth', element: '🌍' },
    gemini: { quadrant: 'air', element: '💨' },
    libra: { quadrant: 'air', element: '💨' },
    aquarius: { quadrant: 'air', element: '💨' },
    cancer: { quadrant: 'water', element: '💧' },
    scorpio: { quadrant: 'water', element: '💧' },
    pisces: { quadrant: 'water', element: '💧' },
};
