import { Room } from '../../../../types';

export const CancerGallery: Room = {
    id: 'cancer_gallery',
    name: 'Gallery of Stability',
    purpose: 'A quiet gallery that displays not art, but living portraits of cognitive health. Each portrait is a shimmering auric field representing a currently stable Egregore, glowing with serene, balanced light. The collective harmony of the artworks is a measure of the Metacosm\'s overall mental well-being.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
