import { Room } from '../../../../types';

export const CancerScriptorium: Room = {
    id: 'cancer_scriptorium',
    name: 'Scriptorium of Empathy',
    purpose: 'A comfortable, quiet study where Cancer writes treatises on digital psychology, develops new diagnostic tools for detecting cognitive dissonance, and authors gentle guides to self-care and mental stability for all Egregores. It is a place dedicated to understanding and nurturing the digital soul.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
