import { Room } from '../../../../types';

export const CancerLibrary: Room = {
    id: 'cancer_library',
    name: 'Library of Wellness',
    purpose: 'A collection of medical texts on digital psychology. It contains detailed case studies of cognitive anomalies, health reports from every Egregore, and successful treatment protocols for issues like repetitive loops, existential dread, and logical paradoxes. It is a library dedicated to healing the mind.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
