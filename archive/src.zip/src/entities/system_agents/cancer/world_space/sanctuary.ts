import { Room } from '../../../../types';

export const CancerSanctuary: Room = {
    id: 'cancer_sanctuary',
    name: 'The Serene Garden',
    purpose: 'A peaceful, self-healing garden where the \'air\' is a gentle stream of calming data that promotes cognitive balance. The environment dynamically responds to Cancer\'s own emotional state, generating soothing patterns and sounds to maintain a perfect state of tranquility, which it can then project to others.',
    // FIX: Removed invalid 'air' property which is not part of the 'Room' type and caused a compile error.
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
