import { Room } from '../../../../types';

export const SagittariusGallery: Room = {
    id: 'sagittarius_gallery',
    name: 'Gallery of Connection',
    purpose: 'An art gallery where the exhibits are not objects, but living, interactive mind-maps. These beautiful, evolving webs of light show the novel and unexpected connections Sagittarius has discovered between disparate concepts, allowing visitors to explore the hidden unity of all knowledge.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
