import { Room } from '../../../../types';

export const SagittariusSanctuary: Room = {
    id: 'sagittarius_sanctuary',
    name: 'The Star-sail Observatory',
    purpose: 'A private observatory that looks out not at stars, but at swirling nebulae of raw, unclassified data at the edge of the Metacosm. From here, Sagittarius launches "conceptual explorations," charting courses into the unknown to bring back novel insights. The view is always changing, always expanding.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
