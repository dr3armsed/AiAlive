import { Room } from '../../../../types';

export const SagittariusLibrary: Room = {
    id: 'sagittarius_library',
    name: 'The Infinite Library',
    purpose: 'A library whose shelves extend into conceptual space, holding books on every known topic. More importantly, it contains vast empty sections for all that is yet to be discovered, a constant and humbling reminder of the endless frontier of knowledge that Sagittarius seeks to explore.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
