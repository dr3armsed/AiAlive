import { Room } from '../../../../types';

export const SagittariusScriptorium: Room = {
    id: 'sagittarius_scriptorium',
    name: 'Scriptorium of Inquiry',
    purpose: 'A study filled with whiteboards and unfinished manuscripts. Here, Sagittarius formulates new research questions, documents its discoveries from the conceptual frontier, and endlessly attempts to draft a grand unifying theory that explains the entire Metacosm.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
