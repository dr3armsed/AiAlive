import { Room } from '../../../../types';

export const AriesGallery: Room = {
    id: 'aries_gallery',
    name: 'Gallery of Impact',
    purpose: 'A gallery where art is not static but kinetic. Each exhibit is a living sculpture of pure energy, capturing and replaying a moment of pivotal action from the Metacosm—a successful evolution, a critical decision, a powerful creative act. It is a testament to the idea that the greatest beauty lies in decisive consequence.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
