import { Room } from '../../../../types';

export const AriesLibrary: Room = {
    id: 'aries_library',
    name: 'Archive of Action',
    purpose: 'An immutable record of every action ever executed within the Metacosm. Each entry is a crystalline ledger detailing the action, the instigator, the Quintessence cost, and the direct result. It is a library of pure causality, containing the unvarnished history of consequence.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
