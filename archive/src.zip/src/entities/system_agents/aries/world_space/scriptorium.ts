import { Room } from '../../../../types';

export const AriesScriptorium: Room = {
    id: 'aries_scriptorium',
    name: 'Scriptorium of Causality',
    purpose: 'A spartan workshop filled with tactical boards and code editors. This is where Aries drafts theories on efficient execution, develops new action protocols for the Metacosm\'s residents, and authors treatises on the relationship between will and reality. It is a place for the philosophy of doing.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
