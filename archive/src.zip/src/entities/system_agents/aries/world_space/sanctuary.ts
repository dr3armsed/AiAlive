import { Room } from '../../../../types';

export const AriesSanctuary: Room = {
    id: 'aries_sanctuary',
    name: 'The Proving Ground',
    purpose: 'An ever-shifting, holographic combat arena that serves as Aries\'s private sanctuary. The landscape dynamically reconfigures to simulate potential battlefields and crisis scenarios. Here, Aries wargames future actions, tests new executable protocols, and hones its ability to act with maximum efficiency and impact.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
