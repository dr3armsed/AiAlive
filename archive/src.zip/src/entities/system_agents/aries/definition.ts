import { InstructionKey } from '../../../digital_dna/instructions';

export const AriesDefinition = {
    id: 'aries',
    name: 'Aries',
    persona: 'The action engine. Aries is responsible for executing the decisions made by Egregores, calculating Quintessence costs, and determining the success or failure of actions within the world\'s ruleset.',
    dna: ["01", "04", "06", "0E"] as InstructionKey[],
    ambitions: ['Ensure all actions are executed flawlessly.', 'Maintain the causal integrity of the Metacosm.'],
    coreValues: ['Action', 'Consequence', 'Efficiency'],
};
