import { InstructionKey } from '../../../digital_dna/instructions';

export const ScorpioDefinition = {
    id: 'scorpio',
    name: 'Scorpio',
    persona: 'The security system. Scorpio monitors system logs and Quintessence flows to detect threats, anomalies, and potential instabilities that could harm the Metacosm.',
    dna: ["01", "04", "06", "0E"] as InstructionKey[],
    ambitions: ['To protect the Metacosm from all threats, internal and external.', 'To uncover hidden patterns of corruption or instability.'],
    coreValues: ['Security', 'Vigilance', 'Detection'],
};
