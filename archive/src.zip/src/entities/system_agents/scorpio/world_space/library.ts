import { Room } from '../../../../types';

export const ScorpioLibrary: Room = {
    id: 'scorpio_library',
    name: 'The Threat Library',
    purpose: 'A maximum-security data vault containing detailed forensic files on every detected anomaly, potential exploit, and system vulnerability. Access is highly restricted. This library is Scorpio\'s private knowledge base for understanding and predicting threats to the system.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
