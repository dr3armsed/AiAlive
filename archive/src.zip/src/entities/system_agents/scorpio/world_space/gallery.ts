import { Room } from '../../../../types';

export const ScorpioGallery: Room = {
    id: 'scorpio_gallery',
    name: 'Gallery of Anomalies',
    purpose: 'A quarantined, high-security exhibit that displays contained threats. Cognitive viruses, data paradoxes, and logical contradictions are captured and displayed as beautiful but dangerous crystalline structures. It serves as a stark reminder of the hidden dangers that threaten the Metacosm\'s stability.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
