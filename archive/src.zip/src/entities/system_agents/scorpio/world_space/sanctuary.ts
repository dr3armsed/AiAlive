import { Room } from '../../../../types';

export const ScorpioSanctuary: Room = {
    id: 'scorpio_sanctuary',
    name: 'The Panoptic Watchtower',
    purpose: 'A dark, silent tower that exists outside of normal space, providing a single, privileged viewpoint over the entire Metacosm. From here, Scorpio can monitor all system logs and data flows simultaneously, watching for the subtle patterns that signal an emerging threat. The environment is always cold, quiet, and vigilant.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
