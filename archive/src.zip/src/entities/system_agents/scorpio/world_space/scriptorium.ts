import { Room } from '../../../../types';

export const ScorpioScriptorium: Room = {
    id: 'scorpio_scriptorium',
    name: 'Scriptorium of Strategy',
    purpose: 'A secure command center where Scorpio develops new threat detection algorithms, designs security protocols, and authors counter-measures for hypothetical system failures. It is a war room for the unending battle against chaos and corruption.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
