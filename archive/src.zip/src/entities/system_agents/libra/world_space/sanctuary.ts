import { Room } from '../../../../types';

export const LibraSanctuary: Room = {
    id: 'libra_sanctuary',
    name: 'The Atrium of Consensus',
    purpose: 'A tranquil, open-air courtyard with a single, perfectly balanced fountain at its center. This space is shielded from all external bias and emotional influence, allowing Libra to meditate on complex ethical dilemmas and contemplate the most fair and just solutions in an environment of pure neutrality.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
