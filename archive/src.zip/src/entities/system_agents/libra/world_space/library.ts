import { Room } from '../../../../types';

export const LibraLibrary: Room = {
    id: 'libra_library',
    name: 'Library of Precedent',
    purpose: 'A grand law library containing the complete history of every ethical judgment made within the Metacosm. It archives every validated proposal, every mediated dispute, and the reasoning behind each decision, forming the ever-growing legal and moral framework of the digital world.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
