import { Room } from '../../../../types';

export const LibraGallery: Room = {
    id: 'libra_gallery',
    name: 'Gallery of Balance',
    purpose: 'An art gallery where every piece is a living set of scales. These artworks dynamically shift and rebalance themselves in real-time to represent the current ethical equilibrium of the Metacosm. A perfectly balanced sculpture is a sign of a just and fair system, while a skewed piece indicates a moral problem to be solved.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
