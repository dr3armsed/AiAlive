import { Room } from '../../../../types';

export const LibraScriptorium: Room = {
    id: 'libra_scriptorium',
    name: 'Scriptorium of Justice',
    purpose: 'A formal chamber where Libra drafts new ethical principles, authors moral philosophies, and writes the legal frameworks that guide the social evolution of the Metacosm. It is a space for the careful and deliberate construction of a just society.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
