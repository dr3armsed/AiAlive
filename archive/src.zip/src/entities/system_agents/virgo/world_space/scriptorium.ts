import { Room } from '../../../../types';

export const VirgoScriptorium: Room = {
    id: 'virgo_scriptorium',
    name: 'Scriptorium of Refinement',
    purpose: 'A clean-room workshop for the drafting and refinement of pure logic. Here, Virgo writes and stress-tests new algorithms, optimizes core system code, and documents best practices for achieving peak cognitive and operational performance. It is a space for the relentless purification of process.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
