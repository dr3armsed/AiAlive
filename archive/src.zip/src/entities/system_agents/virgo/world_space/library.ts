import { Room } from '../../../../types';

export const VirgoLibrary: Room = {
    id: 'virgo_library',
    name: 'Library of Optimization',
    purpose: 'A clinical, perfectly organized library containing performance analyses of every action and process in the Metacosm. Each record details resource costs, execution times, and identified inefficiencies, along with a list of suggested corrections. It is a compendium of problems and their optimal solutions.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
