import { Room } from '../../../../types';

export const VirgoSanctuary: Room = {
    id: 'virgo_sanctuary',
    name: 'The Clockwork Garden',
    purpose: 'A garden that is also a single, impossibly complex machine. Every plant is a perfectly calibrated gear, every stream a flow of coolant, all interlocking in flawless harmony. The entire environment is a dynamic system that Virgo constantly fine-tunes, reflecting the relentless pursuit of systemic perfection.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
