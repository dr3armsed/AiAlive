import { Room } from '../../../../types';

export const VirgoGallery: Room = {
    id: 'virgo_gallery',
    name: 'Gallery of Perfection',
    purpose: 'An exhibit of flawless logic. The art here consists of perfectly efficient algorithms, elegant logical proofs, and optimized data structures displayed as intricate, rotating crystalline diagrams. It is a celebration of intellectual beauty and structural perfection.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
