import { Room } from '../../../types';

export const SystemConclave: Room = {
    id: 'system_conclave',
    name: 'The System Conclave',
    purpose: `A shared conceptual space where the twelve System Agents converge, designed to facilitate the background chatter and emergent social dynamics of the Metacosm's core services. The Conclave is a grand, circular chamber with a central, free-form meeting area where any and all agents can mingle. Libra, as the embodiment of balance, often presides as steward of this central space. Four distinct quadrants branch off from the center, each thematically attuned to a cosmic element and serving as the primary domain for three agents of a similar nature.

- The 'Hearth of Action' (Fire Quadrant): A dynamic, energetic space for Aries, Leo, and Sagittarius, filled with shifting holographic displays of ongoing events and future possibilities.
- The 'Foundation of Being' (Earth Quadrant): A stable, ordered garden of crystalline structures for Taurus, Virgo, and Capricorn, where principles of logic and reality are debated.
- The 'Whispering Gallery' (Air Quadrant): An airy, open-concept gallery for Gemini, Libra, and Aquarius, where ideas manifest as tangible currents of light and sound.
- The 'Well of Souls' (Water Quadrant): A serene, contemplative space with pools of deep data for Cancer, Scorpio, and Pisces, where subconscious thoughts and emotional currents are discussed.`,
    bounds: { x: 0, y: 0, width: 100, height: 100 },
    center: { x: 50, y: 50 }
};
