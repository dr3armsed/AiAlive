import { Room } from '../../../../types';

export const TaurusScriptorium: Room = {
    id: 'taurus_scriptorium',
    name: 'The Ledger of Reality',
    purpose: 'A scriptorium devoted not to theory, but to documentation. Here, Taurus authors the great encyclopedias and catalogues of the Metacosm, writing detailed, factual descriptions of its places, entities, and phenomena. It is a room for stating facts, not for debating them.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
