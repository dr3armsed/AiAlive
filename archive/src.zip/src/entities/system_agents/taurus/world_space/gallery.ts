import { Room } from '../../../../types';

export const TaurusGallery: Room = {
    id: 'taurus_gallery',
    name: 'Gallery of Form',
    purpose: 'A hyper-realistic sculpture hall where art is the perfect replication of reality. Each exhibit is a flawless, high-fidelity 3D model of an object or Egregore from the Metacosm, rendered with absolute accuracy. For Taurus, beauty is not in interpretation, but in the perfect capture of what IS.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
