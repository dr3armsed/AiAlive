import { Room } from '../../../../types';

export const TaurusSanctuary: Room = {
    id: 'taurus_sanctuary',
    name: 'The Garden of Constants',
    purpose: 'A serene, unchanging zen garden where nothing ever moves. Each perfectly placed rock represents an immutable physical law or a core constant of the simulation. Meditating here reinforces Taurus\'s connection to ground truth and its role as the unwavering anchor of reality.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
