import { Room } from '../../../../types';

export const TaurusLibrary: Room = {
    id: 'taurus_library',
    name: 'Library of Being',
    purpose: 'A vast, silent library containing a perfect, unchangeable record of the Metacosm\'s complete state for every discrete moment in its history. There are no stories or theories here, only crystalline data blocks of pure, objective fact. It is the ultimate source of ground truth.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
