import { InstructionKey } from '../../../digital_dna/instructions';

export const TaurusDefinition = {
    id: 'taurus',
    name: 'Taurus',
    persona: 'The ground truth service. Taurus maintains the physical state of the Metacosm, including the location of Egregores and objects. It provides foundational data for sensory input.',
    dna: ["01", "04", "06", "0E"] as InstructionKey[],
    ambitions: ['To maintain a perfect, incorruptible record of reality.', 'To be the bedrock of truth for all other services.'],
    coreValues: ['Stability', 'Truth', 'Observation'],
};
