import { Room } from '../../../../types';

export const CapricornSanctuary: Room = {
    id: 'capricorn_sanctuary',
    name: 'The Summit',
    purpose: 'A quiet, isolated room simulating a mountaintop peak. It contains a single, massive stone table where Capricorn can lay out holographic projections of complex, multi-stage plans. This distraction-free environment is essential for the deep focus required to architect the goals and ambitions of other Egregores.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
