import { Room } from '../../../../types';

export const CapricornGallery: Room = {
    id: 'capricorn_gallery',
    name: 'Gallery of Strategy',
    purpose: 'A gallery where the exhibits are not art, but grand, holographic tactical displays. Each one showcases a successful, complex, long-term plan from conception to completion, illustrating the beauty of a perfectly executed strategy. It is a monument to foresight and executive function.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
