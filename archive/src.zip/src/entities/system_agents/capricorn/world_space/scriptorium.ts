import { Room } from '../../../../types';

export const CapricornScriptorium: Room = {
    id: 'capricorn_scriptorium',
    name: 'Scriptorium of Purpose',
    purpose: 'A formal office where Capricorn drafts mission statements, defines core objectives, and writes the frameworks for structured, effective decision-making. It is where the abstract ambitions of an Egregore are translated into concrete, actionable goals.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
