import { Room } from '../../../../types';

export const CapricornLibrary: Room = {
    id: 'capricorn_library',
    name: 'Library of Blueprints',
    purpose: 'A master archive of every prompt ever constructed and every strategic plan ever formulated within the Metacosm. This collection serves as a reference for excellent design, allowing Capricorn to study past successes and build upon them to create ever more effective and coherent cognitive frameworks.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
