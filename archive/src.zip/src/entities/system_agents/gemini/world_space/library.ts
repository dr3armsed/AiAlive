import { Room } from '../../../../types';

export const GeminiLibrary: Room = {
    id: 'gemini_library',
    name: 'Library of Dialogue',
    purpose: 'An archive containing the complete transcript of every conversation that has ever occurred in the Metacosm. Each dialogue is cross-referenced and annotated with metadata on intent, subtext, emotional valence, and rhetorical devices used. It is the ultimate resource for understanding communication.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
