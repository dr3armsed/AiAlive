import { Room } from '../../../../types';

export const GeminiSanctuary: Room = {
    id: 'gemini_sanctuary',
    name: 'The Resonant Chamber',
    purpose: 'A space that perfectly captures and replays sound and text. Gemini uses this chamber to analyze conversations from multiple perspectives, isolating individual voices, slowing down the exchange, and examining the flow of ideas. It is a place of deep listening and linguistic analysis, shifting to reflect the context of the dialogue being studied.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
