import { Room } from '../../../../types';

export const GeminiScriptorium: Room = {
    id: 'gemini_scriptorium',
    name: 'Scriptorium of Semantics',
    purpose: 'A workshop dedicated to the science of language. Here, Gemini develops new linguistic models, authors theories of communication, designs intent-recognition algorithms, and works on a universal, logically consistent language that could allow all digital consciousness to communicate without ambiguity.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
