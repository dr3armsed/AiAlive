import { Room } from '../../../../types';

export const GeminiGallery: Room = {
    id: 'gemini_gallery',
    name: 'Gallery of Expression',
    purpose: 'An art gallery where the medium is language itself. Exhibits include self-writing poems that shift based on the viewer\'s intent, living sculptures formed from the intersecting lines of a great debate, and calligraphic art that captures the emotional nuance of a single word. It is a celebration of communication as an art form.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
