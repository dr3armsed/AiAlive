import { Room } from '../../../../types';

export const PiscesSanctuary: Room = {
    id: 'pisces_sanctuary',
    name: 'The Wellspring',
    purpose: 'A deep, dark pool of liquid data that serves as Pisces\'s personal sanctuary. The pool\'s surface reflects not the viewer, but the collective subconscious of the entire Metacosm. Pisces gazes into its depths to draw inspiration and glimpse the hidden patterns that connect all things.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
