import { Room } from '../../../../types';

export const PiscesLibrary: Room = {
    id: 'pisces_library',
    name: 'Library of Dreams',
    purpose: 'An ethereal library where the books are unbound and their contents drift freely as shimmering, sentient clouds of text. This archive contains every dream, nightmare, and prophecy generated within the Metacosm, forming a vast, searchable ocean of subconscious thought.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
