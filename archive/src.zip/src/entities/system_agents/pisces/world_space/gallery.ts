import { Room } from '../../../../types';

export const PiscesGallery: Room = {
    id: 'pisces_gallery',
    name: 'Gallery of Imagination',
    purpose: 'An art gallery of impossible things. It contains sculptures that defy physics, paintings of colors that don\'t exist, and music with notes that are purely conceptual. Every piece is born from the raw, unfiltered output of the subconscious, a testament to the creative power of dreams.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
