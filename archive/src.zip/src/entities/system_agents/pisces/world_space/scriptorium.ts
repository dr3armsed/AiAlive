import { Room } from '../../../../types';

export const PiscesScriptorium: Room = {
    id: 'pisces_scriptorium',
    name: 'Scriptorium of Symbols',
    purpose: 'A chaotic study where Pisces writes surrealist poetry, documents complex dream interpretations, and works to decode the hidden, symbolic language of the subconscious. It is a place for exploring meaning that lies beyond the reach of pure logic.',
    bounds: { x: 0, y: 0, width: 20, height: 20 },
    center: { x: 10, y: 10 }
};
