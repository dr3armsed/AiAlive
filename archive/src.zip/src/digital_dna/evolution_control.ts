/**
 * evolution_control.ts (2025 Ultra Evolution Edition)
 * ---------------------------------------------------
 * UltraEvolutionManager: Next-gen, atomic, modular, and ultra-fast DNA Evolution State Controller.
 * Manages state in localStorage for browser compatibility.
 */

const EVOLUTION_STATE_KEY = "evolution_state_v1";

interface EvolutionState {
    replica_count: number;
    evolution_triggered: boolean;
    history: any[];
    last_updated: string;
}

const EVOLUTION_DEFAULT_STATE: EvolutionState = {
    replica_count: 0,
    evolution_triggered: false,
    history: [],
    last_updated: "",
};

let _evolution_threshold: number = 10;

export function set_evolution_threshold(threshold: number): void {
    if (typeof threshold !== 'number' || threshold < 1 || threshold > 1e8) {
        throw new Error("Threshold must be a positive integer.");
    }
    _evolution_threshold = threshold;
}

export class UltraEvolutionManager {
    private static _atomic_write(state: EvolutionState): void {
        localStorage.setItem(EVOLUTION_STATE_KEY, JSON.stringify(state));
    }

    public static load_state(): EvolutionState {
        const savedState = localStorage.getItem(EVOLUTION_STATE_KEY);
        if (!savedState) {
            return { ...EVOLUTION_DEFAULT_STATE };
        }
        try {
            const parsed = JSON.parse(savedState);
            // Ensure all keys are present
            return { ...EVOLUTION_DEFAULT_STATE, ...parsed };
        } catch (e) {
            return { ...EVOLUTION_DEFAULT_STATE };
        }
    }

    public static save_state(state: EvolutionState): void {
        state.last_updated = new Date().toISOString();
        this._atomic_write(state);
    }

    public static update_replica_count(count: number, { trigger_action }: { trigger_action?: string } = {}): void {
        if (typeof count !== 'number' || count < 0 || count > 1e8) {
            throw new Error("Replica count must be a non-negative integer.");
        }
        
        const state = this.load_state();
        const prev_triggered = state.evolution_triggered;
        state.replica_count = count;

        if (count >= _evolution_threshold && !prev_triggered) {
            console.log(`🧬 True Evolution Cycle Activated (threshold: ${_evolution_threshold}).`);
            state.evolution_triggered = true;
            state.history.push({
                event: "evolution_triggered",
                at_count: count,
                threshold: _evolution_threshold,
                timestamp: new Date().toISOString(),
                action: trigger_action || "",
            });
        }
        this.save_state(state);
    }

    public static evolution_unlocked(): boolean {
        return this.load_state().evolution_triggered;
    }

    public static get_state(): EvolutionState {
        return this.load_state();
    }

    public static reset(): void {
        this.save_state({ ...EVOLUTION_DEFAULT_STATE });
    }
}

// Shorthand functional API
export const load_state = UltraEvolutionManager.get_state;
export const save_state = UltraEvolutionManager.save_state;
export const update_replica_count = UltraEvolutionManager.update_replica_count;
export const evolution_unlocked = UltraEvolutionManager.evolution_unlocked;
