// ==================== CORE GENETIC SYSTEMS ====================

// Nuclear DNA
export { DigitalDNA, Gene, GenomeTopology } from './digital_dna';
export type { Gene } from './digital_digital_dna';

// RNA Transcription
export { DigitalRNA, RNAStructure } from './digital_rna';

// Instructions
export { 
    InstructionKey, 
    DNAInstructionTemplate, 
    UltraInstructionSet,
    INSTRUCTION_SET,
    INSTRUCTION_DESCRIPTIONS
} from './instructions';

// Engine & Utilities
export {
    encode_bytes,
    decode_bytes,
    encode_function,
    load_function_from_dna,
    checksum_dna,
    dna_fingerprint,
    ultra_dna_mutate
} from './engine';

// Evolution & Testing
export { Replica, TestReport } from './replica';
export { 
    runEvolutionaryAlgorithm, 
    EvolutionaryRunReport, 
    GenerationStats 
} from './self_training';
export { 
    spawn_replica, 
    load_replica_program, 
    query_replicas, 
    get_lineage, 
    prune_archive 
} from './replica_manager';

// Self-Repair
export { Codex, test_codex_autopatch } from './python_codex';
export { deep_diagnose_error, fix_theory_for_code } from './diagnostics';

// Communication
export { ConverseAgent } from './converse_agent';

// Logging
export { log_success, log_failure, log_event, get_log_history } from './logger';

// Evolution Control
export { 
    UltraEvolutionManager, 
    set_evolution_threshold, 
    load_state,
    save_state,
    update_replica_count,
    evolution_unlocked
} from './evolution_control';

// ==================== BIOLOGICAL SUBSTRATES ====================

// Mitochondrial DNA (Energy System)
export { DigitalChondria, MitochondrialGene, MetabolicState } from './mitochondria';

// Epigenetics (Environmental Regulation)
export { 
    DigitalEpigenome, 
    EpigeneticMarker, 
    ChromatinState, 
    EnvironmentalEpigeneticFactor 
} from './epigenetics';

// ==================== NON-CODING RNA SYSTEMS ====================

export {
    DigitalcircRNA,
    DigitalIncRNA,
    DigitalmiRNA,
    DigitalpiRNA,
    DigitalrRNA,
    DigitalsiRNA,
    DigitaltRNA,
    DigitalXNA
} from './ncrna';

export type {
    circRNALoop,
    CleavageForensics,
    miRNAStrand,
    tRNAChargeProfile
} from './ncrna';

export type { Gene } from './digital_digital_dna';
export type { RNAStructure } from './digital_rna';