/**
 * replica_manager.ts -> Now The DNA Lineage & Archive System (DLAS)
 *
 * UltraDNA Quantum Hyper-Replica Manager v3040+ (2025–2040+)
 * TypeScript, browser-compatible version using localStorage and advanced data structures.
 * Manages the entire lifecycle, lineage, and archival of genetic material (DNA).
 *
 * NOTE: JSON serialization cannot store functions or complex class instances with methods.
 * This manager stores DNA instruction keys and metadata, not live objects.
 */

import { ReplicaMetadata, StoredReplica } from '../types';
import { checksum_dna } from './engine';

const REPLICA_STORAGE_KEY = "dla_storage_v1";
const MAX_ARCHIVED_REPLICAS = 500;
let _PATCHPLAN_LOG: any[] = []; // Re-declared locally to avoid module conflicts

class ReplicaManagerError extends Error {}

function getArchive(): Record<string, StoredReplica> {
    const saved = localStorage.getItem(REPLICA_STORAGE_KEY);
    return saved ? JSON.parse(saved) : {};
}

function saveArchive(archive: Record<string, StoredReplica>): void {
    localStorage.setItem(REPLICA_STORAGE_KEY, JSON.stringify(archive));
}

/**
 * Returns the entire replica archive.
 * @returns An object containing all stored replicas.
 */
export function get_all_replicas(): Record<string, StoredReplica> {
    return getArchive();
}

/**
 * Spawns a new replica in the archive.
 * @param program - The object to be stored, must have a `dna` property.
 * @param metadata - Rich metadata about the replica's creation.
 * @returns The unique ID of the spawned replica.
 */
export async function spawn_replica(program: { dna: { instruction_keys: string[] } }, metadata: ReplicaMetadata): Promise<string> {
    const dnaString = program.dna.instruction_keys.join(',');
    const id = `rep_${metadata.generation}_${await checksum_dna(dnaString)}`;
    const checksum = await checksum_dna(JSON.stringify(program));
    
    const replica: StoredReplica = {
        program,
        metadata,
        checksum,
        timestamp: new Date().toISOString(),
    };

    const archive = getArchive();
    archive[id] = replica;
    saveArchive(archive);
    
    return id;
}

/**
 * Loads a replica's program data from the archive, verifying its integrity.
 * @param id - The unique ID of the replica to load.
 * @returns The stored program object.
 */
export async function load_replica_program(id: string): Promise<any> {
    const archive = getArchive();
    const replica = archive[id];
    if (!replica) {
        throw new ReplicaManagerError(`Replica with ID ${id} not found.`);
    }

    const currentChecksum = await checksum_dna(JSON.stringify(replica.program));
    if (currentChecksum !== replica.checksum) {
        throw new ReplicaManagerError(`Data integrity check failed for replica ${id}.`);
    }

    return replica.program;
}

export function get_replica_metadata(id: string): ReplicaMetadata {
    const archive = getArchive();
    const replica = archive[id];
    if (!replica) {
        throw new ReplicaManagerError(`Replica with ID ${id} not found.`);
    }
    return replica.metadata;
}


/**
 * Queries the archive for replicas matching the given criteria.
 * @param filters - An object of filters, e.g., { generation: 5, minFitness: 100 }.
 * @returns An array of replica IDs that match the criteria.
 */
export function query_replicas(filters: { generation?: number; minFitness?: number; parentId?: string }): string[] {
    const archive = getArchive();
    return Object.entries(archive)
        .filter(([id, replica]) => {
            if (filters.generation !== undefined && replica.metadata.generation !== filters.generation) return false;
            if (filters.minFitness !== undefined && (replica.metadata.fitness || -Infinity) < filters.minFitness) return false;
            if (filters.parentId !== undefined && replica.metadata.parentId !== filters.parentId) return false;
            return true;
        })
        .map(([id]) => id);
}

/**
 * Traces the lineage of a replica back to its origin.
 * @param id - The ID of the replica to trace.
 * @returns An array of replica IDs representing the lineage.
 */
export function get_lineage(id: string): string[] {
    const lineage: string[] = [id];
    const archive = getArchive();
    let currentId = id;

    while (archive[currentId]?.metadata.parentId) {
        const parentId = archive[currentId].metadata.parentId!;
        if (lineage.includes(parentId)) break; // Cycle detected
        lineage.unshift(parentId);
        currentId = parentId;
    }
    return lineage;
}

/**
 * Prunes the archive to maintain a healthy and manageable gene pool.
 * It removes the oldest and lowest-fitness replicas.
 */
export function prune_archive(): void {
    const archive = getArchive();
    let replicas = Object.entries(archive);

    if (replicas.length <= MAX_ARCHIVED_REPLICAS) return;

    // Sort by fitness (ascending) then by date (ascending)
    replicas.sort(([, a], [, b]) => {
        const fitnessA = a.metadata.fitness ?? -Infinity;
        const fitnessB = b.metadata.fitness ?? -Infinity;
        if (fitnessA !== fitnessB) return fitnessA - fitnessB;
        return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    });

    const numberToRemove = replicas.length - MAX_ARCHIVED_REPLICAS;
    const removedIds = replicas.slice(0, numberToRemove).map(([id]) => id);

    const newArchive = { ...archive };
    removedIds.forEach(id => delete newArchive[id]);
    saveArchive(newArchive);
    console.log(`[DLAS] Pruned ${numberToRemove} replicas from the archive.`);
}
