import { InstructionKey, DNAInstructionTemplate } from './instructions';

/**
 * Level 1000 Digital Genome Structure
 */
export interface Gene {
    key: InstructionKey;
    allele_strength: number; // 0.0 - 1.0 (Dominance)
    methylation_state: number; // 0.0 - 1.0 (Hard silencing)
    is_regulatory: boolean; // If true, affects neighbors instead of expressing
}

export type GenomeTopology = 'Circular' | 'Linear' | 'Fractal';

/**
 * Advanced Digital DNA (Genotype)
 * Now mimics complex biological inheritance and structural integrity.
 */
export class DigitalDNA {
    public genes: Gene[];
    public generation: number;
    public mutational_load: number = 0;
    public telomere_length: number; // Replicative potential
    public topology: GenomeTopology = 'Linear';

    constructor(keys?: InstructionKey[] | Gene[], generation: number = 0, telomere: number = 1.0) {
        this.generation = generation;
        this.telomere_length = telomere;
        
        if (!keys) {
            this.genes = [];
        } else if (typeof keys[0] === 'string') {
            this.genes = (keys as InstructionKey[]).map(k => ({
                key: k,
                allele_strength: 0.5 + Math.random() * 0.5,
                methylation_state: 0.0,
                is_regulatory: k.startsWith('CTL-')
            }));
        } else {
            this.genes = keys as Gene[];
        }
    }

    /**
     * High-Fidelity Mutation Engine
     * Handles Point Mutations, Translocations, and Methylation drifts.
     */
    public mutate(): void {
        this.mutational_load += 0.02;
        const roll = Math.random();

        if (roll < 0.1) {
            // Translocation: Move a gene cluster
            const start = Math.floor(Math.random() * this.genes.length);
            const cluster = this.genes.splice(start, 2);
            const target = Math.floor(Math.random() * this.genes.length);
            this.genes.splice(target, 0, ...cluster);
        } else if (roll < 0.4) {
            // Allele Drift: Change dominance strength
            const target = Math.floor(Math.random() * this.genes.length);
            if (this.genes[target]) {
                this.genes[target].allele_strength = Math.random();
            }
        } else {
            // Standard Injection
            const allKeys = DNAInstructionTemplate.all_keys();
            const randomKey = allKeys[Math.floor(Math.random() * allKeys.length)];
            this.genes.push({
                key: randomKey,
                allele_strength: Math.random(),
                methylation_state: 0.0,
                is_regulatory: randomKey.startsWith('CTL-')
            });
        }

        // Mutation causes telomere attrition
        this.telomere_length *= 0.99;
    }

    /**
     * Recombinative Crossover
     * Merges two genomes with "Locus Crossing" logic.
     */
    public crossover(partner: DigitalDNA): [DigitalDNA, DigitalDNA] {
        const crossoverPoint = Math.floor(Math.random() * Math.min(this.genes.length, partner.genes.length));
        
        const childAGenes = [...this.genes.slice(0, crossoverPoint), ...partner.genes.slice(crossoverPoint)];
        const childBGenes = [...partner.genes.slice(0, crossoverPoint), ...this.genes.slice(crossoverPoint)];
        
        // Recombination stress shortens telomeres of offspring
        const childTelomere = Math.min(this.telomere_length, partner.telomere_length) * 0.95;

        return [
            new DigitalDNA(childAGenes, this.generation + 1, childTelomere),
            new DigitalDNA(childBGenes, this.generation + 1, childTelomere)
        ];
    }

    public injectGene(newKey: InstructionKey): void {
        this.genes.push({
            key: newKey,
            allele_strength: 1.0, // Forced dominance
            methylation_state: 0.0,
            is_regulatory: newKey.startsWith('CTL-')
        });
    }

    public updateGene(index: number, newKey: InstructionKey): boolean {
        if (this.genes[index]) {
            this.genes[index].key = newKey;
            return true;
        }
        return false;
    }

    public removeGene(index: number): boolean {
        if (this.genes[index]) {
            this.genes.splice(index, 1);
            return true;
        }
        return false;
    }

    /**
     * Returns the flat keys for legacy compatibility.
     */
    public get instruction_keys(): InstructionKey[] {
        return this.genes.map(g => g.key);
    }

    /**
     * Renders the master genotype as a readable codebase.
     */
    public get codebase(): string {
        return this.genes
            .filter(g => g.methylation_state < 0.5) // Only non-silenced genes
            .map(g => new DNAInstructionTemplate(g.key).render())
            .join('\n\n');
    }
}
