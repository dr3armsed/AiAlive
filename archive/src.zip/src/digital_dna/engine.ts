/**
 * UltraX Digital DNA Engine — Evolution Core (engine.ts/v3+ 2025–2050)
 * --------------------------------------------------------------------
 * TypeScript conversion of the high-performance DNA engine.
 */

// ========== DNA CHARSET AND GLOSSARY ==========

export const DNA_CHARSET: string = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_/";

// ========== PERFORMANCE — FASTPATH STRING ENCODING/DECODING ==========

export function encode_bytes(data: Uint8Array): string {
    let binary = '';
    const len = data.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(data[i]);
    }
    const base64 = btoa(binary);
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

export function decode_bytes(data: string): Uint8Array {
    let base64 = data.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
        base64 += '=';
    }
    try {
        const binaryString = atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes;
    } catch (e) {
        throw new Error(`Failed to decode DNA bytes: ${e}`);
    }
}

// ========== FUNCTION ENCODING/DECODING — ATOMIC AND AUDITABLE ==========

// eslint-disable-next-line @typescript-eslint/ban-types
export function encode_function(func: Function): string {
    if (typeof func !== 'function') {
        throw new TypeError("encode_function expects a callable.");
    }
    const src = func.toString();
    const encoder = new TextEncoder();
    return encode_bytes(encoder.encode(src));
}

// eslint-disable-next-line @typescript-eslint/ban-types
export function load_function_from_dna(
    dna: string,
    globals_ns?: Record<string, any>,
    { auto_audit = true }: { auto_audit?: boolean } = {}
): Function {
    const decoder = new TextDecoder();
    const src = decoder.decode(decode_bytes(dna));

    if (auto_audit) {
        const dangerous = ["os.", "eval(", "subprocess", "exec(", "input(", "sys.", "__import__"];
        for (const bad of dangerous) {
            if (src.includes(bad)) {
                throw new Error(`Unsafe function DNA: detected ${bad} in decoded source.`);
            }
        }
    }
    
    try {
        // Using new Function is safer than eval
        return new Function(`return ${src}`)();
    } catch (e) {
        throw new Error(`DNA function decode/exec failed: ${e}\n${src}`);
    }
}


// ========== DNA CHECKSUM & FINGERPRINT ==========

export async function checksum_dna(dna: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(dna);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex.substring(0, 16);
}

export async function dna_fingerprint(obj: any): Promise<string> {
    const str = JSON.stringify(obj);
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex.substring(0, 20);
}


// ========== DNA MUTATION ENGINE ==========

export function ultra_dna_mutate(dna: string, explain: boolean = false): string {
    const data = decode_bytes(dna);
    const b = new Uint8Array(data);
    if (b.length === 0) return dna;

    const mode = ["flip", "swap", "permute", "xor", "block"][Math.floor(Math.random() * 5)];
    let explanation = '';

    if (mode === "flip") {
        const idx = Math.floor(Math.random() * b.length);
        b[idx] ^= 0xFF;
        explanation = `flip at ${idx}`;
    } else if (mode === "swap" && b.length > 1) {
        const i = Math.floor(Math.random() * b.length);
        const j = Math.floor(Math.random() * b.length);
        [b[i], b[j]] = [b[j], b[i]];
        explanation = `swap ${i} <-> ${j}`;
    } else { // Fallback
        const idx = Math.floor(Math.random() * b.length);
        b[idx] = Math.floor(Math.random() * 256);
        explanation = `randbyte at ${idx}`;
    }

    if (explain) {
        console.log(`[DNA-Mutate explain] Mode: ${mode}, ${explanation}, len=${b.length}`);
    }

    return encode_bytes(b);
}
