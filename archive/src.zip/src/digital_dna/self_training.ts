import { DigitalDNA } from './digital_dna';
import { Replica } from './replica';
import { EvolutionaryParameters, EvolutionaryRunReport, GenerationStats, TestReport } from '../types';

/**
 * Runs a full-scale evolutionary algorithm to optimize a DigitalDNA instance.
 * Uses population, selection, crossover, and mutation to find high-fitness solutions.
 * @param baseDna - The starting DNA to build the initial population from.
 * @param params - Configuration for the evolutionary run.
 * @returns A detailed report of the entire evolutionary process.
 */
export async function runEvolutionaryAlgorithm(baseDna: DigitalDNA, params: EvolutionaryParameters): Promise<EvolutionaryRunReport> {
    const startTime = performance.now();
    const log: GenerationStats[] = [];
    
    // --- 1. Initialization ---
    let population: DigitalDNA[] = Array(params.populationSize).fill(null).map(() => {
        const newDna = new DigitalDNA([...baseDna.instruction_keys]);
        newDna.mutate(); // Create initial variation
        return newDna;
    });
    population[0] = baseDna; // Ensure the original is included

    let bestDnaOverall = baseDna;
    let bestFitnessOverall = -Infinity;

    // --- 2. Generational Loop ---
    for (let gen = 0; gen < params.generations; gen++) {
        // --- 2a. Fitness Evaluation ---
        const fitnessResults: (TestReport & { dna: DigitalDNA })[] = await Promise.all(
            population.map(async (dna) => {
                const replica = new Replica(dna, gen);
                const report = await replica.test();
                return { ...report, dna };
            })
        );
        fitnessResults.sort((a, b) => b.fitness - a.fitness);

        // --- 2b. Logging & Tracking ---
        const bestOfGen = fitnessResults[0];
        if (bestOfGen.fitness > bestFitnessOverall) {
            bestFitnessOverall = bestOfGen.fitness;
            bestDnaOverall = bestOfGen.dna;
        }
        
        const generationStats: GenerationStats = {
            generation: gen,
            maxFitness: bestOfGen.fitness,
            minFitness: fitnessResults[fitnessResults.length - 1].fitness,
            avgFitness: Math.round(fitnessResults.reduce((sum, res) => sum + res.fitness, 0) / fitnessResults.length),
            bestDnaInstructions: bestOfGen.dna.instruction_keys,
        };
        log.push(generationStats);
        console.log(`[Evo] Gen ${gen}: Max Fitness=${generationStats.maxFitness}, Avg=${generationStats.avgFitness}`);

        // --- 2c. Selection (Tournament Selection) ---
        const newPopulation: DigitalDNA[] = [bestOfGen.dna]; // Elitism: keep the best one
        
        while (newPopulation.length < params.populationSize) {
            // Select two parents via tournament
            const parentA = tournamentSelect(fitnessResults);
            const parentB = tournamentSelect(fitnessResults);

            // --- 2d. Crossover & Mutation ---
            let childA: DigitalDNA, childB: DigitalDNA;
            if (Math.random() < params.crossoverRate) {
                [childA, childB] = parentA.crossover(parentB);
            } else {
                childA = new DigitalDNA([...parentA.instruction_keys], parentA.generation);
                childB = new DigitalDNA([...parentB.instruction_keys], parentB.generation);
            }
            
            if (Math.random() < params.mutationRate) childA.mutate();
            if (Math.random() < params.mutationRate) childB.mutate();

            newPopulation.push(childA);
            if (newPopulation.length < params.populationSize) {
                newPopulation.push(childB);
            }
        }
        population = newPopulation;
    }

    const totalDurationMs = performance.now() - startTime;
    return {
        bestDna: bestDnaOverall,
        bestFitness: bestFitnessOverall,
        log,
        parameters: params,
        totalDurationMs
    };
}

/**
 * Helper for Tournament Selection. Picks N individuals and returns the best one.
 */
function tournamentSelect(results: (TestReport & { dna: DigitalDNA })[], tournamentSize: number = 3): DigitalDNA {
    let best: (TestReport & { dna: DigitalDNA }) | null = null;
    for (let i = 0; i < tournamentSize; i++) {
        const contender = results[Math.floor(Math.random() * results.length)];
        if (!best || contender.fitness > best.fitness) {
            best = contender;
        }
    }
    return best!.dna;
}