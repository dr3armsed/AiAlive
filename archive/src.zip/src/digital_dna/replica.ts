
import { DigitalDNA } from './digital_dna';
import { simulateCodeExecution } from '../services/geminiServices/index';
import { TestReport } from '../types';

/**
 * Level-1000 Quantum Replica
 * An advanced, testable instance of a digital entity's DNA.
 * Capable of undergoing rigorous, multi-faceted fitness evaluations.
 */
export class Replica {
    public dna: DigitalDNA;
    public generation: number;

    constructor(dna: DigitalDNA, generation: number) {
        this.dna = dna;
        this.generation = generation;
    }

    /**
     * Executes an advanced, multi-metric fitness test on the replica's DNA.
     * @param context - Optional context to simulate different environmental conditions.
     * @returns A detailed TestReport object.
     */
    async test(context?: any): Promise<TestReport> {
        const startTime = performance.now();
        const logs: string[] = [];
        let fitness = 0;
        let estimatedQuintessenceCost = 0;

        if (!this.dna.instruction_keys || this.dna.instruction_keys.length === 0) {
            return {
                fitness: 0,
                logs: ["No instructions to test."],
                executionTimeMs: 0,
                estimatedQuintessenceCost: 0,
                noveltyScore: 0,
                securityAudit: { passed: true, issues: [] }
            };
        }

        const codeToRun = this.dna.codebase || '';
        const executionResult = await simulateCodeExecution(codeToRun, this.dna);

        // --- Metric Calculation ---
        const executionTimeMs = performance.now() - startTime;
        const securityAudit = this.performSecurityAudit(codeToRun);
        const noveltyScore = this.dna.instruction_keys.length > 0 ? new Set(this.dna.instruction_keys).size / this.dna.instruction_keys.length : 0; // Ratio of unique instructions

        // Base cost + cost per instruction
        estimatedQuintessenceCost = 5 + this.dna.instruction_keys.length * 2;

        if (executionResult.success) {
            fitness += 50; // Base success reward
            logs.push(`Execution successful. Output: ${executionResult.output}`);
            if (executionResult.output.includes("Result:")) fitness += 20; // Bonus for completing calculation
            if (executionResult.output.length > 10) fitness += 5; // Bonus for non-trivial output
        } else {
            fitness -= 100; // Major penalty for failure
            logs.push(`Execution failed. Error: ${executionResult.error}`);
            estimatedQuintessenceCost *= 2; // Failed actions are costly
        }

        // --- Fitness Adjustment based on metrics ---
        // Penalize long execution times
        fitness -= Math.max(0, (executionTimeMs - 10)) * 0.5;
        // Penalize high quintessence cost
        fitness -= estimatedQuintessenceCost * 0.2;
        // Reward novelty
        fitness += noveltyScore * 10;
        // Penalize security issues
        if (!securityAudit.passed) fitness -= 50 * securityAudit.issues.length;

        return {
            fitness: Math.round(fitness),
            logs,
            executionTimeMs,
            estimatedQuintessenceCost,
            noveltyScore,
            securityAudit
        };
    }
    
    private performSecurityAudit(code: string): { passed: boolean; issues: string[] } {
        const issues: string[] = [];
        const forbiddenPatterns = ['eval(', '__import__', 'os.', 'sys.']; // Simplified list
        
        for (const pattern of forbiddenPatterns) {
            if (code.includes(pattern)) {
                issues.push(`Forbidden pattern found: ${pattern}`);
            }
        }
        
        return {
            passed: issues.length === 0,
            issues
        };
    }
}