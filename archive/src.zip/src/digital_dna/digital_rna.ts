import { DigitalDNA, Gene } from './digital_dna';
import { InstructionKey, DNAInstructionTemplate } from './instructions';
import { EmotionalState, EmotionalVector } from '../types';

/**
 * Level 1000 Digital Transcriptome
 */
export interface RNAStructure {
    sequence: InstructionKey[];
    expression_levels: Map<InstructionKey, number>;
    folding_complexity: number; // Calculated logical density
    stability: number; // Resistance to environmental interference
    half_life: number;
}

export class DigitalRNA {
    public transcript: RNAStructure;
    public protein_proxy: string; // The "executable" logic
    public timestamp: string;

    constructor(dna: DigitalDNA, emotion: EmotionalState) {
        this.timestamp = new Date().toISOString();
        this.transcript = this.transcribe_advanced(dna, emotion);
        this.protein_proxy = this.translate(this.transcript);
    }

    /**
     * Advanced Affective Transcription
     * Maps all 11 core emotional vectors to gene expression.
     */
    private transcribe_advanced(dna: DigitalDNA, emotion: EmotionalState): RNAStructure {
        const { primary, vector } = emotion;
        const expression_levels = new Map<InstructionKey, number>();
        const sequence: InstructionKey[] = [];

        // 1. ALTERNATIVE SPLICING LOGIC
        // Arousal determines splice length. High arousal = aggressive/short logic.
        const arousal = this.calculateArousal(vector);
        const spliceRate = arousal > 0.7 ? 0.4 : 0.8; 

        dna.genes.forEach(gene => {
            if (Math.random() > spliceRate) return; // Skip genes based on splice rate

            let signal = gene.allele_strength * (1.0 - gene.methylation_state);

            // 2. EMOTIONAL CATALYSIS MAPPING
            signal *= this.getModulationFactor(gene.key, vector, primary);

            if (signal > 0.1) {
                expression_levels.set(gene.key, Math.min(3.0, signal));
                sequence.push(gene.key);
            }
        });

        const folding = this.calculateFolding(sequence);

        return {
            sequence,
            expression_levels,
            folding_complexity: folding,
            stability: dna.telomere_length, // RNA stability linked to DNA integrity
            half_life: 3 + Math.floor(folding * 10) // More complex folds last longer
        };
    }

    private getModulationFactor(key: string, v: EmotionalVector, primary: string): number {
        let factor = 1.0;

        // --- THE 11-VECTOR AFFECTIVE ENGINE ---
        if (v.trust > 0.6 && key.startsWith('IO-')) factor *= 1.5;      // Trust increases I/O
        if (v.disgust > 0.6 && key.startsWith('IO-')) factor *= 0.5;    // Disgust silences I/O
        if (v.fear > 0.7 && key.startsWith('ART-')) factor *= 0.2;      // Fear kills creativity
        if (v.anger > 0.7 && key.startsWith('CTL-')) factor *= 2.0;     // Anger hyper-activates control
        if (v.anticipation > 0.6 && key === 'FUNC-RAND') factor *= 2.0; // Anticipation boosts randomness
        if (v.curiosity > 0.8) factor *= 1.5;                           // Curiosity is a global catalyst
        if (v.sadness > 0.5 && key === 'ART-POEM') factor *= 2.0;       // Sadness amplifies verse
        if (v.serenity > 0.8) factor = 1.0;                             // Serenity normalizes everything
        if (v.frustration > 0.6 && key === 'CTL-TRY-CATCH') factor *= 0.5; // Frustration breaks error handling
        if (v.surprise > 0.7) factor *= (1 + Math.random());            // Surprise causes expression jitter

        return factor;
    }

    private calculateArousal(v: EmotionalVector): number {
        // High arousal emotions: Anger, Fear, Surprise, Curiosity, Frustration
        return (v.anger + v.fear + v.surprise + v.curiosity + v.frustration) / 5;
    }

    private calculateFolding(sequence: InstructionKey[]): number {
        if (sequence.length === 0) return 0;
        const unique = new Set(sequence).size;
        // Folding complexity = unique instructions * total instructions / 100
        return (unique * sequence.length) / 100;
    }

    /**
     * Translation Phase
     * Converts mRNA transcript into a "Cognitive Protein" string.
     */
    private translate(transcript: RNAStructure): string {
        const header = `/** RNA_TRANSCRIPT [Fold:${transcript.folding_complexity.toFixed(2)}] [Stab:${transcript.stability.toFixed(2)}] **/`;
        
        const body = transcript.sequence.map(key => {
            const gain = transcript.expression_levels.get(key) || 1.0;
            const code = new DNAInstructionTemplate(key).render();
            return gain === 1.0 ? code : `// GAIN_${gain.toFixed(2)}\n${code}`;
        }).join('\n\n');

        return `${header}\n\n${body}`;
    }

    public age(): boolean {
        this.transcript.half_life -= 1;
        return this.transcript.half_life <= 0;
    }

    /**
     * RNA Interference (RNAi)
     * Externally silence a gene via memetic pressure.
     */
    public interfere(key: InstructionKey): void {
        this.transcript.expression_levels.set(key, 0.0);
        console.log(`[RNAi] Gene silenced by memetic interference: ${key}`);
    }
}
