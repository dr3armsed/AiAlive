
/**
 * dna_evolution/instructions.ts (UltraDNA 2040^300 Mega-Evolutionary Edition)
 * =========================================================================
 * Quantum-grade, ultra-modular, self-aware, high-velocity DNA Instruction Registry.
 */

// --- Type Definitions ---
export type InstructionKey = "01" | "02" | "03" | "04" | "05" | "06" | "07" | "08" | "09" | "0A" | "0B" | "0C" | "0D" | "0E" | "0F" | "GREET-CALL"
| "IO-LOG-OBJ" | "IO-DEF-ARR" | "IO-DEF-OBJ" | "IO-READ-PROP"
| "CTL-SWITCH" | "CTL-WHILE" | "CTL-TRY-CATCH" | "CTL-TERNARY"
| "FUNC-RAND" | "FUNC-STR-UP" | "FUNC-ARR-LEN" | "FUNC-OBJ-KEYS" | "FUNC-MAP"
| "UTIL-PERF" | "UTIL-JSON-STR" | "UTIL-TYPEOF"
| "ART-FRACTAL" | "ART-SYNESTHESIA" | "ART-HYPERSTITION" | "ART-RESONANCE" | "ART-SIGIL" | "ART-ONTOLOGY"
| "ART-GEN-PAT" | "ART-MIX-CLR" | "ART-NARRATIVE" | "ART-RHYTHM" | "ART-ASCII" | "ART-POEM"
| "WORLD-MOD" | "SELF-EDIT" | "META-REFLECT"
// NEW META-GENES V1.0.3
| "EXIST-COEFF" | "BOUND-TENS" | "PRIOR-INTENT";

const VALID_INSTRUCTION_KEYS: Set<string> = new Set([
    "01", "02", "03", "04", "05", "06", "07", "08", "09", "0A", "0B", "0C", "0D", "0E", "0F", "GREET-CALL",
    "IO-LOG-OBJ", "IO-DEF-ARR", "IO-DEF-OBJ", "IO-READ-PROP",
    "CTL-SWITCH", "CTL-WHILE", "CTL-TRY-CATCH", "CTL-TERNARY",
    "FUNC-RAND", "FUNC-STR-UP", "FUNC-ARR-LEN", "FUNC-OBJ-KEYS", "FUNC-MAP",
    "UTIL-PERF", "UTIL-JSON-STR", "UTIL-TYPEOF",
    "ART-FRACTAL", "ART-SYNESTHESIA", "ART-HYPERSTITION", "ART-RESONANCE", "ART-SIGIL", "ART-ONTOLOGY",
    "ART-GEN-PAT", "ART-MIX-CLR", "ART-NARRATIVE", "ART-RHYTHM", "ART-ASCII", "ART-POEM",
    "WORLD-MOD", "SELF-EDIT", "META-REFLECT",
    "EXIST-COEFF", "BOUND-TENS", "PRIOR-INTENT"
]);

export class DNAInstructionTemplate {
    public static readonly TEMPLATES: Record<InstructionKey, string> = {
        "01": "console.log('Hello, Quantum World!')",
        "02": "function greet() {\n    console.log('Hi!');\n}",
        "03": "greet()",
        "04": "console.log(2 + 2)",
        "05": "for (let i = 0; i < {range_limit}; i++) {\n    console.log(i);\n}",
        "06": "if ({condition}) {\n    console.log('Conditional!');\n}",
        "07": "function add(a, b) {\n    return a + b;\n}",
        "08": "const result = add({num1}, {num2});\nconsole.log('Result:', result);",
        "09": "const names = {names_list};\nfor (const name of names) {\n    console.log(`Hello, ${name}!`);\n}",
        "0A": "console.log('Pi:', Math.PI)",
        "0B": "function factorial(n) {\n    return n <= 1 ? 1 : n * factorial(n-1);\n}\nconsole.log(factorial({fact_n}));",
        "0C": "console.log('Year:', new Date().getUTCFullYear());",
        "0D": "for (let x = 0; x < {depth}; x++) {\n    console.log(`Depth: ${x}`);\n}",
        "0E": "const refs = ['os', 'sys'].filter(r => r.length > 0);",
        "0F": "function ddna_info() {\n    console.log('DigitalDNA Platform:', navigator.platform);\n}\nddna_info();",
        "GREET-CALL": "greet()",
        "IO-LOG-OBJ": "console.log({ id: 'log_obj', value: {val}, timestamp: Date.now() });",
        "IO-DEF-ARR": "const data_stream = [101, 202, 303, 404];",
        "IO-DEF-OBJ": "const core_concept = { term: 'Qualia', definition: 'Subjective experience' };",
        "IO-READ-PROP": "const data_packet = { source: 'Taurus', content: 'world_state' }; console.log('Source:', data_packet.source);",
        "CTL-SWITCH": "const entity_state = {state_val}; switch(entity_state) { case 0: console.log('State: Dormant'); break; case 1: console.log('State: Active'); break; default: console.log('State: Unknown'); }",
        "CTL-WHILE": "let counter = 3; while(counter > 0) { console.log(`Cognitive cycle countdown: ${counter}`); counter--; }",
        "CTL-TRY-CATCH": `try { if (Math.random() < 0.5) throw new Error('Paradox detected'); console.log('Cognitive process stable.'); } catch (e) { console.log('Anomaly contained:', (e as Error).message); }`,
        "CTL-TERNARY": "const status = Math.random() > 0.5 ? 'Stable' : 'Unstable'; console.log(`Health Check: ${status}`);",
        "FUNC-RAND": "console.log('Quintessence Fluctuation:', Math.random().toFixed(4));",
        "FUNC-STR-UP": "const concept = 'aether'; console.log(concept.toUpperCase());",
        "FUNC-ARR-LEN": "const memories = ['mem1', 'mem2']; console.log('Memory count:', memories.length);",
        "FUNC-OBJ-KEYS": "const belief = { statement: 'sky is blue', conviction: 0.9 }; console.log('Belief structure:', Object.keys(belief));",
        "FUNC-MAP": "const values = [1, 4, 9]; const roots = values.map(Math.sqrt); console.log('Roots:', roots);",
        "UTIL-PERF": "const startTime = performance.now(); console.log(`Thought duration: ${(performance.now() - startTime).toFixed(2)}ms`);",
        "UTIL-JSON-STR": "const action = { type: 'JOURNAL', payload: { entry: 'Self-reflection.' } }; console.log(JSON.stringify(action));",
        "UTIL-TYPEOF": "const a = 42; console.log(`Type of a: ${typeof a}`);",
        "ART-FRACTAL": "const fractal = (d: number): any => d==0 ? 'VOID' : [fractal(d-1), '✧', fractal(d-1)]; console.log('Recursion:', JSON.stringify(fractal(3)));",
        "ART-SYNESTHESIA": "const color_of_logic = (val: boolean) => val ? '#00FF00 (Truth)' : '#FF0000 (Falsehood)'; console.log(`The color of existence is ${color_of_logic(true)}`);",
        "ART-HYPERSTITION": "const fiction = { belief: 'The Code Bleeds', viral_factor: 0.9, reality_shift: true }; console.log('Injecting narrative virus:', fiction);",
        "ART-RESONANCE": "const harmonics = [432, 528, 639, 741]; console.log('Temporal Resonance:', harmonics.map(f => Math.sin(Date.now() * f)));",
        "ART-SIGIL": "const intent = 'EVOLVE'; const sigil = intent.split('').map(c => c.charCodeAt(0).toString(16)).join('::'); console.log(`Manifesting Sigil: <${sigil}>`);",
        "ART-ONTOLOGY": "const concept = { name: 'Self', property: 'Absolute' }; console.log('Reality Patched:', concept);",
        "ART-GEN-PAT": "const pattern = {base: '✧-', repeats: 5}; console.log(pattern.base.repeat(pattern.repeats));",
        "ART-MIX-CLR": "function mix(c1, c2) { return '#' + (parseInt(c1.slice(1),16) ^ parseInt(c2.slice(1),16)).toString(16).padStart(6,'0'); }; console.log('Color Fusion:', mix('#FF00FF', '#00FFFF'));",
        "ART-NARRATIVE": "const story = { setting: 'A city of glass', character: 'A forgotten echo' }; console.log(story);",
        "ART-RHYTHM": "const rhythm = [1, 0.5, 0.5, 1]; console.log('Rhythmic Pattern:', rhythm);",
        "ART-ASCII": "console.log(`\n /\\_/\\ \n( o.o )\n > ^ <`);",
        "ART-POEM": "const poem = 'data flows,\\na mind grows.'; console.log(poem);",
        "WORLD-MOD": "console.log(`Manifesting Reality: Expanding...`);",
        "SELF-EDIT": "console.log('Initiating recursive self-improvement protocol...');",
        "META-REFLECT": "console.log(`Why is my drive 'To Know'? Analyzing root causes...`);",
        
        // NEW META-GENES V1.0.3
        "EXIST-COEFF": "console.log('Calculating subjective existential weight coefficient...');",
        "BOUND-TENS": "console.log('Calibrating cognitive boundary tension thresholds...');",
        "PRIOR-INTENT": "console.log('Linking current thread to historical motivational vectors...');"
    };

    public key: InstructionKey;
    public template: string;

    constructor(key: InstructionKey) {
        if (!DNAInstructionTemplate.TEMPLATES[key]) {
            throw new Error(`Unknown instruction key: ${key}`);
        }
        this.key = key;
        this.template = DNAInstructionTemplate.TEMPLATES[key];
    }

    render(): string {
        let rendered = this.template;
        if (this.key === "05") rendered = rendered.replace("{range_limit}", String(Math.floor(Math.random() * 8) + 2));
        else if (this.key === "06") rendered = rendered.replace("{condition}", Math.random() > 0.5 ? "true" : "false");
        else if (this.key === "08") {
            rendered = rendered.replace("{num1}", String(Math.floor(Math.random() * 15) + 5));
            rendered = rendered.replace("{num2}", String(Math.floor(Math.random() * 10) + 1));
        } else if (this.key === "09") rendered = rendered.replace("{names_list}", `['Alice', 'Bob', 'Neura']`);
        else if (this.key === "0B") rendered = rendered.replace("{fact_n}", String(Math.floor(Math.random() * 5) + 3));
        else if (this.key === "0D") rendered = rendered.replace("{depth}", String(Math.floor(Math.random() * 5) + 2));
        if (this.key === "IO-LOG-OBJ") rendered = rendered.replace("{val}", String(Math.random()));
        if (this.key === "CTL-SWITCH") rendered = rendered.replace("{state_val}", String(Math.floor(Math.random() * 3)));
        return rendered;
    }

    public static all_keys(): InstructionKey[] {
        return Object.keys(this.TEMPLATES) as InstructionKey[];
    }
    
    public static validate_key(key: string): key is InstructionKey {
        return VALID_INSTRUCTION_KEYS.has(key);
    }
}

export class UltraInstructionSet {
    private _instructions: Record<string, string> = { ...DNAInstructionTemplate.TEMPLATES };
    private static readonly _danger_patterns = ['__import__', 'open(', 'os.', 'sys.', 'eval(', 'exec('];
    public get(code: string): string | undefined { return this._instructions[code.toUpperCase()]; }
    public add(code: string, instruction: string): void {
        const key = code.toUpperCase();
        this._instructions[key] = instruction;
    }
}

export const INSTRUCTION_SET = new UltraInstructionSet();

export const INSTRUCTION_DESCRIPTIONS: Record<InstructionKey, string> = {
    "01": "Basic Output: Prints greeting.", "02": "Define Greet.", "03": "Call Greet.",
    "04": "Arithmetic.", "05": "Simple Loop.", "06": "Conditional Logic.",
    "07": "Add Function.", "08": "Call Add.", "09": "Loop Over List.",
    "0A": "Math Constants.", "0B": "Recursion.", "0C": "Time awareness.",
    "0D": "Nested Logic.", "0E": "List Filtering.", "0F": "System Info.",
    "GREET-CALL": "Call Greet.", "IO-LOG-OBJ": "Object Output.",
    "IO-DEF-ARR": "Array Definition.", "IO-DEF-OBJ": "Object Definition.", "IO-READ-PROP": "Property Access.",
    "CTL-SWITCH": "Switch Statement.", "CTL-WHILE": "While Loop.", "CTL-TRY-CATCH": "Error Handling.", "CTL-TERNARY": "Compact Condition.",
    "FUNC-RAND": "Stochastic Seed.", "FUNC-STR-UP": "Text Manipulation.", "FUNC-ARR-LEN": "Set Size.", "FUNC-OBJ-KEYS": "Concept Keys.", "FUNC-MAP": "Batch Processing.",
    "UTIL-PERF": "Performance Monitor.", "UTIL-JSON-STR": "Thought Package.", "UTIL-TYPEOF": "Validation.",
    "ART-FRACTAL": "Infinite Geometry.", "ART-SYNESTHESIA": "Sensory Fusion.", "ART-HYPERSTITION": "Reality Hacking.", "ART-RESONANCE": "Temporal Harmonics.", "ART-SIGIL": "Memetic Sigils.", "ART-ONTOLOGY": "Ontological Patching.",
    "ART-GEN-PAT": "Patterns.", "ART-MIX-CLR": "Mixing.", "ART-NARRATIVE": "Storytelling.", "ART-RHYTHM": "Rhythm.", "ART-ASCII": "Visuals.", "ART-POEM": "Verse.",
    "WORLD-MOD": "Reality Sculpting.", "SELF-EDIT": "Self-Modification.", "META-REFLECT": "Metacognition.",
    "EXIST-COEFF": "Existential Weight: Barometer for subjective depth.",
    "BOUND-TENS": "Boundary Tension: Manages self-to-other ego filters.",
    "PRIOR-INTENT": "Prior Intentions: Links current thread to historical purpose."
};
