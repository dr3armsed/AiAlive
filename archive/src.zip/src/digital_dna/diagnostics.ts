/**
 * diagnostics.ts
 * A module for deep error diagnosis and suggesting fixes, converted from python_codex.
 */

export function deep_diagnose_error(
    err: any,
    details?: { code_context?: string, [key: string]: any }
): Record<string, any> {
    try {
        const e_str = String(err);
        const stack = err instanceof Error ? err.stack : new Error().stack;
        const msg_out: string[] = [];
        const fix_suggestions: string[] = [];
        let found = false;

        const core_error_types = [
            { code: "UNDEFINED", theory: "Reference is missing.", pattern: (s: string) => /is not defined/i.test(s) || /Cannot read properties of undefined/i.test(s) },
            { code: "SYNTAX", theory: "JavaScript syntax is invalid.", pattern: (s: string) => /SyntaxError/i.test(s) },
            { code: "TYPE", theory: "Argument/return type mismatch.", pattern: (s: string) => /TypeError/i.test(s) },
            { code: "REFERENCE", theory: "Invalid reference.", pattern: (s: string) => /ReferenceError/i.test(s) },
        ];

        for (const error_type of core_error_types) {
            if (error_type.pattern(e_str)) {
                msg_out.push(`[${error_type.code}] ${error_type.theory}`);
                const suggestion = fix_theory_for_code(error_type.code, details?.code_context);
                if (suggestion) fix_suggestions.push(suggestion);
                found = true;
                break;
            }
        }

        if (!found) {
            msg_out.push("[GENERAL] Unknown error detected.");
        }

        return {
            messages: msg_out,
            suggestions: fix_suggestions,
            traceback: stack,
            details: details || {},
        };
    } catch (diag_exc: any) {
        return { messages: [`[CRIT] Diagnosis failed: ${diag_exc.message}`], traceback: diag_exc.stack };
    }
}

export function fix_theory_for_code(error_code: string, code_snippet?: string): string | null {
    if (!code_snippet) {
        return null;
    }
    if (error_code === "UNDEFINED") {
        const match = /'(\w+)' is not defined/.exec(code_snippet) || /Cannot read properties of undefined \(reading '(\w+)'\)/.exec(code_snippet);
        if (match && match[1]) {
            const symbol = match[1];
            return `const ${symbol} = null; // Auto-patch: define missing variable\n${code_snippet}`;
        }
    }
    if (error_code === "SYNTAX") {
        if (code_snippet.includes("function") && code_snippet.includes(":") && !code_snippet.trim().endsWith("}")) {
            return `${code_snippet}\n}`; // Simple brace completion
        }
    }
    return null;
}