export { DigitalChondria } from './digital_chondria';
export type { MitochondrialGene, MetabolicState } from './digital_chondria';