export { DigitalEpigenome } from './digital_epigenetics';
export type { EpigeneticMarker, ChromatinState, EnvironmentalEpigeneticFactor } from './digital_epigenetics';