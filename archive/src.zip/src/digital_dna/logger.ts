/**
 * dna_evolution/logger.ts (2025 Ultra Evolution Edition)
 *
 * UltraLogger: Ultra-fast, robust, and modular DNA Execution Logging Utility.
 * Browser-compatible version that logs to the console and an in-memory array.
 */

interface LogEntry {
    status: 'success' | 'failure' | 'event';
    timestamp: string;
    generation: any;
    nodeType: string;
    code: string;
    details: Record<string, any>;
}

const _logHistory: LogEntry[] = [];
const MAX_LOG_HISTORY = 2000;

function _log(entry: Omit<LogEntry, 'timestamp'>) {
    const fullEntry: LogEntry = {
        ...entry,
        timestamp: new Date().toISOString(),
    };
    _logHistory.push(fullEntry);
    if (_logHistory.length > MAX_LOG_HISTORY) {
        _logHistory.shift();
    }

    if (entry.status === 'success') {
        console.groupCollapsed(`[SUCCESS] Gen: ${entry.generation} | Type: ${entry.nodeType}`);
    } else {
        console.group(`[${entry.status.toUpperCase()}] Gen: ${entry.generation} | Type: ${entry.nodeType}`);
    }
    console.log('Code:', entry.code);
    console.log('Details:', entry.details);
    console.groupEnd();
}


export function log_success(
    node: any,
    code: string,
    metadata: Record<string, any> = {}
): void {
    _log({
        status: 'success',
        generation: node?.generation ?? 'unknown',
        nodeType: node?.constructor?.name ?? 'unknown',
        code,
        details: { metadata }
    });
}

export function log_failure(
    node: any,
    code: string,
    error_message: string,
    theory?: string,
    metadata: Record<string, any> = {}
): void {
    _log({
        status: 'failure',
        generation: node?.generation ?? 'unknown',
        nodeType: node?.constructor?.name ?? 'unknown',
        code,
        details: { error_message, theory, metadata }
    });
}

export function log_event(
    status: string,
    node: any,
    code: string,
    info: Record<string, any>
): void {
    _log({
        status: 'event',
        generation: node?.generation ?? 'unknown',
        nodeType: node?.constructor?.name ?? 'unknown',
        code,
        details: { eventStatus: status, ...info }
    });
}

export function get_log_history(limit: number = 100): LogEntry[] {
    return _logHistory.slice(-limit);
}
