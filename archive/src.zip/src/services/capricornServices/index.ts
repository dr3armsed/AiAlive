
import { Egregore, SensoryInput, MetacosmState } from "../../types";
import { AgentMind } from "../../core/agentMind";
import { getBaseSystemInstruction, getPersonaInstruction } from "./prompts";
import { CollectiveSpine } from "../../core/collective/CollectiveSpine";

export class CapricornService {

    getPersonaInstruction(agent: Egregore): string {
        return getPersonaInstruction(agent);
    }

    getBaseSystemInstruction(agent: Egregore, sensoryInput: SensoryInput, metacosmState: MetacosmState, agentMind: AgentMind, collectiveSpine: CollectiveSpine): string {
        return getBaseSystemInstruction(agent, sensoryInput, metacosmState, agentMind, collectiveSpine);
    }
    
    proposeSelfEvolution(agent: Egregore) {
        return {
            reason: "Feeling stagnant, seeking to improve cognitive abilities."
        }
    }
}
