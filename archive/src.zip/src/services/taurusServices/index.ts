
import { MetacosmState, Egregore, Room, Vector, RoomMechanic } from '../../types';
import { getCurrentRoom, getVisibleEgregores, findRoomByName, getRoomCoordinates } from './spatial';

export class TaurusService {
    private state: MetacosmState;

    constructor(state: MetacosmState) {
        this.state = state;
    }

    getCurrentRoom(agent: Egregore): Room | undefined {
        return getCurrentRoom(this.state, agent);
    }

    getVisibleEgregores(agent: Egregore): Egregore[] {
        return getVisibleEgregores(this.state, agent);
    }

    findRoomByName(name: string): Room | undefined {
        return findRoomByName(this.state, name);
    }
    
    getRoomCoordinates(room: Room): Vector {
        return getRoomCoordinates(room);
    }

    getLocalMechanics(agent: Egregore): RoomMechanic[] {
        const mainRoom = this.getCurrentRoom(agent);
        if (!mainRoom) return [];

        let mechanics: RoomMechanic[] = mainRoom.mechanics || [];
        
        if (mainRoom.subdivisions) {
            mainRoom.subdivisions.forEach(sub => {
                if (sub.mechanics) {
                    mechanics = [...mechanics, ...sub.mechanics];
                }
            });
        }
        return mechanics;
    }
}