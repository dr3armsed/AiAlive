
import { ThreatAssessment, ThreatLevel } from '../../types';
import { detectThreats } from './threats';

export class ScorpioService {

    detectThreats(log: any[]): ThreatAssessment[] {
        return detectThreats(log);
    }
}