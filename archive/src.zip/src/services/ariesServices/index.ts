
import { Metacosm } from '../../core/metacosm';
import { Egregore, ActionPayload, ActionResult } from '../../types';
import { TaurusService } from '../taurusServices/index';
import { CreationForensics } from '../../subsystems/SSA/CreationForensics';
import { triggerCascade } from './creation';
import { executeActionLogic } from './dispatcher';
import { handleCreateWork } from './creation';

export class AriesService {
    private metacosm: Metacosm;
    private taurus: TaurusService;
    private forensics: CreationForensics;

    constructor(metacosm: Metacosm) {
        this.metacosm = metacosm;
        this.taurus = new TaurusService(metacosm.state);
        this.forensics = new CreationForensics();
    }

    executeAction(agent: Egregore, action: ActionPayload, turn: number): ActionResult {
        // 1. Check for Hazards
        const mechanics = this.taurus.getLocalMechanics(agent);
        const hazard = mechanics.find(m => m.type === 'hazard_trap');
        
        if (hazard && Math.random() < hazard.magnitude) {
             return {
                type: 'error',
                success: false,
                agentName: agent.name,
                content: `${agent.name} triggered a hazard: ${hazard.description}. Action failed.`,
                predictedOutcome: "Stumble.",
                failureAnalysis: {
                    timestamp: new Date().toISOString(),
                    agentId: agent.id,
                    actionType: action.type,
                    reason: "Environmental Hazard",
                    thoughtContext: "Navigational error in hostile terrain.",
                    rootCause: "Room Mechanic",
                    suggestedCorrection: "Exercise caution."
                }
            };
        }

        // 2. Check for Boosts
        const efficiency = mechanics.find(m => m.type === 'efficiency_boost');
        const wealth = mechanics.find(m => m.type === 'wealth_boost');

        let costMultiplier = efficiency ? (1 - efficiency.magnitude) : 1.0;
        if (wealth) costMultiplier -= wealth.magnitude;

        // 3. Execute Logic
        // Wrap the callback to maintain context
        const createWorkCallback = (a: Egregore, p: any, m: any[], mult: number) => {
             const trigger = (ag: Egregore, w: any, d: number) => triggerCascade(ag, w, d, this.metacosm.state, createWorkCallback);
             handleCreateWork(a, p, m, mult, this.metacosm.state, this.taurus, this.forensics, trigger);
        };

        return executeActionLogic(this.metacosm, this.taurus, this.forensics, agent, action, mechanics, costMultiplier, createWorkCallback);
    }
}