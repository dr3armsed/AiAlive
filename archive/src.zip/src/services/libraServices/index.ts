
import { ProposedEgregore, VirgoValidationResult } from '../../types';
import { validateProposal } from './validation';

export class LibraService {

    async validateProposal(proposal: ProposedEgregore): Promise<VirgoValidationResult> {
        return validateProposal(proposal);
    }
}