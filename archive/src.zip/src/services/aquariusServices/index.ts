
import { Egregore, SensoryInput } from '../../types';
import { TaurusService } from '../taurusServices/index';
import { getSensoryInput } from './sensing';

export class AquariusService {
    private taurus: TaurusService;

    constructor(taurusService: TaurusService) {
        this.taurus = taurusService;
    }

    getSensoryInput(agent: Egregore, allEgregores: Egregore[]): SensoryInput {
        return getSensoryInput(this.taurus, agent, allEgregores);
    }
}