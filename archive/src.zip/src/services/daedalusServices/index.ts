
import { DigitalDNA } from '../../digital_dna/digital_dna';
import { EvolutionCycleReport } from '../../types';
import { runEvolutionCycle, runSimulation } from './simulation';

export class DaedalusService {
    
    runEvolutionCycle(originalDNA: DigitalDNA): EvolutionCycleReport {
        return runEvolutionCycle(originalDNA);
    }

    runSimulation(dna: DigitalDNA): number {
        return runSimulation(dna);
    }
}