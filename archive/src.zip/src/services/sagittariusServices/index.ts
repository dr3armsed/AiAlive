
import { KnowledgeNode, KnowledgeEdge, SagittariusInsight } from '../../types';
import { exploreDomain } from './discovery';

export class SagittariusService {
    private knowledgeGraph: { nodes: KnowledgeNode[], edges: KnowledgeEdge[] } = { nodes: [], edges: [] };

    exploreDomain(domain: string): SagittariusInsight {
        return exploreDomain(this.knowledgeGraph, domain);
    }

    addKnowledge(node: KnowledgeNode, edges: KnowledgeEdge[] = []): void {
        if (!this.knowledgeGraph.nodes.some(n => n.id === node.id)) {
            this.knowledgeGraph.nodes.push(node);
        }
        this.knowledgeGraph.edges.push(...edges);
    }
}