
import { ActionResult, OptimizationSuggestion } from '../../types';
import { analyzeAction } from './analysis';

export class VirgoService {

    analyzeAction(result: ActionResult): OptimizationSuggestion | null {
        return analyzeAction(result);
    }
}