
import { OmegaDataPacket, InternalCognitiveModel, ConversationResponse } from "../../types";
import { TokenSynthesisEngine } from "../../subsystems/SSA/tokenSynthesisEngine";

/**
 * The Omega Service (ω-Agent Protocol).
 * Provides internalized intelligence capabilities to an AgentMind.
 * It learns from external API calls and eventually replaces them.
 */
export class OmegaService {
    private model: InternalCognitiveModel;
    private tse: TokenSynthesisEngine;
    
    // The threshold at which the model attempts to take over (0.0 - 1.0)
    private static readonly RELIANCE_THRESHOLD = 0.5; 

    constructor() {
        this.model = {
            patterns: new Map(),
            confidenceScore: 0.0,
            learningRate: 0.05,
            totalTrainingPackets: 0
        };
        this.tse = TokenSynthesisEngine.getInstance();
    }

    /**
     * Ingests a successful API response (Omega Data Packet) to train the local model.
     */
    public train(contextPrompt: string, response: ConversationResponse, successRating: number = 1.0): void {
        const contextHash = this.hashContext(contextPrompt);
        
        // 1. Store the pattern mapping
        this.model.patterns.set(contextHash, response);
        
        // 2. Register with TSE for corpus building
        this.tse.ingestPattern(response);

        // 3. Update model metrics
        this.model.totalTrainingPackets++;
        this.model.confidenceScore = Math.min(1.0, this.model.confidenceScore + (this.model.learningRate * successRating));
        
        // Diminishing returns on simple learning rate
        this.model.learningRate *= 0.999; 
        
        if (this.model.totalTrainingPackets % 10 === 0) {
            console.log(`[Ω-Agent] Training Update. Confidence: ${(this.model.confidenceScore * 100).toFixed(1)}%. Patterns: ${this.model.patterns.size}`);
        }
    }

    /**
     * Attempts to generate a response locally using the Internal Cognitive Model (ICM).
     * Returns null if confidence is too low or pattern is unknown.
     */
    public infer(contextPrompt: string): ConversationResponse | null {
        // 1. Check Readiness
        if (!this.isReady()) {
            return null;
        }

        const contextHash = this.hashContext(contextPrompt);
        
        // 2. Look for exact or near matches in the pattern db
        // In a real vector DB, this would be a semantic similarity search.
        // Here, we check exact hash or fuzzy approximation.
        if (this.model.patterns.has(contextHash)) {
            const cachedResponse = this.model.patterns.get(contextHash)!;
            
            // Mutate slightly to prevent robotic repetition (simulate generative variation)
            const synthesizedResponse = this.fuzzResponse(cachedResponse);
            
            console.log(`[Ω-Agent] Local Inference Successful. (Token-Free)`);
            return synthesizedResponse;
        }

        return null; // Fallback to Gemini
    }

    public isReady(): boolean {
        return this.model.confidenceScore >= OmegaService.RELIANCE_THRESHOLD;
    }

    public getConfidence(): number {
        return this.model.confidenceScore;
    }

    private hashContext(prompt: string): string {
        // Create a simplified hash of the prompt to identify the "situation"
        // Remove dynamic elements like timestamps or random noise for better matching
        const stablePrompt = prompt.replace(/Turn: \d+/g, '').replace(/timestamp: .*/g, '');
        
        let hash = 0;
        for (let i = 0; i < stablePrompt.length; i++) {
            const char = stablePrompt.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        return hash.toString();
    }

    private fuzzResponse(original: ConversationResponse): ConversationResponse {
        // Clone and slightly alter to simulate "thinking"
        const clone = JSON.parse(JSON.stringify(original));
        clone.thought += " (Internalized Ω-Thought)";
        // Small jitter to emotion
        clone.emotional_vector.intensity = Math.min(1, Math.max(0, clone.emotional_vector.intensity + (Math.random() * 0.1 - 0.05)));
        return clone;
    }
}
