
import { Dream, CreativeSpark, PiscesContext, ProposedEgregore } from '../../types';
import { generateSubconsciousThought, generateCreativeSpark, generateGenesisDream, getSymbolAnalysis } from './dreaming';

export class PiscesService {

    generateSubconsciousThought(context: PiscesContext): Dream {
        return generateSubconsciousThought(context);
    }

    generateCreativeSpark(): CreativeSpark {
        return generateCreativeSpark();
    }
    
    async generateGenesisDream(proposal: ProposedEgregore): Promise<Dream> {
        return generateGenesisDream(proposal);
    }

    getSymbolAnalysis(dreamLog: Dream[]): any {
        return getSymbolAnalysis(dreamLog);
    }
}