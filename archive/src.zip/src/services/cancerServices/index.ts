
import { Egregore, OverallHealthStatus, CognitiveAnomaly, RoomMechanic } from '../../types';
import { AgentMind } from '../../core/agentMind';
import { performHealthCheck } from './diagnostics';

export interface HealthReport {
    status: OverallHealthStatus;
    anomalies: CognitiveAnomaly[];
    creativeRecommendation?: string;
}

export class CancerService {
    
    public performHealthCheck(agent: Egregore, thoughtHistory: any[], agentMind?: AgentMind, activeMechanics: RoomMechanic[] = []): HealthReport {
        return performHealthCheck(agent, thoughtHistory, agentMind, activeMechanics);
    }

    detectAnomalies(agent: Egregore, history: any[]): any[] {
        return this.performHealthCheck(agent, history).anomalies;
    }
    
    recommendSelfCareAction(agent: Egregore): string {
        return "CREATE_WORK";
    }

    generateHealthReportForArchitect(egregores: Egregore[], logs: any[]): string {
        let report = "Architect Health & Inspiration Report:\n";
        for (const agent of egregores) {
             const agentLogs = logs.filter(log => log.agentName === agent.name);
             const health = this.performHealthCheck(agent, agentLogs);
             report += `- ${agent.name}: ${health.status}. `;
             if (health.creativeRecommendation) {
                 report += `[MUSE ACTIVE]: Suggesting ${health.creativeRecommendation}.\n`;
             } else {
                 report += `Stable.\n`;
             }
        }
        return report;
    }
}